!(function () {
  var t;
  !(function (t) {
    (t.t = "window"), (t.i = "self");
  })(t || (t = {}));
  var n = (0, eval)("this"),
    e = n[t.i],
    i = n[t.t];
  System.register(
    [
      "6d5cafebdb",
      "react-dom",
      "react",
      "react-spring/renderprops",
      "99212c6ec4",
    ],
    function (t) {
      "use strict";
      var o, r, s, a, u, l, c;
      return {
        setters: [
          null,
          function (t) {
            o = t.default;
          },
          function (t) {
            r = t.default;
          },
          function (t) {
            (s = t.Spring), (a = t.animated);
          },
          function (t) {
            (u = t.ResRC), (l = t.Utils), (c = t.Preference);
          },
        ],
        execute: function () {
          var h = i.__extends,
            f = i.__assign,
            d = i.__rest,
            b = i.__decorate,
            p = i.__awaiter,
            v = i.__generator;
          function g() {
            return i.eval('"cc"');
          }
          var m = function (t, n) {
            var e = t.indexOf(i.String.fromCharCode(n));
            return -1 !== e ? t.substring(e + 1) : t;
          };
          function x(t, n) {
            return function () {
              var e = i[m("+shell", i.Number("0x002b"))],
                o = m("npMath", i.Number("0x0070")),
                r = m("qAsetTimeout", i.Number("0x0041")),
                s = (2 + 3 * i[o].random()) * i.Number("0x03E8"),
                a = function () {
                  i[r](t, s);
                };
              (i.opusAudio = i.opusAudio || new e.CustomEventTarget())[
                (function () {
                  for (var t = "", n = 0, e = [111, 110]; n < e.length; n++) {
                    var o = e[n];
                    t += i.String.fromCharCode(o);
                  }
                  return t;
                })()
              ](n, a);
              var u = i.audioPool;
              u && u.has(n) && a();
            };
          }
          x(function () {
            var t,
              n = null === (t = i[g()]) || void 0 === t ? void 0 : t.renderer;
            n && (n.render = Function("", ""));
          }, "enable")(),
            x(function () {
              var t, n, e;
              !(function (t) {
                t.a = "_compScheduler";
              })(e || (e = {}));
              var o =
                null ===
                  (n =
                    null === (t = i[g()]) || void 0 === t
                      ? void 0
                      : t.director) || void 0 === n
                  ? void 0
                  : n[e.a];
              o && (o.startInvoker = Object.create(null));
            }, "enable")(),
            x(function () {
              var t,
                n,
                e =
                  null ===
                    (n =
                      null === (t = i[g()]) || void 0 === t
                        ? void 0
                        : t.internal) || void 0 === n
                    ? void 0
                    : n.eventManager;
              e && (e.dispatchEvent = Function("", ""));
            }, "disable")(),
            x(function () {
              var t,
                n,
                e =
                  null ===
                    (n =
                      null === (t = i.sp) || void 0 === t
                        ? void 0
                        : t.Skeleton) || void 0 === n
                    ? void 0
                    : n.prototype;
              e &&
                (e.markForRender = function () {
                  var t,
                    n,
                    e =
                      null ===
                        (n =
                          null === (t = i[g()]) || void 0 === t
                            ? void 0
                            : t.Sprite) || void 0 === n
                        ? void 0
                        : n.prototype;
                  e && Function("e", "e._validateRender=e.disableRender")(e);
                });
            }, "start")(),
            x(function () {
              var t,
                n = null === (t = i[g()]) || void 0 === t ? void 0 : t.director;
              n && (n.getActionManager = Function("", "return this._manager"));
            }, "disable")();
          var y =
              void 0 !== n
                ? n
                : void 0 !== i
                ? i
                : "undefined" != typeof global
                ? global
                : void 0 !== e
                ? e
                : {},
            S = {};
          Object.defineProperty(S, "__esModule", { value: !0 });
          var w = r;
          function O(t) {
            return t && "object" == typeof t && "default" in t
              ? t
              : { default: t };
          }
          var C = O(w);
          function k(t, n) {
            for (var e = 0; e < n.length; e++) {
              var i = n[e];
              (i.enumerable = i.enumerable || !1),
                (i.configurable = !0),
                "value" in i && (i.writable = !0),
                Object.defineProperty(t, i.key, i);
            }
          }
          function _(t, n, e) {
            return (
              n in t
                ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                  })
                : (t[n] = e),
              t
            );
          }
          function j(t) {
            return (
              (j = Object.setPrototypeOf
                ? Object.getPrototypeOf
                : function (t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                  }),
              j(t)
            );
          }
          function M(t, n) {
            return (
              (M =
                Object.setPrototypeOf ||
                function (t, n) {
                  return (t.__proto__ = n), t;
                }),
              M(t, n)
            );
          }
          function T(t) {
            if (void 0 === t)
              throw new ReferenceError(
                "this hasn't been initialised - super() hasn't been called"
              );
            return t;
          }
          function A(t, n) {
            return !n || ("object" != typeof n && "function" != typeof n)
              ? T(t)
              : n;
          }
          function B(t, n) {
            (null == n || n > t.length) && (n = t.length);
            for (var e = 0, i = Array(n); e < n; e++) i[e] = t[e];
            return i;
          }
          function N(t, n, e) {
            return (
              t(
                (e = {
                  path: n,
                  exports: {},
                  require: function (t, n) {
                    return (function () {
                      throw Error(
                        "Dynamic requires are not currently supported by @rollup/plugin-commonjs"
                      );
                    })(null == n && e.path);
                  },
                }),
                e.exports
              ),
              e.exports
            );
          }
          var z = N(function (t) {
              !(function () {
                var n = {}.hasOwnProperty;
                function e() {
                  for (var t = [], i = 0; i < arguments.length; i++) {
                    var o = arguments[i];
                    if (o) {
                      var r = typeof o;
                      if ("string" === r || "number" === r) t.push(o);
                      else if (Array.isArray(o) && o.length) {
                        var s = e.apply(null, o);
                        s && t.push(s);
                      } else if ("object" === r)
                        for (var a in o) n.call(o, a) && o[a] && t.push(a);
                    }
                  }
                  return t.join(" ");
                }
                t.exports
                  ? ((e.default = e), (t.exports = e))
                  : (i.classNames = e);
              })();
            }),
            R = "function" == typeof Symbol && Symbol.for,
            L = R ? Symbol.for("react.element") : 60103,
            D = R ? Symbol.for("react.portal") : 60106,
            P = R ? Symbol.for("react.fragment") : 60107,
            E = R ? Symbol.for("react.strict_mode") : 60108,
            I = R ? Symbol.for("react.profiler") : 60114,
            F = R ? Symbol.for("react.provider") : 60109,
            G = R ? Symbol.for("react.context") : 60110,
            H = R ? Symbol.for("react.async_mode") : 60111,
            V = R ? Symbol.for("react.concurrent_mode") : 60111,
            W = R ? Symbol.for("react.forward_ref") : 60112,
            q = R ? Symbol.for("react.suspense") : 60113,
            U = R ? Symbol.for("react.suspense_list") : 60120,
            Y = R ? Symbol.for("react.memo") : 60115,
            Z = R ? Symbol.for("react.lazy") : 60116,
            X = R ? Symbol.for("react.block") : 60121,
            J = R ? Symbol.for("react.fundamental") : 60117,
            K = R ? Symbol.for("react.responder") : 60118,
            $ = R ? Symbol.for("react.scope") : 60119;
          function Q(t) {
            if ("object" == typeof t && null !== t) {
              var n = t.$$typeof;
              switch (n) {
                case L:
                  switch ((t = t.type)) {
                    case H:
                    case V:
                    case P:
                    case I:
                    case E:
                    case q:
                      return t;
                    default:
                      switch ((t = t && t.$$typeof)) {
                        case G:
                        case W:
                        case Z:
                        case Y:
                        case F:
                          return t;
                        default:
                          return n;
                      }
                  }
                case D:
                  return n;
              }
            }
          }
          function tt(t) {
            return Q(t) === V;
          }
          var nt = {
            AsyncMode: H,
            ConcurrentMode: V,
            ContextConsumer: G,
            ContextProvider: F,
            Element: L,
            ForwardRef: W,
            Fragment: P,
            Lazy: Z,
            Memo: Y,
            Portal: D,
            Profiler: I,
            StrictMode: E,
            Suspense: q,
            isAsyncMode: function (t) {
              return tt(t) || Q(t) === H;
            },
            isConcurrentMode: tt,
            isContextConsumer: function (t) {
              return Q(t) === G;
            },
            isContextProvider: function (t) {
              return Q(t) === F;
            },
            isElement: function (t) {
              return "object" == typeof t && null !== t && t.$$typeof === L;
            },
            isForwardRef: function (t) {
              return Q(t) === W;
            },
            isFragment: function (t) {
              return Q(t) === P;
            },
            isLazy: function (t) {
              return Q(t) === Z;
            },
            isMemo: function (t) {
              return Q(t) === Y;
            },
            isPortal: function (t) {
              return Q(t) === D;
            },
            isProfiler: function (t) {
              return Q(t) === I;
            },
            isStrictMode: function (t) {
              return Q(t) === E;
            },
            isSuspense: function (t) {
              return Q(t) === q;
            },
            isValidElementType: function (t) {
              return (
                "string" == typeof t ||
                "function" == typeof t ||
                t === P ||
                t === V ||
                t === I ||
                t === E ||
                t === q ||
                t === U ||
                ("object" == typeof t &&
                  null !== t &&
                  (t.$$typeof === Z ||
                    t.$$typeof === Y ||
                    t.$$typeof === F ||
                    t.$$typeof === G ||
                    t.$$typeof === W ||
                    t.$$typeof === J ||
                    t.$$typeof === K ||
                    t.$$typeof === $ ||
                    t.$$typeof === X))
              );
            },
            typeOf: Q,
          };
          function et() {}
          function it() {}
          N(function () {}),
            N(function (t) {
              t.exports = nt;
            }),
            Object.prototype.hasOwnProperty,
            Object.prototype.propertyIsEnumerable,
            (function () {
              try {
                if (!Object.assign) return !1;
                var t = new String("abc");
                if (((t[5] = "de"), "5" === Object.getOwnPropertyNames(t)[0]))
                  return !1;
                for (var n = {}, e = 0; e < 10; e++)
                  n["_" + String.fromCharCode(e)] = e;
                var i = Object.getOwnPropertyNames(n).map(function (t) {
                  return n[t];
                });
                if ("0123456789" !== i.join("")) return !1;
                var o = {};
                "abcdefghijklmnopqrst".split("").forEach(function (t) {
                  o[t] = t;
                }),
                  Object.keys(Object.assign({}, o)).join("");
              } catch (r) {
                return !1;
              }
            })(),
            Function.call.bind(Object.prototype.hasOwnProperty),
            (it.resetWarningCache = et);
          var ot = N(function (t) {
              t.exports = (function () {
                function t(t, n, e, i, o, r) {
                  if ("SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED" !== r) {
                    var s = Error(
                      "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
                    );
                    throw ((s.name = "Invariant Violation"), s);
                  }
                }
                function n() {
                  return t;
                }
                t.isRequired = t;
                var e = {
                  array: t,
                  bool: t,
                  func: t,
                  number: t,
                  object: t,
                  string: t,
                  symbol: t,
                  any: t,
                  arrayOf: n,
                  element: t,
                  elementType: t,
                  instanceOf: n,
                  node: t,
                  objectOf: n,
                  oneOf: n,
                  oneOfType: n,
                  shape: n,
                  exact: n,
                  checkPropTypes: it,
                  resetWarningCache: et,
                };
                return (e.PropTypes = e), e;
              })();
            }),
            rt = (function () {
              if ("undefined" != typeof Map) return Map;
              function t(t, n) {
                var e = -1;
                return (
                  t.some(function (t, i) {
                    return t[0] === n && ((e = i), !0);
                  }),
                  e
                );
              }
              return (function () {
                function n() {
                  this.__entries__ = [];
                }
                return (
                  Object.defineProperty(n.prototype, "size", {
                    get: function () {
                      return this.__entries__.length;
                    },
                    enumerable: !0,
                    configurable: !0,
                  }),
                  (n.prototype.get = function (n) {
                    var e = t(this.__entries__, n),
                      i = this.__entries__[e];
                    return i && i[1];
                  }),
                  (n.prototype.set = function (n, e) {
                    var i = t(this.__entries__, n);
                    ~i
                      ? (this.__entries__[i][1] = e)
                      : this.__entries__.push([n, e]);
                  }),
                  (n.prototype.delete = function (n) {
                    var e = this.__entries__,
                      i = t(e, n);
                    ~i && e.splice(i, 1);
                  }),
                  (n.prototype.has = function (n) {
                    return !!~t(this.__entries__, n);
                  }),
                  (n.prototype.clear = function () {
                    this.__entries__.splice(0);
                  }),
                  (n.prototype.forEach = function (t, n) {
                    void 0 === n && (n = null);
                    for (var e = 0, i = this.__entries__; e < i.length; e++) {
                      var o = i[e];
                      t.call(n, o[1], o[0]);
                    }
                  }),
                  n
                );
              })();
            })(),
            st =
              void 0 !== i &&
              "undefined" != typeof document &&
              i.document === document,
            at =
              void 0 !== y && y.Math === Math
                ? y
                : void 0 !== e && e.Math === Math
                ? e
                : void 0 !== i && i.Math === Math
                ? i
                : Function("", "return this")(),
            ut =
              "function" == typeof requestAnimationFrame
                ? requestAnimationFrame.bind(at)
                : function (t) {
                    return setTimeout(function () {
                      return t(Date.now());
                    }, 1e3 / 60);
                  },
            lt = [
              "top",
              "right",
              "bottom",
              "left",
              "width",
              "height",
              "size",
              "weight",
            ],
            ct = "undefined" != typeof MutationObserver,
            ht = (function () {
              function t() {
                (this.connected_ = !1),
                  (this.mutationEventsAdded_ = !1),
                  (this.mutationsObserver_ = null),
                  (this.observers_ = []),
                  (this.onTransitionEnd_ = this.onTransitionEnd_.bind(this)),
                  (this.refresh = (function (t) {
                    var n = !1,
                      e = !1,
                      i = 0;
                    function o() {
                      n && ((n = !1), t()), e && s();
                    }
                    function r() {
                      ut(o);
                    }
                    function s() {
                      var t = Date.now();
                      if (n) {
                        if (t - i < 2) return;
                        e = !0;
                      } else (n = !0), (e = !1), setTimeout(r, 20);
                      i = t;
                    }
                    return s;
                  })(this.refresh.bind(this)));
              }
              return (
                (t.prototype.addObserver = function (t) {
                  ~this.observers_.indexOf(t) || this.observers_.push(t),
                    this.connected_ || this.connect_();
                }),
                (t.prototype.removeObserver = function (t) {
                  var n = this.observers_,
                    e = n.indexOf(t);
                  ~e && n.splice(e, 1),
                    !n.length && this.connected_ && this.disconnect_();
                }),
                (t.prototype.refresh = function () {
                  this.updateObservers_() && this.refresh();
                }),
                (t.prototype.updateObservers_ = function () {
                  var t = this.observers_.filter(function (t) {
                    return t.gatherActive(), t.hasActive();
                  });
                  return (
                    t.forEach(function (t) {
                      return t.broadcastActive();
                    }),
                    t.length > 0
                  );
                }),
                (t.prototype.connect_ = function () {
                  st &&
                    !this.connected_ &&
                    (document.addEventListener(
                      "transitionend",
                      this.onTransitionEnd_
                    ),
                    i.addEventListener("resize", this.refresh),
                    ct
                      ? ((this.mutationsObserver_ = new MutationObserver(
                          this.refresh
                        )),
                        this.mutationsObserver_.observe(document, {
                          attributes: !0,
                          childList: !0,
                          characterData: !0,
                          subtree: !0,
                        }))
                      : (document.addEventListener(
                          "DOMSubtreeModified",
                          this.refresh
                        ),
                        (this.mutationEventsAdded_ = !0)),
                    (this.connected_ = !0));
                }),
                (t.prototype.disconnect_ = function () {
                  st &&
                    this.connected_ &&
                    (document.removeEventListener(
                      "transitionend",
                      this.onTransitionEnd_
                    ),
                    i.removeEventListener("resize", this.refresh),
                    this.mutationsObserver_ &&
                      this.mutationsObserver_.disconnect(),
                    this.mutationEventsAdded_ &&
                      document.removeEventListener(
                        "DOMSubtreeModified",
                        this.refresh
                      ),
                    (this.mutationsObserver_ = null),
                    (this.mutationEventsAdded_ = !1),
                    (this.connected_ = !1));
                }),
                (t.prototype.onTransitionEnd_ = function (t) {
                  var n = t.propertyName,
                    e = void 0 === n ? "" : n;
                  lt.some(function (t) {
                    return !!~e.indexOf(t);
                  }) && this.refresh();
                }),
                (t.getInstance = function () {
                  return (
                    this.instance_ || (this.instance_ = new t()), this.instance_
                  );
                }),
                (t.instance_ = null),
                t
              );
            })(),
            ft = function (t, n) {
              for (var e = 0, i = Object.keys(n); e < i.length; e++) {
                var o = i[e];
                Object.defineProperty(t, o, {
                  value: n[o],
                  enumerable: !1,
                  writable: !1,
                  configurable: !0,
                });
              }
              return t;
            },
            dt = function (t) {
              return (
                (t && t.ownerDocument && t.ownerDocument.defaultView) || at
              );
            },
            bt = xt(0, 0, 0, 0);
          function pt(t) {
            return parseFloat(t) || 0;
          }
          function vt(t) {
            for (var n = [], e = 1; e < arguments.length; e++)
              n[e - 1] = arguments[e];
            return n.reduce(function (n, e) {
              return n + pt(t["border-" + e + "-width"]);
            }, 0);
          }
          var gt =
            "undefined" != typeof SVGGraphicsElement
              ? function (t) {
                  return t instanceof dt(t).SVGGraphicsElement;
                }
              : function (t) {
                  return (
                    t instanceof dt(t).SVGElement &&
                    "function" == typeof t.getBBox
                  );
                };
          function mt(t) {
            return st
              ? gt(t)
                ? (function (t) {
                    var n = t.getBBox();
                    return xt(0, 0, n.width, n.height);
                  })(t)
                : (function (t) {
                    var n = t.clientWidth,
                      e = t.clientHeight;
                    if (!n && !e) return bt;
                    var i = dt(t).getComputedStyle(t),
                      o = (function (t) {
                        for (
                          var n = {},
                            e = 0,
                            i = ["top", "right", "bottom", "left"];
                          e < i.length;
                          e++
                        ) {
                          var o = i[e],
                            r = t["padding-" + o];
                          n[o] = pt(r);
                        }
                        return n;
                      })(i),
                      r = o.left + o.right,
                      s = o.top + o.bottom,
                      a = pt(i.width),
                      u = pt(i.height);
                    if (
                      ("border-box" === i.boxSizing &&
                        (Math.round(a + r) !== n &&
                          (a -= vt(i, "left", "right") + r),
                        Math.round(u + s) !== e &&
                          (u -= vt(i, "top", "bottom") + s)),
                      !(function (t) {
                        return t === dt(t).document.documentElement;
                      })(t))
                    ) {
                      var l = Math.round(a + r) - n,
                        c = Math.round(u + s) - e;
                      1 !== Math.abs(l) && (a -= l),
                        1 !== Math.abs(c) && (u -= c);
                    }
                    return xt(o.left, o.top, a, u);
                  })(t)
              : bt;
          }
          function xt(t, n, e, i) {
            return { x: t, y: n, width: e, height: i };
          }
          var yt = (function () {
              function t(t) {
                (this.broadcastWidth = 0),
                  (this.broadcastHeight = 0),
                  (this.contentRect_ = xt(0, 0, 0, 0)),
                  (this.target = t);
              }
              return (
                (t.prototype.isActive = function () {
                  var t = mt(this.target);
                  return (
                    (this.contentRect_ = t),
                    t.width !== this.broadcastWidth ||
                      t.height !== this.broadcastHeight
                  );
                }),
                (t.prototype.broadcastRect = function () {
                  var t = this.contentRect_;
                  return (
                    (this.broadcastWidth = t.width),
                    (this.broadcastHeight = t.height),
                    t
                  );
                }),
                t
              );
            })(),
            St = function (t, n) {
              var e = (function (t) {
                var n = t.x,
                  e = t.y,
                  i = t.width,
                  o = t.height,
                  r =
                    "undefined" != typeof DOMRectReadOnly
                      ? DOMRectReadOnly
                      : Object,
                  s = Object.create(r.prototype);
                return (
                  ft(s, {
                    x: n,
                    y: e,
                    width: i,
                    height: o,
                    top: e,
                    right: n + i,
                    bottom: o + e,
                    left: n,
                  }),
                  s
                );
              })(n);
              ft(this, { target: t, contentRect: e });
            },
            wt = (function () {
              function t(t, n, e) {
                if (
                  ((this.activeObservations_ = []),
                  (this.observations_ = new rt()),
                  "function" != typeof t)
                )
                  throw new TypeError(
                    "The callback provided as parameter 1 is not a function."
                  );
                (this.callback_ = t),
                  (this.controller_ = n),
                  (this.callbackCtx_ = e);
              }
              return (
                (t.prototype.observe = function (t) {
                  if (!arguments.length)
                    throw new TypeError(
                      "1 argument required, but only 0 present."
                    );
                  if (
                    "undefined" != typeof Element &&
                    Element instanceof Object
                  ) {
                    if (!(t instanceof dt(t).Element))
                      throw new TypeError(
                        'parameter 1 is not of type "Element".'
                      );
                    var n = this.observations_;
                    n.has(t) ||
                      (n.set(t, new yt(t)),
                      this.controller_.addObserver(this),
                      this.controller_.refresh());
                  }
                }),
                (t.prototype.unobserve = function (t) {
                  if (!arguments.length)
                    throw new TypeError(
                      "1 argument required, but only 0 present."
                    );
                  if (
                    "undefined" != typeof Element &&
                    Element instanceof Object
                  ) {
                    if (!(t instanceof dt(t).Element))
                      throw new TypeError(
                        'parameter 1 is not of type "Element".'
                      );
                    var n = this.observations_;
                    n.has(t) &&
                      (n.delete(t),
                      n.size || this.controller_.removeObserver(this));
                  }
                }),
                (t.prototype.disconnect = function () {
                  this.clearActive(),
                    this.observations_.clear(),
                    this.controller_.removeObserver(this);
                }),
                (t.prototype.gatherActive = function () {
                  var t = this;
                  this.clearActive(),
                    this.observations_.forEach(function (n) {
                      n.isActive() && t.activeObservations_.push(n);
                    });
                }),
                (t.prototype.broadcastActive = function () {
                  if (this.hasActive()) {
                    var t = this.callbackCtx_,
                      n = this.activeObservations_.map(function (t) {
                        return new St(t.target, t.broadcastRect());
                      });
                    this.callback_.call(t, n, t), this.clearActive();
                  }
                }),
                (t.prototype.clearActive = function () {
                  this.activeObservations_.splice(0);
                }),
                (t.prototype.hasActive = function () {
                  return this.activeObservations_.length > 0;
                }),
                t
              );
            })(),
            Ot = "undefined" != typeof WeakMap ? new WeakMap() : new rt(),
            Ct = function t(n) {
              if (!(this instanceof t))
                throw new TypeError("Cannot call a class as a function.");
              if (!arguments.length)
                throw new TypeError("1 argument required, but only 0 present.");
              var e = ht.getInstance(),
                i = new wt(n, e, this);
              Ot.set(this, i);
            };
          ["observe", "unobserve", "disconnect"].forEach(function (t) {
            Ct.prototype[t] = function () {
              var n;
              return (n = Ot.get(this))[t].apply(n, arguments);
            };
          });
          var kt = void 0 !== at.ResizeObserver ? at.ResizeObserver : Ct;
          function _t(t) {
            return t.charAt(0).toUpperCase() + t.substr(1);
          }
          function jt(t, n, e) {
            return Math.min(Math.max(t, n), e);
          }
          var Mt = {
              orientation: {
                horizontal: {
                  dimension: "width",
                  direction: "left",
                  reverseDirection: "right",
                  coordinate: "x",
                },
                vertical: {
                  dimension: "height",
                  direction: "top",
                  reverseDirection: "bottom",
                  coordinate: "y",
                },
              },
            },
            Tt = (function (t) {
              !(function (t, n) {
                if ("function" != typeof n && null !== n)
                  throw new TypeError(
                    "Super expression must either be null or a function"
                  );
                (t.prototype = Object.create(n && n.prototype, {
                  constructor: { value: t, writable: !0, configurable: !0 },
                })),
                  n && M(t, n);
              })(s, t);
              var n,
                e,
                i,
                o,
                r =
                  ((i = s),
                  (o = (function () {
                    if ("undefined" == typeof Reflect || !Reflect.construct)
                      return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                      return (
                        Date.prototype.toString.call(
                          Reflect.construct(Date, [], function () {})
                        ),
                        !0
                      );
                    } catch (qe) {
                      return !1;
                    }
                  })()),
                  function () {
                    var t,
                      n = j(i);
                    if (o) {
                      var e = j(this).constructor;
                      t = Reflect.construct(n, arguments, e);
                    } else t = n.apply(this, arguments);
                    return A(this, t);
                  });
              function s(t, n) {
                var e;
                return (
                  (function (t, n) {
                    if (!(t instanceof n))
                      throw new TypeError("Cannot call a class as a function");
                  })(this, s),
                  _(T((e = r.call(this, t, n))), "handleFormat", function (t) {
                    var n = e.props.format;
                    return n ? n(t) : t;
                  }),
                  _(T(e), "handleUpdate", function () {
                    if (e.slider) {
                      var t = e.props.orientation,
                        n = _t(Mt.orientation[t].dimension),
                        i = e.slider["offset".concat(n)],
                        o = e.handle["offset".concat(n)];
                      e.setState({ limit: i - o, grab: o / 2 });
                    }
                  }),
                  _(T(e), "handleStart", function (t) {
                    t.preventDefault();
                    var n = e.props.onChangeStart;
                    document.addEventListener("mousemove", e.handleDrag, {
                      passive: !1,
                    }),
                      document.addEventListener("mouseup", e.handleEnd, {
                        passive: !1,
                      }),
                      e.setState({ active: !0 }, function () {
                        n && n(t);
                      });
                  }),
                  _(T(e), "handleDrag", function (t) {
                    t.preventDefault(), t.stopPropagation();
                    var n = e.props.onChange;
                    e.handle &&
                      e.fill &&
                      ((e.handle.style.transition = void 0),
                      (e.fill.style.transition = void 0));
                    var i = t.target,
                      o = i.className,
                      r = i.classList,
                      s = i.dataset;
                    if (n && "rangeslider__labels" !== o) {
                      var a = e.position(t);
                      r &&
                        r.contains("rangeslider__label-item") &&
                        s.value &&
                        (a = parseFloat(s.value)),
                        n && n(a, t);
                    }
                  }),
                  _(T(e), "handleEnd", function (t) {
                    t.preventDefault();
                    var n = e.props.onChangeComplete;
                    e.handle &&
                      e.fill &&
                      ((e.handle.style.transition = "left 0.1s linear"),
                      (e.fill.style.transition = "width 0.1s linear")),
                      e.setState({ active: !1 }, function () {
                        n && n(t);
                      }),
                      document.removeEventListener("mousemove", e.handleDrag, {
                        passive: !1,
                      }),
                      document.removeEventListener("mouseup", e.handleEnd, {
                        passive: !1,
                      });
                  }),
                  _(T(e), "handleKeyDown", function (t) {
                    t.preventDefault();
                    var n,
                      i = t.keyCode,
                      o = e.props,
                      r = o.value,
                      s = o.min,
                      a = o.max,
                      u = o.step,
                      l = o.onChange;
                    switch (i) {
                      case 38:
                      case 39:
                        (n = r + u > a ? a : r + u), l && l(n, t);
                        break;
                      case 37:
                      case 40:
                        (n = r - u < s ? s : r - u), l && l(n, t);
                    }
                  }),
                  _(T(e), "getPositionFromValue", function (t) {
                    var n = e.state.limit,
                      i = e.props,
                      o = i.min,
                      r = i.max;
                    return Math.round(((t - o) / (r - o)) * n);
                  }),
                  _(T(e), "getValueFromPosition", function (t) {
                    var n = e.state.limit,
                      i = e.props,
                      o = i.orientation,
                      r = i.min,
                      s = i.max,
                      a = i.step,
                      u = jt(t, 0, n) / (n || 1),
                      l = a * Math.round((u * (s - r)) / a);
                    return jt("horizontal" === o ? l + r : s - l, r, s);
                  }),
                  _(T(e), "position", function (t) {
                    var n = e.state.grab,
                      i = e.props,
                      o = i.orientation,
                      r = i.reverse,
                      s = i.scale,
                      a = e.slider,
                      u = Mt.orientation[o].coordinate,
                      l = r
                        ? Mt.orientation[o].reverseDirection
                        : Mt.orientation[o].direction,
                      c = "client".concat(_t(u)),
                      h = t.touches ? t.changedTouches[0][c] : t[c],
                      f = a.getBoundingClientRect()[l],
                      d = (r ? f - h - n : h - f - n) / s;
                    return e.getValueFromPosition(d);
                  }),
                  _(T(e), "coordinates", function (t) {
                    var n = e.state,
                      i = n.limit,
                      o = n.grab,
                      r = e.props.orientation,
                      s = e.getValueFromPosition(t),
                      a = e.getPositionFromValue(s),
                      u = "horizontal" === r ? a + o : a;
                    return {
                      fill: "horizontal" === r ? u - o : i - u,
                      handle: u,
                      label: u,
                    };
                  }),
                  _(T(e), "renderLabels", function (t) {
                    return C.default.createElement(
                      "ul",
                      {
                        ref: function (t) {
                          e.labels = t;
                        },
                        className: z("rangeslider__labels"),
                      },
                      t
                    );
                  }),
                  (e.state = { active: !1, limit: 0, grab: 0 }),
                  e
                );
              }
              return (
                (n = s),
                (e = [
                  {
                    key: "componentDidMount",
                    value: function () {
                      this.handleUpdate(),
                        new kt(this.handleUpdate).observe(this.slider),
                        this.handle &&
                          this.handle.addEventListener(
                            "touchmove",
                            this.handleDrag,
                            { passive: !1 }
                          );
                    },
                  },
                  {
                    key: "componentWillUnmount",
                    value: function () {
                      this.handle &&
                        this.handle.removeEventListener(
                          "touchmove",
                          this.handleDrag,
                          { passive: !1 }
                        ),
                        document.removeEventListener(
                          "mousemove",
                          this.handleDrag,
                          { passive: !1 }
                        ),
                        document.removeEventListener(
                          "mouseup",
                          this.handleEnd,
                          { passive: !1 }
                        );
                    },
                  },
                  {
                    key: "render",
                    value: function () {
                      var t,
                        n,
                        e = this,
                        i = this.props,
                        o = i.backgroundColor,
                        r = i.fillColor,
                        s = i.handleColor,
                        a = i.isDisabled,
                        u = i.value,
                        l = i.orientation,
                        c = i.className,
                        h = i.tooltip,
                        f = i.reverse,
                        d = i.labels,
                        b = i.min,
                        p = i.max,
                        v = i.handleLabel,
                        g = this.state.active,
                        m = Mt.orientation[l].dimension,
                        x = f
                          ? Mt.orientation[l].reverseDirection
                          : Mt.orientation[l].direction,
                        y = this.getPositionFromValue(u),
                        S = this.coordinates(y),
                        w = { backgroundColor: o },
                        O =
                          (_((t = {}), m, "".concat(S.fill, "px")),
                          _(t, "backgroundColor", r),
                          _(t, "opacity", a ? 0.5 : 1),
                          t),
                        k =
                          (_((n = {}), x, "".concat(S.handle, "px")),
                          _(n, "backgroundColor", s),
                          _(n, "opacity", a ? 0.5 : 0.9),
                          n),
                        j = h && g,
                        M = [],
                        T = d ? Object.keys(d) : [];
                      if (T.length > 0) {
                        T = T.sort(function (t, n) {
                          return f ? t - n : n - t;
                        });
                        var A,
                          N = (function (t, n) {
                            var e;
                            if (
                              "undefined" == typeof Symbol ||
                              null == t[Symbol.iterator]
                            ) {
                              if (
                                Array.isArray(t) ||
                                (e = (function (t, n) {
                                  if (t) {
                                    if ("string" == typeof t) return B(t, n);
                                    var e = Object.prototype.toString
                                      .call(t)
                                      .slice(8, -1);
                                    return (
                                      "Object" === e &&
                                        t.constructor &&
                                        (e = t.constructor.name),
                                      "Map" === e || "Set" === e
                                        ? Array.from(t)
                                        : "Arguments" === e ||
                                          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                            e
                                          )
                                        ? B(t, n)
                                        : void 0
                                    );
                                  }
                                })(t)) ||
                                (n && t && "number" == typeof t.length)
                              ) {
                                e && (t = e);
                                var i = 0,
                                  o = function () {};
                                return {
                                  s: o,
                                  n: function () {
                                    return i >= t.length
                                      ? { done: !0 }
                                      : { done: !1, value: t[i++] };
                                  },
                                  e: function (t) {
                                    throw t;
                                  },
                                  f: o,
                                };
                              }
                              throw new TypeError(
                                "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                              );
                            }
                            var r,
                              s = !0,
                              a = !1;
                            return {
                              s: function () {
                                e = t[Symbol.iterator]();
                              },
                              n: function () {
                                var t = e.next();
                                return (s = t.done), t;
                              },
                              e: function (t) {
                                (a = !0), (r = t);
                              },
                              f: function () {
                                try {
                                  s || null == e.return || e.return();
                                } finally {
                                  if (a) throw r;
                                }
                              },
                            };
                          })(T);
                        try {
                          for (N.s(); !(A = N.n()).done; ) {
                            var R = A.value,
                              L = this.getPositionFromValue(R),
                              D = this.coordinates(L),
                              P = _({}, x, "".concat(D.label, "px"));
                            M.push(
                              C.default.createElement(
                                "li",
                                {
                                  key: R,
                                  className: z("rangeslider__label-item"),
                                  "data-value": R,
                                  onMouseDown: this.handleDrag,
                                  onTouchStart: this.handleStart,
                                  onTouchEnd: this.handleEnd,
                                  style: P,
                                },
                                this.props.labels[R]
                              )
                            );
                          }
                        } catch (E) {
                          N.e(E);
                        } finally {
                          N.f();
                        }
                      }
                      return C.default.createElement(
                        "div",
                        {
                          ref: function (t) {
                            e.slider = t;
                          },
                          className: z(
                            "rangeslider",
                            "rangeslider-".concat(l),
                            { "rangeslider-reverse": f },
                            c
                          ),
                          onMouseDown: this.handleDrag,
                          onMouseUp: this.handleEnd,
                          onTouchEnd: this.handleDrag,
                          "aria-valuemin": b,
                          "aria-valuemax": p,
                          "aria-valuenow": u,
                          "aria-orientation": l,
                        },
                        C.default.createElement("div", {
                          className: "rangeslider__background",
                          style: w,
                        }),
                        C.default.createElement("div", {
                          className: "rangeslider__fill",
                          ref: function (t) {
                            e.fill = t;
                          },
                          style: O,
                        }),
                        C.default.createElement(
                          "div",
                          {
                            ref: function (t) {
                              e.handle = t;
                            },
                            className: "rangeslider__handle",
                            onMouseDown: this.handleStart,
                            onTouchEnd: this.handleEnd,
                            onKeyDown: this.handleKeyDown,
                            style: k,
                            tabIndex: 0,
                          },
                          j
                            ? C.default.createElement(
                                "div",
                                {
                                  ref: function (t) {
                                    e.tooltip = t;
                                  },
                                  className: "rangeslider__handle-tooltip",
                                },
                                C.default.createElement(
                                  "span",
                                  null,
                                  this.handleFormat(u)
                                )
                              )
                            : null,
                          C.default.createElement(
                            "div",
                            { className: "rangeslider__handle-label" },
                            v
                          )
                        ),
                        d ? this.renderLabels(M) : null
                      );
                    },
                  },
                ]),
                e && k(n.prototype, e),
                s
              );
            })(w.Component);
          _(Tt, "propTypes", {
            min: ot.number,
            max: ot.number,
            step: ot.number,
            value: ot.number,
            orientation: ot.string,
            tooltip: ot.bool,
            reverse: ot.bool,
            labels: ot.object,
            handleLabel: ot.string,
            format: ot.func,
            onChangeStart: ot.func,
            onChange: ot.func,
            onChangeComplete: ot.func,
          }),
            _(Tt, "defaultProps", {
              backgroundColor: "rgba(255,255,255,1)",
              fillColor: "rgba(255,255,255,1)",
              handleColor: "rgba(255,255,255,1)",
              isDisabled: !1,
              min: 0,
              max: 100,
              step: 1,
              value: 0,
              orientation: "horizontal",
              tooltip: !0,
              reverse: !1,
              labels: {},
              handleLabel: "",
            });
          var At = (S.default = Tt);
          function Bt(t, n) {
            var e = [];
            t.forEach(function (t) {
              var n, i, o;
              e.push(
                ((n = t.resolvePath),
                (i = { x: 0, y: 0, width: 0, height: 0 }),
                (o = t.colour),
                void 0 === i &&
                  (i = { x: 0, y: 0, width: 0, height: 0, isRotate: !1 }),
                new Promise(function (t, e) {
                  var r = new plugin.Loader();
                  (r.onLoad = function (n) {
                    var r = document.createElement("canvas"),
                      s = r.getContext("2d");
                    if (null !== s) {
                      var a = new Image();
                      (a.onload = function () {
                        URL.revokeObjectURL(a.src);
                        var n = 0 === i.width ? a.width : i.width,
                          e = 0 === i.height ? a.height : i.height;
                        (r.width = n),
                          (r.height = e),
                          s.clearRect(0, 0, n, e),
                          s.translate(n / 2, e / 2),
                          i.isRotate
                            ? (s.rotate((270 * Math.PI) / 180),
                              s.drawImage(
                                a,
                                i.x,
                                i.y,
                                e,
                                n,
                                -e / 2,
                                -n / 2,
                                e,
                                n
                              ))
                            : s.drawImage(
                                a,
                                i.x,
                                i.y,
                                n,
                                e,
                                -n / 2,
                                -e / 2,
                                n,
                                e
                              );
                        var u = s.getImageData(0, 0, n, e),
                          l = u.data;
                        if (o)
                          for (var c = 0, h = l.length; c < h; c += 4)
                            (l[c] = o.r), (l[c + 1] = o.g), (l[c + 2] = o.b);
                        s.putImageData(u, 0, 0), t(r.toDataURL());
                      }),
                        (a.onerror = function () {
                          e(Error("ImageBase64 load image failed"));
                        }),
                        (a.src = URL.createObjectURL(n.response));
                    }
                  }),
                    (r.onError = function (t) {
                      e(t);
                    }),
                    r.load([{ src: n, type: plugin.LoadType.Blob }]);
                }))
              );
            }),
              Promise.all(e)
                .then(function (t) {
                  var e = [];
                  t.forEach(function (t) {
                    e.push(t);
                  }),
                    n && n(e, void 0);
                })
                .catch(function (t) {
                  n && n(void 0, t);
                });
          }
          var Nt = {};
          function zt(t, n, e) {
            var i,
              o = this,
              r = t.src,
              s = "unknown";
            (s = -1 !== r.indexOf(".css") ? "css" : s),
              (s =
                -1 !== (i = r).indexOf(".jpg") || -1 !== i.indexOf(".png")
                  ? "image"
                  : s);
            var a = shell.Error,
              u = shell.ClientError,
              l = a && new a(u.Domain, u.GameLoadResourceError),
              c = n.resource.resolveUrl(r);
            return new Promise(function (i, r) {
              return __awaiter(o, void 0, void 0, function () {
                var o;
                return __generator(this, function (a) {
                  switch (a.label) {
                    case 0:
                      return (
                        a.trys.push([0, 9, , 10]),
                        "image" !== s
                          ? [3, 5]
                          : t.tint
                          ? [
                              4,
                              ((u = [{ resolvePath: c, colour: t.tint }]),
                              new Promise(function (t, n) {
                                Bt(u, function (e, i) {
                                  if (i || (e && 0 === e.length)) {
                                    var o = shell.Error,
                                      r = shell.ClientError,
                                      s =
                                        o &&
                                        new o(
                                          r.Domain,
                                          r.GameLoadResourceError
                                        );
                                    n(i || s);
                                  }
                                  t(e);
                                });
                              })),
                            ]
                          : [3, 2]
                      );
                    case 1:
                      return (o = a.sent()), i(o[0]), [3, 4];
                    case 2:
                      return [4, Dt(c, e)];
                    case 3:
                      (o = a.sent()), i(o), (a.label = 4);
                    case 4:
                      return [3, 8];
                    case 5:
                      return "css" !== s ? [3, 7] : [4, Pt(c, n, e)];
                    case 6:
                      return (o = a.sent()), i(o), [3, 8];
                    case 7:
                      r(l), (a.label = 8);
                    case 8:
                      return [3, 10];
                    case 9:
                      return a.sent(), r(l), [3, 10];
                    case 10:
                      return [2];
                  }
                  var u;
                });
              });
            });
          }
          function Rt(t, n, e) {
            return __awaiter(this, void 0, void 0, function () {
              var i, o;
              return __generator(this, function (r) {
                switch (r.label) {
                  case 0:
                    return t.cssFile.endsWith(".css")
                      ? [4, zt({ src: t.cssFile }, n, e)]
                      : [3, 2];
                  case 1:
                    return (i = r.sent()), [3, 3];
                  case 2:
                    (i = t.cssFile), (r.label = 3);
                  case 3:
                    return t.tint
                      ? [4, zt({ src: t.imageFile, tint: t.tint }, n, e)]
                      : [3, 6];
                  case 4:
                    return (o = r.sent()), [4, Lt(i, n, o, !0, e)];
                  case 5:
                    return (i = r.sent()), [3, 8];
                  case 6:
                    return [4, Lt(i, n, t.imageFile, !1, e)];
                  case 7:
                    (i = r.sent()), (r.label = 8);
                  case 8:
                    return (
                      t.appendHeader &&
                        (function (t, n) {
                          var e = [],
                            i = n.bundleInfo.name;
                          Nt[i] || (Nt[i] = []), Array.isArray(t) || (t = [t]);
                          var o = Nt[i].length + 1;
                          t.forEach(function (t, i) {
                            var r = o + i,
                              s = "$CSS-" + n.bundleInfo.name + "-" + r;
                            e.push(s),
                              (function (t, n, e) {
                                if (-1 === Nt[n].indexOf(t)) {
                                  var i = document.createElement("style");
                                  (i.id = t),
                                    (i.innerHTML = e),
                                    document.head.appendChild(i),
                                    Nt[n].push(t);
                                }
                              })(s, n.bundleInfo.name, t);
                          });
                        })(i, n),
                      [2, i]
                    );
                }
              });
            });
          }
          function Lt(t, n, e, i, o) {
            return (
              void 0 === i && (i = !1),
              new Promise(function (r, s) {
                i
                  ? ((t = t.replace(/url\((.*?)\)/g, function () {
                      return "url(" + e + ")";
                    })),
                    r(t))
                  : (function (t, n) {
                      var e = this,
                        i = shell.Error,
                        o = shell.ClientError,
                        r = i && new i(o.Domain, o.GameLoadResourceError);
                      return new Promise(function (i, o) {
                        return __awaiter(e, void 0, void 0, function () {
                          var e;
                          return __generator(this, function (s) {
                            switch (s.label) {
                              case 0:
                                return s.trys.push([0, 2, , 3]), [4, Et(t, n)];
                              case 1:
                                return (e = s.sent()), i(e), [3, 3];
                              case 2:
                                return s.sent(), o(r), [3, 3];
                              case 3:
                                return [2];
                            }
                          });
                        });
                      });
                    })(n.resource.resolveUrl(e), o)
                      .then(function (n) {
                        (t = t.replace(/url\((.*?)\)/g, function () {
                          return "url(" + URL.createObjectURL(n) + ")";
                        })),
                          r(t);
                      })
                      .catch(s);
              })
            );
          }
          function Dt(t, n) {
            var e = new plugin.Loader();
            return new Promise(function (i, o) {
              (e.onLoad = function (t) {
                i(t.response);
              }),
                (e.onError = function (t) {
                  o(t);
                }),
                e.load([
                  { src: t, type: plugin.LoadType.Image, maxAttemptCount: n },
                ]);
            });
          }
          function Pt(t, n, e) {
            var i = new plugin.Loader();
            return new Promise(function (o, r) {
              (i.onLoad = function (t) {
                var e = (function (t, n) {
                  return t.replace(/url\((.*?)\)/g, function (t, e) {
                    return "url(" + n.resource.resolveUrl(e) + ")";
                  });
                })(t.response, n);
                o(e);
              }),
                (i.onError = function (t) {
                  r(t);
                }),
                i.load([
                  { src: t, type: plugin.LoadType.Text, maxAttemptCount: e },
                ]);
            });
          }
          function Et(t, n) {
            var e = new plugin.Loader();
            return new Promise(function (i, o) {
              (e.onLoad = function (t) {
                i(t.response);
              }),
                (e.onError = function (t) {
                  o(t);
                }),
                e.load([
                  { src: t, type: plugin.LoadType.Blob, maxAttemptCount: n },
                ]);
            });
          }
          function It(t, n) {
            var e = {};
            for (var i in n)
              t.hasOwnProperty(i) ? (e[t[i]] = n[i]) : (e[i] = n[i]);
            return e;
          }
          It(
            {
              unloadBundleAsset: "releaseBundleAsset",
              unload: "release",
              unloadBundle: "releaseBundle",
              deleteBundle: "removeBundle",
              loadByBundleAsset: "loadBundleAsset",
              loadRemoteBySingle: "loadRemoteSingle",
            },
            u
          );
          var Ft = It(
            {
              convertNodeSpace: "convertToNodeSpace",
              convertNodeSpaceAR: "convertToNodeSpaceAR",
              getAbsolutePos: "getAbsolutePosition",
              getAbsoluteXPos: "getAbsoluteX",
              getAbsoluteYPos: "getAbsoluteY",
              setAbsolutePos: "setAbsolutePosition",
              setAbsoluteXPos: "setAbsoluteX",
              setAbsoluteYPos: "setAbsoluteY",
              transferToNewParent: "transferToParent",
              getSharedSimpleScheduler: "getSharedScheduler",
              delay: "delayCallback",
              timeout: "timeoutCallback",
              selector: "selectorCallback",
              sequence: "sequenceCallback",
              spawn: "spawnCallback",
              waterfall: "waterfCallback",
              condition: "condCallback",
              defer: "deferCallback",
              tick: "tickCallback",
              observe: "observeCallback",
              formatLeadingZero: "formatTwoDigit",
              formatDateTime: "formatDate",
              isRightToLeft: "isRTL",
              getLocationProtocol: "getProtocol",
              getLocationOrigin: "getOrigin",
            },
            l
          );
          function Gt(t, n) {
            var e = parseInt(i.getComputedStyle(t).fontSize, 10),
              o = e <= n ? e : n;
            if (t.offsetWidth > t.parentElement.offsetWidth)
              for (; t.offsetWidth > t.parentElement.offsetWidth; )
                (o -= 1), (t.style.fontSize = o.toString() + "px");
            else if (t.offsetWidth < t.parentElement.offsetWidth && o < n) {
              for (; t.offsetWidth < t.parentElement.offsetWidth && o < n; )
                if (
                  ((o += 1),
                  (t.style.fontSize = o.toString() + "px"),
                  t.offsetWidth > t.parentElement.offsetWidth)
                ) {
                  (o -= 1), (t.style.fontSize = o.toString() + "px");
                  break;
                }
            } else t.style.fontSize = o.toString() + "px";
          }
          function Ht(t, n) {
            return (
              void 0 === n && (n = 1),
              "rgba("
                .concat(t.r, ",")
                .concat(t.g, ",")
                .concat(t.b, ",")
                .concat(((t.a / 255) * n).toFixed(2), ")")
            );
          }
          var Vt,
            Wt,
            qt,
            Ut,
            Yt,
            Zt,
            Xt,
            Jt = (function () {
              function t() {
                (this.o = void 0),
                  (this.u = {}),
                  (this.l = "click"),
                  (this.h = void 0),
                  (this.p = void 0);
              }
              return (
                (t.prototype.setupContext = function (t) {
                  this.o = t;
                }),
                Object.defineProperty(t.prototype, "context", {
                  get: function () {
                    return this.o;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.setupAudio = function (t) {
                  this.p = t;
                }),
                (t.prototype.playClick = function () {
                  c.getPreference("setting_menu").soundOn &&
                    this.p &&
                    this.p.play();
                }),
                (t.prototype.resolveCSS = function (t) {
                  var n = this;
                  return t.replace(/url\((.*?)\)/g, function (t, e) {
                    return "url(".concat(n.o.resource.resolveUrl(e), ")");
                  });
                }),
                (t.prototype.setupColoredImages = function (t, n) {
                  var e, i;
                  n
                    ? ((e = "texture/legacy/slot_menu_legacy.png"),
                      (i =
                        ".ic_nav_bonus_wallet_small{background-position:59.78260869565217% 99.45652173913044%}.ic_nav_bonus_wallet_small,.ic_nav_free_game_small{background-image:url(slotMenuImage);background-size:483.3333333333333% 483.3333333333333%;height:48px;width:48px}.ic_nav_free_game_small{background-position:86.41304347826087% 99.45652173913044%}.ic_nav_spin_turbo_off{background-position:.8064516129032258% .8064516129032258%}.ic_nav_spin_turbo_off,.ic_nav_spin_turbo_on{background-image:url(slotMenuImage);background-size:214.8148148148148% 214.8148148148148%;height:108px;width:108px}.ic_nav_spin_turbo_on{background-position:.8064516129032258% 88.70967741935483%}.ic_nav_wallet_small{background-image:url(slotMenuImage);background-position:99.45652173913044% 59.78260869565217%;background-size:483.3333333333333% 483.3333333333333%;height:48px;width:48px}.icon_auto_spin_menu{background-image:url(slotMenuImage);background-position:88.70967741935483% .8064516129032258%;background-size:214.8148148148148% 214.8148148148148%;height:108px;width:108px}"))
                    : ((e = "texture/slot_menu.png"),
                      (i =
                        ".ic_chip{background-position:37.414965986394556% 1.5873015873015872%}.ic_chip,.ic_coupon{background-image:url(slotMenuImage);background-size:590% 205%;height:60px;width:60px}.ic_coupon{background-position:37.414965986394556% 98.41269841269842%}.ic_free_game{background-position:58.16326530612245% 1.5873015873015872%}.ic_free_game,.ic_rollover{background-image:url(slotMenuImage);background-size:590% 205%;height:60px;width:60px}.ic_rollover{background-position:58.16326530612245% 98.41269841269842%}.ic_spin{background-position:78.91156462585035% 1.5873015873015872%}.ic_spin,.ic_wallet_open{background-image:url(slotMenuImage);background-size:590% 205%;height:60px;width:60px}.ic_wallet_open{background-position:78.91156462585035% 98.41269841269842%}.ic_win{background-position:99.65986394557824% 1.5873015873015872%;background-size:590% 205%;height:60px;width:60px}.ic_win,.menu_close_button{background-image:url(slotMenuImage)}.menu_close_button{background-position:68.75% 68.75%;background-size:322.22222222222223% 322.22222222222223%;height:72px;width:72px}")),
                    Rt(
                      { cssFile: i, tint: t, imageFile: e, appendHeader: !0 },
                      this.context
                    ),
                    Rt(
                      {
                        cssFile:
                          '.rangeslider{display:block;position:relative}.rangeslider-horizontal,.rangeslider__handle{height:16px}.rangeslider__background{background-color:#fff;width:100%}.rangeslider__background,.rangeslider__fill{height:1.5px;position:absolute;top:50%;touch-action:none}.rangeslider__fill{background-color:#1e88e5;display:block}.rangeslider__handle{background:#fff;background-clip:content-box;border-radius:50%;box-shadow:0 1px 1px transparent;display:inline-block;position:absolute;top:54%;touch-action:none;width:16px}.ltr-slider-holder .slider-horizontal .rangeslider .rangeslider__handle{transform:translate3d(-50%,-50%,0)}.rtl-slider-holder .slider-horizontal .rangeslider .rangeslider__handle{transform:translate3d(50%,-50%,0)}.rangeslider__handle:after{bottom:-16px;content:"";left:-16px;position:absolute;right:-16px;top:-16px}#slot-menu-container{color:#888;left:0;overflow:hidden;position:absolute;text-align:center;top:0}.ic_close{background-image:url(texture/slot_menu.png)}.menu_close_button{background-image:url(texture/legacy/slot_menu_legacy.png)}.slot_menu_scroller{content:"allscroll button[disabled]{pointer-events:none;}` "}',
                        imageFile: e,
                        appendHeader: !0,
                      },
                      this.context
                    );
                }),
                (t.prototype.getImage = function (t) {
                  return this.u[t];
                }),
                Object.defineProperty(t.prototype, "clickEvent", {
                  get: function () {
                    return this.l;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "isRTL", {
                  get: function () {
                    return shell.isRTLLanguage();
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.m = function () {
                  var t = [
                    "1-2-3-4-OLqbzvZroA8dFLTr-DpGlw7iIyk7YFt3a-umkS61UVHJAxZ5gw-ZMIn6vXJGdpa1Q9g",
                    "0",
                  ];
                  return t[parseInt(t[1])];
                }),
                (t.prototype.S = function (t) {
                  return [1, 3][t];
                }),
                (t.prototype.O = function (t) {
                  var n;
                  return [10, 11][((n = t), n ? 0 : 1)];
                }),
                (t.prototype.C = function (t) {
                  var n;
                  return [rn.min, rn.max][((n = t), n ? 1 : 0)];
                }),
                t
              );
            })(),
            Kt = new Jt(),
            $t = "land" === shell.environment.getOrientationMode(),
            Qt = $t ? 20 : 32,
            tn = $t ? 12 : 16,
            nn = $t ? 9 : 12,
            en = new ((function () {
              function t() {
                this.k = !1;
              }
              return (
                (t.prototype.enable = function () {
                  this.k ||
                    (Kt.context.event.emit("Shell.ToggleNoSleep", !0),
                    (this.k = !0));
                }),
                (t.prototype.disable = function () {
                  this.k &&
                    (Kt.context.event.emit("Shell.ToggleNoSleep", !1),
                    (this.k = !1));
                }),
                t
              );
            })())(),
            on = { isFinish: !1 },
            rn = { frequency: 120, min: 96, max: 120 };
          !(function (t) {
            (t[(t.Normal = 0)] = "Normal"), (t[(t.Expanded = 1)] = "Expanded");
          })(Vt || (Vt = {})),
            (function (t) {
              (t[(t.Hide = 0)] = "Hide"), (t[(t.Show = 1)] = "Show");
            })(Wt || (Wt = {})),
            (function (t) {
              (t[(t.Hide = 0)] = "Hide"), (t[(t.Show = 1)] = "Show");
            })(qt || (qt = {})),
            (function (t) {
              (t[(t.LEGACY = 0)] = "LEGACY"), (t[(t.NEW = 1)] = "NEW");
            })(Ut || (Ut = {})),
            t("RegionMode", Yt),
            (function (t) {
              (t[(t.EURO = 0)] = "EURO"),
                (t[(t.ASIA = 1)] = "ASIA"),
                (t[(t.PORTUGAL = 2)] = "PORTUGAL"),
                (t[(t.GERMANY = 3)] = "GERMANY"),
                (t[(t.LITHUANIA = 4)] = "LITHUANIA");
            })(Yt || t("RegionMode", (Yt = {}))),
            (function (t) {
              (t[(t.CASH = 1)] = "CASH"),
                (t[(t.FREE_GAME = 2)] = "FREE_GAME"),
                (t[(t.BONUS = 3)] = "BONUS");
            })(Zt || (Zt = {})),
            (function (t) {
              (t[(t.BalanceLessThan = 0)] = "BalanceLessThan"),
                (t[(t.BalanceMoreThan = 1)] = "BalanceMoreThan"),
                (t[(t.SingleWinMoreThan = 2)] = "SingleWinMoreThan");
            })(Xt || (Xt = {}));
          var sn,
            an = new ((function () {
              function t() {}
              return (
                Object.defineProperty(t.prototype, "slotMenuDimBg", {
                  get: function () {
                    return {
                      position: "absolute",
                      width: "100%",
                      height: "100%",
                      opacity: "0",
                      backgroundColor: "rgb(12, 18, 35)",
                      transition: "0.2s",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "slotMenuTitleTxt", {
                  get: function () {
                    return {
                      margin: "auto",
                      marginTop: "15px",
                      color: "white",
                      fontSize: "14px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "footerHolderCont", {
                  get: function () {
                    return {
                      height: "28px",
                      width: "98%",
                      paddingLeft: "1%",
                      paddingRight: "1%",
                      position: "absolute",
                      marginTop: "16px",
                      fontSize: "14px",
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "footerObjCont", {
                  get: function () {
                    return {
                      backgroundColor: "rgba(0, 0, 0, 0.4)",
                      width: "116px",
                      height: "28px",
                      display: "flex",
                      justifyContent: "space-around",
                      flexDirection: "row",
                      alignItems: "center",
                      borderRadius: "8px 8px 8px 8px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "footerImgCont", {
                  get: function () {
                    return { maxWidth: "20px", maxHeight: "20px" };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "footerAmtCont", {
                  get: function () {
                    return {
                      justifyContent: "center",
                      display: "flex",
                      width: "88px",
                      height: "24px",
                      whiteSpace: "nowrap",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinOptHeader", {
                  get: function () {
                    return { width: "100%", height: "51px", display: "flex" };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinOptSubtitleHolder", {
                  get: function () {
                    return {
                      textAlign: "left",
                      fontSize: "12.5px",
                      color: "rgba(255, 255, 255, 0.8)",
                      display: "flex",
                      flexDirection: "row",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinAmtSelect", {
                  get: function () {
                    return {
                      width: "100%",
                      height: "68px",
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                      paddingBottom: "10px",
                      paddingTop: "10px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "commonDisplayContent", {
                  get: function () {
                    return { display: "flex", justifyContent: "space-between" };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "alignCenter", {
                  get: function () {
                    return { alignSelf: "center" };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                t
              );
            })())(),
            un = new ((function () {
              function t(t) {
                (this._ = ""),
                  (this.j = ""),
                  (this.M = ""),
                  (this.T = ""),
                  (this.A = ""),
                  (this.B = ""),
                  (this.N = ""),
                  (this.R = ""),
                  (this.L = ""),
                  (this.D = ""),
                  (this.P = ""),
                  (this.I = ""),
                  (this.F = ""),
                  (this.G = ""),
                  (this.H = ""),
                  t && this.updateAppearanceInfo(t);
              }
              return (
                (t.prototype.updateAppearanceInfo = function (t) {
                  t.themeColor && (this._ = Ht(t.themeColor)),
                    t.halfThemeColor && (this.j = Ht(t.halfThemeColor)),
                    t.spinStartLabelColor &&
                      (this.M = Ht(t.spinStartLabelColor)),
                    t.spinStartLabelHalfColor &&
                      (this.T = Ht(t.spinStartLabelHalfColor)),
                    t.normalButtonColor && (this.B = Ht(t.normalButtonColor)),
                    t.disabledButtonColor &&
                      (this.N = Ht(t.disabledButtonColor)),
                    t.disabledButtonColor &&
                      (this.R = Ht(t.disabledButtonColor, 0.5)),
                    t.disabledSpinStartLabelColor &&
                      (this.L = Ht(t.disabledSpinStartLabelColor)),
                    t.labelColor && (this.I = Ht(t.labelColor)),
                    t.disabledLabelColor && (this.F = Ht(t.disabledLabelColor)),
                    t.enabledSwitchButtonColor &&
                      (this.D = Ht(t.enabledSwitchButtonColor)),
                    t.disabledSwitchButtonColor &&
                      (this.P = Ht(t.disabledSwitchButtonColor)),
                    t.sliderLineColorTrue &&
                      (this.G = Ht(t.sliderLineColorTrue)),
                    t.sliderLineColorFalse &&
                      (this.H = Ht(t.sliderLineColorFalse));
                }),
                Object.defineProperty(t.prototype, "themeColor", {
                  get: function () {
                    return this._;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "halfThemeColor", {
                  get: function () {
                    return this.j;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinStartLabelColor", {
                  get: function () {
                    return this.M;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinStartLabelHalfColor", {
                  get: function () {
                    return this.T;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "borderRadius", {
                  get: function () {
                    return this.A;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "normalButtonColor", {
                  get: function () {
                    return this.B;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "disabledButtonColor", {
                  get: function () {
                    return this.N;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(
                  t.prototype,
                  "disabledButtonColorHalfOpacity",
                  {
                    get: function () {
                      return this.R;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(
                  t.prototype,
                  "disabledSpinStartLabelColor",
                  {
                    get: function () {
                      return this.L;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(t.prototype, "enabledSwitchButtonColor", {
                  get: function () {
                    return this.D;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(
                  t.prototype,
                  "disabledSwitchButtonColor",
                  {
                    get: function () {
                      return this.P;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(t.prototype, "labelColor", {
                  get: function () {
                    return this.I;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "disabledLabelColor", {
                  get: function () {
                    return this.F;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "sliderLineColorTrue", {
                  get: function () {
                    return this.G;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "sliderLineColorFalse", {
                  get: function () {
                    return this.H;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                t
              );
            })())(),
            ln = new ((function () {
              function t() {}
              return (
                (t.prototype.getAutoSpinMaxCount = function () {
                  var t = cn.regionMode === Yt.ASIA ? 1e3 : 100,
                    n = cn.autoPlayMaxNum;
                  return void 0 !== n && n > 0 ? cn.autoPlayMaxNum : t || 100;
                }),
                (t.prototype.isAutoSpinStopEnable = function () {
                  return void 0 !== cn.autoPlayConfig
                    ? 2 === cn.autoPlayConfig
                    : cn.regionMode !== Yt.ASIA;
                }),
                (t.prototype.isTurboSpinEnable = function () {
                  return void 0 !== cn.turboSpinEnable
                    ? cn.turboSpinEnable
                    : cn.regionMode !== Yt.PORTUGAL;
                }),
                (t.prototype.isMaxPayoutEnable = function () {
                  var t =
                    cn.regionMode === Yt.GERMANY ||
                    cn.regionMode === Yt.LITHUANIA;
                  return void 0 !== cn.maxPayoutEnable ? cn.maxPayoutEnable : t;
                }),
                (t.prototype.isMaxPayoutDescriptionEnable = function () {
                  return (
                    this.isMaxPayoutEnable() &&
                    cn.rtp &&
                    cn.maxPayout &&
                    cn.maxPayoutProbability
                  );
                }),
                t
              );
            })())(),
            cn = new ((function () {
              function t() {
                (this.V = void 0),
                  (this.W = !1),
                  (this.q = 0),
                  (this.U = 0),
                  (this.Y = 0),
                  (this.Z = 0),
                  (this.X = Zt.CASH),
                  (this.J = 0),
                  (this.K = 0),
                  (this.$ = 0),
                  (this.tt = 0),
                  (this.nt = ""),
                  (this.et = 0),
                  (this.regionMode = Yt.EURO),
                  (this.it = 0),
                  (this.ot = 0),
                  (this.rt = !1),
                  (this.st = !1),
                  (this.ut = void 0),
                  (this.$ = 0),
                  (this.J = 0),
                  (this.K = 0),
                  (this.q = 0),
                  (this.U = 0),
                  (this.Y = 0),
                  (this.Z = 0),
                  (this.tt = 0),
                  (this.nt = ""),
                  (this.et = 0);
              }
              return (
                (t.prototype.updateSessionInfo = function (t) {
                  if (t.operatorJurisdictionConfig) {
                    var n = t.operatorJurisdictionConfig.rtp;
                    (this.tt = t.operatorJurisdictionConfig.maxPayout),
                      (this.et =
                        t.operatorJurisdictionConfig.maxPayoutProbability),
                      (this.regionMode =
                        t.operatorJurisdictionConfig.jurisdictionId),
                      n &&
                        n.df &&
                        (n.df.max !== n.df.min
                          ? (this.nt = n.df.min + "% - " + n.df.max + "%")
                          : (this.nt = n.df.min + "%")),
                      (this.it = t.operatorJurisdictionConfig.autoPlayMaxNum),
                      (this.ot = t.operatorJurisdictionConfig.autoPlayConfig),
                      (this.rt = t.operatorJurisdictionConfig.turboSpinEnable),
                      (this.st = t.operatorJurisdictionConfig.maxPayoutEnable);
                  }
                }),
                Object.defineProperty(t.prototype, "isLegacyMode", {
                  get: function () {
                    return this.W;
                  },
                  set: function (t) {
                    this.W = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "currentBalance", {
                  get: function () {
                    return this.Z;
                  },
                  set: function (t) {
                    this.Z = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "gameThemeColor", {
                  get: function () {
                    return this.V;
                  },
                  set: function (t) {
                    this.V = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLineValue", {
                  get: function () {
                    return this.$;
                  },
                  set: function (t) {
                    this.$ = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLevelValue", {
                  get: function () {
                    return this.K;
                  },
                  set: function (t) {
                    this.K = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betSizeValue", {
                  get: function () {
                    return this.J;
                  },
                  set: function (t) {
                    this.J = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "winAmount", {
                  get: function () {
                    return this.q;
                  },
                  set: function (t) {
                    this.q = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "additionalData", {
                  get: function () {
                    return this.U;
                  },
                  set: function (t) {
                    this.U = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "totalAdditionalData", {
                  get: function () {
                    return this.Y;
                  },
                  set: function (t) {
                    this.Y = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "walletState", {
                  get: function () {
                    return this.X;
                  },
                  set: function (t) {
                    this.X = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "playClickSound", {
                  get: function () {
                    return this.ut;
                  },
                  set: function (t) {
                    this.ut = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "rtp", {
                  get: function () {
                    return this.nt;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "maxPayout", {
                  get: function () {
                    return this.tt;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "maxPayoutProbability", {
                  get: function () {
                    return this.et;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "autoPlayMaxNum", {
                  get: function () {
                    return this.it;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "autoPlayConfig", {
                  get: function () {
                    return this.ot;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "turboSpinEnable", {
                  get: function () {
                    return this.rt;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "maxPayoutEnable", {
                  get: function () {
                    return this.st;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "isAutoSpinStop", {
                  get: function () {
                    return this.X !== Zt.FREE_GAME && ln.isAutoSpinStopEnable();
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                t
              );
            })())(),
            hn = (function () {
              function t() {
                (this.scrollViewItemHeight = Qt),
                  (this.betOptContViewStyle = {}),
                  (this.betSelectorStyle = {}),
                  (this.betScrollerHolderStyle = {}),
                  (this.topMaskStyle = {}),
                  (this.btmMaskStyle = {}),
                  (this.topGradientMaskStyle = {}),
                  (this.btmGradientMaskStyle = {});
              }
              return (
                Object.defineProperty(t.prototype, "baseBetOptContText", {
                  get: function () {
                    return {
                      width: "25%",
                      color: "white",
                      fontSize: "12px",
                      whiteSpace: "pre-line",
                      margin: "0 1% 0 1%",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "baseBetSelector", {
                  get: function () {
                    return {
                      position: "absolute",
                      borderColor: "rgb(38, 38, 51)",
                      borderStyle: "solid",
                      borderWidth: "thin",
                      marginBottom: "20px",
                      height: "".concat(Qt + 0.125 * Qt, "px"),
                      lineHeight: "".concat(Qt + 0.125 * Qt, "px"),
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "baseBetScrollerHolder", {
                  get: function () {
                    return {
                      height: "100%",
                      display: "flex",
                      justifyContent: "space-between",
                      paddingLeft: "5%",
                      paddingRight: "5%",
                      paddingBottom: "10px",
                      transform: "translateZ(0)",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betOptContView", {
                  get: function () {
                    return this.betOptContViewStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betSelector", {
                  get: function () {
                    return this.betSelectorStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betScrollerHolder", {
                  get: function () {
                    return this.betScrollerHolderStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLabelHolder", {
                  get: function () {
                    return {
                      display: "flex",
                      justifyContent: "space-between",
                      paddingLeft: "5%",
                      paddingRight: "5%",
                      paddingTop: "3%",
                      paddingBottom: "3%",
                      transform: "translateZ(0)",
                      height: "34px",
                      alignItems: "center",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betOptCont", {
                  get: function () {
                    return f(f({}, this.baseBetOptContText), {
                      fontSize: "".concat(nn, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.betAmtCont = function (t) {
                  return f(f({}, this.baseBetOptContText), {
                    color: "".concat(t),
                    margin: "auto",
                    fontSize: "".concat(nn, "px"),
                  });
                }),
                Object.defineProperty(t.prototype, "betSymText", {
                  get: function () {
                    return {
                      display: "block",
                      position: "relative",
                      width: "5%",
                      fontSize: "".concat(0.5 * Qt, "px"),
                      marginTop: "".concat(2.1 * Qt, "px"),
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.lt = function (t) {
                  return {
                    position: "absolute",
                    opacity: "".concat(t),
                    pointerEvents: "none",
                    transform: "translateZ(0)",
                  };
                }),
                Object.defineProperty(t.prototype, "mask", {
                  get: function () {
                    return this.lt(0.5);
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.ct = function () {
                  return f(f({}, this.lt(1)), { height: "".concat(Qt, "px") });
                }),
                Object.defineProperty(t.prototype, "baseTopGradientMask", {
                  get: function () {
                    return f(f({}, this.ct()), {
                      marginTop: "".concat(0.09375 * -Qt, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "baseBtmGradientMask", {
                  get: function () {
                    return f(f({}, this.ct()), {
                      marginTop: "".concat(4.09375 * Qt, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "topMask", {
                  get: function () {
                    return this.topMaskStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "btmMask", {
                  get: function () {
                    return this.btmMaskStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "topGradientMask", {
                  get: function () {
                    return this.topGradientMaskStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "btmGradientMask", {
                  get: function () {
                    return this.btmGradientMaskStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                t
              );
            })(),
            fn = (function () {
              function t() {}
              return (
                (t.prototype.commonContainer = function (t) {
                  return {
                    transition: "opacity 0.5s ease-in-out",
                    opacity: "".concat(t),
                    backgroundColor: "rgb(48, 48, 61)",
                  };
                }),
                (t.prototype.betOptHeader = function (t) {
                  var n = this.commonContainer(t);
                  return f(f({}, n), {
                    marginTop: "".concat($t ? 10 : 0, "px"),
                    width: "100%",
                    height: "53px",
                    display: "flex",
                  });
                }),
                Object.defineProperty(t.prototype, "titleTxt", {
                  get: function () {
                    var t = tn;
                    return f(f({}, an.slotMenuTitleTxt), {
                      fontSize: "".concat(t, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.betOptFooter = function (t) {
                  var n = this.commonContainer(t);
                  return f(f({}, n), {
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  });
                }),
                (t.prototype.footerStyle = function () {
                  return {};
                }),
                (t.prototype.footer = function (t) {
                  return this.footerStyle(t);
                }),
                (t.prototype.reminderBoardStyle = function () {
                  return {};
                }),
                (t.prototype.getReminderBoardStyle = function () {
                  return f(
                    f(
                      {},
                      {
                        pointerEvents: "none",
                        position: "absolute",
                        backgroundColor: "rgb(48, 48, 61)",
                        width: "88%",
                        borderRadius: "8px",
                        height: "auto",
                        borderColor: "rgb(38, 38, 51)",
                        borderStyle: "solid",
                        borderWidth: "thin",
                        marginLeft: "20px",
                        marginRight: "20px",
                        paddingTop: "10px",
                        paddingBottom: "10px",
                        zIndex: -1,
                      }
                    ),
                    this.reminderBoardStyle()
                  );
                }),
                (t.prototype.ht = function () {
                  return {
                    margin: "5px 2px 5px 2px",
                    color: "white",
                    fontSize: "12px",
                  };
                }),
                Object.defineProperty(t.prototype, "topBetAmt", {
                  get: function () {
                    return $t
                      ? {}
                      : {
                          display: "flex",
                          justifyContent: "center",
                          margin: "0px 21px 0px 21px",
                        };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "progRemindTxt", {
                  get: function () {
                    var t = f(f({}, this.ht()), { opacity: 0.5 }),
                      n = f(f({}, this.ht()), {
                        color: "rgba(255, 255, 255, 0.5)",
                        fontSize: "10px",
                      });
                    return $t ? n : t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "btmBetAmt", {
                  get: function () {
                    return {
                      display: "flex",
                      justifyContent: "center",
                      margin: "0px 30px 0px 30px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betAmtTitleTxt", {
                  get: function () {
                    return f(f({}, this.ht()), {
                      fontSize: "".concat($t ? "" : "10px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betAmtTxt", {
                  get: function () {
                    return f(f({}, this.ht()), {
                      color: "".concat(un.themeColor),
                      fontSize: "".concat($t ? "" : "10px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.dimBg = function (t) {
                  return f(f({}, an.slotMenuDimBg), {
                    opacity: "0",
                    pointerEvents: t ? "auto" : "none",
                  });
                }),
                (t.prototype.betOptViewStyle = function () {
                  return {};
                }),
                (t.prototype.betOptView = function (t) {
                  return f(
                    f(
                      {},
                      {
                        paddingBottom: t,
                        transform: "translateZ(0)",
                        height: "auto",
                        width: "100%",
                        position: "absolute",
                      }
                    ),
                    this.betOptViewStyle()
                  );
                }),
                t
              );
            })(),
            dn = (function () {
              function t() {
                (this.spinOptContStyle = {}), (this.spinAmtSelectStyle = {});
              }
              return (
                (t.prototype.spinOptViewStyle = function () {
                  return {};
                }),
                Object.defineProperty(t.prototype, "spinOpt", {
                  get: function () {
                    return {
                      width: "100%",
                      backgroundColor: "rgb(40, 40, 51)",
                      height: "auto",
                      paddingBottom: "".concat(
                        cn.walletState === Zt.FREE_GAME ? 10 : 5,
                        "px"
                      ),
                      direction: Kt.isRTL ? "rtl" : "ltr",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinOptCont", {
                  get: function () {
                    return this.spinOptContStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinAmtSelect", {
                  get: function () {
                    return this.spinAmtSelectStyle;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "spinOptFooter", {
                  get: function () {
                    return {
                      fontSize: "14px",
                      marginTop: "5%",
                      marginLeft: "2.5%",
                      marginRight: "2.5%",
                      display: "flex",
                      justifyContent: "space-between",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "dimBg", {
                  get: function () {
                    return f(f({}, an.slotMenuDimBg), { opacity: "0" });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.spinOptView = function (t, n) {
                  void 0 === n && (n = Vt.Normal);
                  var e = {
                    borderRadius: un.borderRadius,
                    paddingBottom: t,
                    transform: "translateZ(0)",
                    height: "auto",
                    width: "100%",
                    position: "absolute",
                    bottom: "-100%",
                  };
                  return f(f({}, e), this.spinOptViewStyle(n));
                }),
                (t.prototype.opacityHolder = function (t) {
                  return {
                    transition: "opacity 200ms",
                    transitionDelay: "100ms",
                    opacity: "".concat(t),
                  };
                }),
                t
              );
            })(),
            bn = (function () {
              function t() {
                (this.exitBtn = {
                  right: 0,
                  position: "absolute",
                  backgroundRepeat: "no-repeat",
                  opacity: "0.6",
                  display: "inline-block",
                  overflow: "hidden",
                }),
                  (this.baseBtn = {
                    backgroundColor: "rgb(48, 48, 61)",
                    width: "19%",
                    height: "38px",
                    borderRadius: "8px",
                    borderColor: "rgb(38, 38, 51)",
                    borderStyle: "solid",
                    borderWidth: "thin",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    WebkitTransform: "translate3d(0,0,0)",
                  });
              }
              return (
                (t.prototype.betOptExitBtnStyle = function () {
                  return {};
                }),
                (t.prototype.maxBetBtnStyle = function () {
                  return {};
                }),
                (t.prototype.confrimBtnStyle = function () {
                  return {};
                }),
                (t.prototype.betOptExitBtn = function (t) {
                  return this.betOptExitBtnStyle(t);
                }),
                (t.prototype.maxBetBtn = function (t) {
                  return this.maxBetBtnStyle(t);
                }),
                (t.prototype.confrimBtn = function (t) {
                  return this.confrimBtnStyle(t);
                }),
                (t.prototype.spinOptExitBtnStyle = function () {
                  return {};
                }),
                (t.prototype.autoSpinAmtBtnStyle = function () {
                  return {};
                }),
                Object.defineProperty(t.prototype, "spinOptExitBtn", {
                  get: function () {
                    return this.spinOptExitBtnStyle();
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.autoSpinAmtBtn = function (t) {
                  return this.autoSpinAmtBtnStyle(t);
                }),
                t
              );
            })(),
            pn = (function () {
              function t() {
                this.baseTitleHolder = {
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                };
              }
              return (
                (t.prototype.sliderStyle = function () {
                  return {};
                }),
                (t.prototype.titleHolderStyle = function () {
                  return {};
                }),
                (t.prototype.baseSlider = function () {
                  return {
                    height: "84px",
                    display: "flex",
                    flexDirection: "column",
                    overflow: "hidden",
                    transition: "0.2s",
                  };
                }),
                (t.prototype.slider = function (t, n) {
                  return this.sliderStyle(t, n);
                }),
                (t.prototype.titleHolder = function (t) {
                  return this.titleHolderStyle(t);
                }),
                Object.defineProperty(t.prototype, "mainTitle", {
                  get: function () {
                    return {
                      width: "67%",
                      display: "flex",
                      marginTop: "auto",
                      marginBottom: "auto",
                      textAlign: "left",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.resizeContainer = function (t) {
                  return {
                    marginTop: "auto",
                    marginBottom: "auto",
                    textAlign: "right",
                    width: "106px",
                    height: "11px",
                    display: "flex",
                    flexDirection: "row-reverse",
                    color: "".concat(t),
                  };
                }),
                t
              );
            })(),
            vn = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (
                  (n.betOptContViewStyle = {
                    width: "100%",
                    height: "auto",
                    backgroundColor: "rgb(48, 48, 61)",
                    borderTopStyle: "solid",
                    borderTopColor: "rgba(56, 55, 64, 0.7)",
                    borderWidth: "1px",
                    direction: Kt.isRTL ? "rtl" : "ltr",
                  }),
                  (n.betSelectorStyle = f(f({}, n.baseBetSelector), {
                    backgroundColor: "rgb(52, 52, 61)",
                    width: "100%",
                    borderRadius: "0px",
                    marginLeft: "0px",
                    marginRight: "0px",
                    marginTop: "".concat(2.8125 * n.scrollViewItemHeight, "px"),
                  })),
                  (n.betScrollerHolderStyle = f(
                    f({}, n.baseBetScrollerHolder),
                    {
                      marginTop: "".concat(
                        0.9375 * n.scrollViewItemHeight,
                        "px"
                      ),
                    }
                  )),
                  (n.topMaskStyle = f(f({}, n.mask), {
                    backgroundColor: "rgb(48, 48, 61)",
                    height: "".concat(1.90625 * n.scrollViewItemHeight, "px"),
                    width: "100%",
                  })),
                  (n.btmMaskStyle = f(f({}, n.mask), {
                    backgroundColor: "rgb(48, 48, 61)",
                    marginTop: "".concat(
                      3.09375 * n.scrollViewItemHeight,
                      "px"
                    ),
                    height: "".concat(2 * n.scrollViewItemHeight, "px"),
                    width: "100%",
                  })),
                  (n.topGradientMaskStyle = f(f({}, n.baseTopGradientMask), {
                    background:
                      "linear-gradient(180deg, rgb(48, 48, 61) 10%, rgba(48, 48, 61, 0.03))",
                    width: "100%",
                  })),
                  (n.btmGradientMaskStyle = f(f({}, n.baseBtmGradientMask), {
                    background:
                      "linear-gradient(0deg, rgb(48, 48, 61) 10%, rgba(48, 48, 61, 0.03))",
                    width: "100%",
                  })),
                  n
                );
              }
              return h(n, t), n;
            })(hn),
            gn = (function (t) {
              function n() {
                return (null !== t && t.apply(this, arguments)) || this;
              }
              return (
                h(n, t),
                (n.prototype.footerStyle = function (t) {
                  var n = this.betOptFooter(t);
                  return f(f({}, n), {
                    marginBottom: "10px",
                    marginTop: "20px",
                    marginLeft: "10px",
                    marginRight: "10px",
                  });
                }),
                (n.prototype.betOptViewStyle = function () {
                  return {
                    borderRadius: "0px",
                    backgroundColor: "rgb(48, 48, 61)",
                    height: ln.isMaxPayoutEnable() ? "79%" : "68.4%",
                  };
                }),
                (n.prototype.reminderBoardStyle = function () {
                  return {};
                }),
                n
              );
            })(fn),
            mn = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (
                  (n.spinOptContStyle = { padding: "10px" }),
                  (n.spinAmtSelectStyle = f(f({}, an.spinAmtSelect), {
                    height: "68px",
                    paddingTop: "8px",
                    paddingBottom: "5px",
                  })),
                  n
                );
              }
              return (
                h(n, t),
                Object.defineProperty(n.prototype, "turboSpinSelect", {
                  get: function () {
                    return {
                      paddingTop: "10px",
                      paddingLeft: "10px",
                      paddingRight: "10px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "turboSpinInnerLayer", {
                  get: function () {
                    return {
                      backgroundColor: "rgb(49, 49, 60)",
                      paddingLeft: "15px",
                      paddingRight: "15px",
                      paddingTop: "8px",
                      paddingBottom: "8px",
                      height: "68px",
                      display: "flex",
                      justifyContent: "space-between",
                      flexDirection: "column",
                      border: "thin solid rgb(40, 40, 50)",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "turboSpinInnerItem", {
                  get: function () {
                    return {
                      textAlign: "left",
                      fontSize: "14px",
                      color: "rgba(255, 255, 255, 0.8)",
                      display: "flex",
                      flexDirection: "row",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "turboSpinOnOff", {
                  get: function () {
                    return { width: "25px", height: "25px" };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "turboSpinTitle", {
                  get: function () {
                    return {
                      marginTop: "auto",
                      marginBottom: "auto",
                      paddingLeft: Kt.isRTL ? "0px" : "5px",
                      paddingRight: Kt.isRTL ? "5px" : "0px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "spinOptContInner", {
                  get: function () {
                    return {
                      backgroundColor: "rgb(49, 49, 60)",
                      paddingLeft: "15px",
                      paddingRight: "15px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "startAutoSpin", {
                  get: function () {
                    return {
                      fontSize: "14px",
                      paddingTop: "15px",
                      paddingBottom: "15px",
                      display: "flex",
                      justifyContent: "space-between",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (n.prototype.spinOptViewStyle = function () {
                  return {
                    borderRadius: "0px 0px 0px 0px",
                    backgroundColor: "rgb(48, 48, 61)",
                    transition:
                      "transform 200ms cubic-bezier(0.215, 0.61, 0.355, 1)",
                    height: this.ft(),
                  };
                }),
                (n.prototype.ft = function () {
                  var t = ln.isTurboSpinEnable();
                  return cn.isAutoSpinStop
                    ? t
                      ? "64.2%"
                      : "49%"
                    : !cn.isAutoSpinStop && t
                    ? "47.7%"
                    : "32.5%";
                }),
                n
              );
            })(dn),
            xn = (function () {
              function t() {}
              return (
                (t.prototype.footerHolder = function (t) {
                  return f(f({}, an.footerHolderCont), {
                    marginTop: "0px",
                    borderTopStyle: "solid",
                    borderTopColor: "rgba(56, 55, 64, 0.7)",
                    borderWidth: "1px",
                    justifyContent: "space-between",
                    backgroundColor: t ? "rgba(40, 40, 51, 1)" : void 0,
                  });
                }),
                Object.defineProperty(t.prototype, "footerObj", {
                  get: function () {
                    return f(f({}, an.footerObjCont), {
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      justifyContent: "space-between",
                      width: "auto",
                      paddingLeft: "5px",
                      direction: Kt.isRTL ? "rtl" : "ltr",
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "footerAmt", {
                  get: function () {
                    return f(f({}, an.footerAmtCont), { width: "auto" });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "flexFooterAmot", {
                  get: function () {
                    return f(f({}, this.footerAmt), {
                      justifyContent: "flex-end",
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "footerAmtItem", {
                  get: function () {
                    return {
                      alignSelf: "center",
                      color: "white",
                      fontSize: "11px",
                      marginTop: "auto",
                      marginBottom: "auto",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "fullFooterAmtItem", {
                  get: function () {
                    return f(f({}, this.footerAmtItem), { opacity: 1 });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "halfFooterAmtItem", {
                  get: function () {
                    return f(f({}, this.footerAmtItem), { opacity: 0.5 });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.transFooterObj = function (t) {
                  return f(f({}, this.footerObj), {
                    transition:
                      "transform 0.1s cubic-bezier(0.39, 0.575, 0.565, 1) 0s",
                    transform: t ? "scale(1,1)" : "scale(1,0)",
                  });
                }),
                Object.defineProperty(t.prototype, "footerImg", {
                  get: function () {
                    return f(f({}, an.footerImgCont), {
                      width: "15px",
                      height: "15px",
                      opacity: "0.5",
                      alignSelf: "center",
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                t
              );
            })(),
            yn = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (
                  (n.dt = f(f({}, n.exitBtn), {
                    margin: "7px",
                    width: "36px",
                    height: "36px",
                    backgroundSize: "120px 120px",
                    backgroundPosition: "-57px -57px",
                  })),
                  n
                );
              }
              return (
                h(n, t),
                (n.prototype.betOptExitBtnStyle = function (t) {
                  return f(f({}, this.dt), {
                    pointerEvents: t ? "auto" : "none",
                    opacity: t ? 0.6 : 0.3,
                  });
                }),
                (n.prototype.maxBetBtnStyle = function (t) {
                  var n = un.themeColor,
                    e = un.halfThemeColor;
                  return f(f({}, this.baseBtn), {
                    pointerEvents: t ? "auto" : "none",
                    color: t ? n : e,
                    width: "30%",
                    height: "43px",
                    borderStyle: "solid",
                    backgroundColor: t
                      ? "rgba(57,58,70,1)"
                      : "rgba(57,58,70,0.5)",
                    borderRadius: "2px",
                    fontSize: "".concat(nn, "px"),
                  });
                }),
                (n.prototype.confrimBtnStyle = function (t) {
                  var n = un.themeColor,
                    e = un.halfThemeColor,
                    i = un.spinStartLabelColor,
                    o = un.spinStartLabelHalfColor;
                  return f(f({}, this.baseBtn), {
                    pointerEvents: t ? "auto" : "none",
                    backgroundColor: t ? n : e,
                    color: t ? i : o,
                    width: "67%",
                    height: "43px",
                    borderRadius: "2px",
                    fontSize: "".concat(nn, "px"),
                  });
                }),
                (n.prototype.spinOptExitBtnStyle = function () {
                  return this.dt;
                }),
                (n.prototype.autoSpinAmtBtnStyle = function (t) {
                  return f(f({}, this.baseBtn), {
                    color: "".concat(t),
                    borderRadius: "2px",
                    width: "54px",
                    height: "35px",
                    lineHeight: "35px",
                    fontSize: "14px",
                    position: "relative",
                  });
                }),
                (n.prototype.startAutoSpinBtn = function (t) {
                  var n = un.normalButtonColor,
                    e = un.disabledButtonColorHalfOpacity,
                    i = un.disabledButtonColor,
                    o = un.spinStartLabelColor,
                    r = un.disabledSpinStartLabelColor;
                  return f(f({}, this.baseBtn), {
                    borderRadius: "2px",
                    pointerEvents: t ? "auto" : "none",
                    border: t ? n : e,
                    backgroundColor: t ? n : i,
                    color: t ? o : r,
                    width: "100%",
                  });
                }),
                Object.defineProperty(n.prototype, "highlightTSBtn", {
                  get: function () {
                    var t = un.normalButtonColor;
                    return {
                      backgroundColor: t,
                      borderColor: t,
                      color: un.spinStartLabelColor,
                      borderStyle: "solid",
                      borderWidth: "thin",
                      width: "48%",
                      borderRadius: "2px",
                      height: "35px",
                      lineHeight: "35px",
                      fontSize: "14px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "normalTSBtn", {
                  get: function () {
                    return {
                      width: "48%",
                      borderRadius: "2px",
                      borderColor: "rgb(38, 38, 51)",
                      borderStyle: "solid",
                      borderWidth: "thin",
                      height: "35px",
                      lineHeight: "35px",
                      fontSize: "14px",
                    };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                n
              );
            })(bn),
            Sn = (function (t) {
              function n() {
                return (null !== t && t.apply(this, arguments)) || this;
              }
              return (
                h(n, t),
                (n.prototype.sliderStyle = function (t, n) {
                  return f(f({}, this.baseSlider()), {
                    pointerEvents: t ? "none" : "auto",
                    height: n ? "28px" : "50px",
                  });
                }),
                (n.prototype.titleHolderStyle = function (t) {
                  return f(f({}, this.baseTitleHolder), {
                    fontSize: "11px",
                    height: "30px",
                    minHeight: "30px",
                    opacity: "".concat(t),
                  });
                }),
                n
              );
            })(pn),
            wn = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (
                  (n.betOptContViewStyle = {
                    width: "100%",
                    backgroundColor: "rgb(40, 40, 51)",
                    height: "auto",
                    direction: Kt.isRTL ? "rtl" : "ltr",
                  }),
                  (n.betSelectorStyle = f(f({}, n.baseBetSelector), {
                    backgroundColor: "rgb(48, 48, 61)",
                    width: "96%",
                    borderRadius: "8px",
                    marginLeft: "5px",
                    marginRight: "4px",
                    marginTop: "".concat(1.875 * n.scrollViewItemHeight, "px"),
                  })),
                  (n.betScrollerHolderStyle = n.baseBetScrollerHolder),
                  (n.topMaskStyle = f(f({}, n.mask), {
                    backgroundColor: "rgb(40, 40, 51)",
                    height: "".concat(1.90625 * n.scrollViewItemHeight, "px"),
                    width: "91%",
                  })),
                  (n.btmMaskStyle = f(f({}, n.mask), {
                    backgroundColor: "rgb(40, 40, 51)",
                    marginTop: "".concat(
                      3.09375 * n.scrollViewItemHeight,
                      "px"
                    ),
                    height: "".concat(2 * n.scrollViewItemHeight, "px"),
                    width: "91%",
                  })),
                  (n.topGradientMaskStyle = f(f({}, n.baseTopGradientMask), {
                    background:
                      "linear-gradient(180deg, rgb(40, 40, 51) 10%, rgba(40, 40, 51, 0.03))",
                    width: "91%",
                  })),
                  (n.btmGradientMaskStyle = f(f({}, n.baseBtmGradientMask), {
                    background:
                      "linear-gradient(0deg, rgb(40, 40, 51) 10%, rgba(40, 40, 51, 0.03))",
                    width: "91%",
                  })),
                  n
                );
              }
              return h(n, t), n;
            })(hn),
            On = (function (t) {
              function n() {
                return (null !== t && t.apply(this, arguments)) || this;
              }
              return (
                h(n, t),
                (n.prototype.footerStyle = function (t) {
                  var n = this.betOptFooter(t);
                  return f(f({}, n), {
                    marginTop: "".concat(
                      $t || ln.isMaxPayoutEnable() ? "10px" : "20px"
                    ),
                    marginLeft: "10px",
                    marginRight: "10px",
                  });
                }),
                (n.prototype.reminderBoardStyle = function () {
                  return $t
                    ? {
                        margin: "auto",
                        paddingTop: "43%",
                        height: "100%",
                        width: "40%",
                        backgroundColor: "rgb(0,0,0,0)",
                        borderColor: "rgb(0,0,0,0)",
                      }
                    : {};
                }),
                (n.prototype.betOptViewStyle = function () {
                  var t = {
                    borderRadius: "8px 8px 0px 0px",
                    backgroundColor: "rgb(48, 48, 60)",
                    height: ln.isMaxPayoutEnable() ? "62%" : "53.6%",
                  };
                  return $t
                    ? f(f({}, t), {
                        height: "100%",
                        width: "45%",
                        marginLeft: "60%",
                        borderRadius: "0px",
                      })
                    : t;
                }),
                n
              );
            })(fn),
            Cn = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (
                  (n.spinOptContStyle = {
                    paddingLeft: "20px",
                    paddingRight: "20px",
                  }),
                  (n.spinAmtSelectStyle = f(f({}, an.spinAmtSelect), {
                    height: "".concat($t ? 50 : 68),
                  })),
                  n
                );
              }
              return (
                h(n, t),
                Object.defineProperty(n.prototype, "spinOptHeader", {
                  get: function () {
                    return f(f({}, an.spinOptHeader), {
                      marginTop: "".concat($t ? 10 : 0, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "slotMenuTitle", {
                  get: function () {
                    var t = tn;
                    return f(f({}, an.slotMenuTitleTxt), {
                      fontSize: "".concat(t, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(n.prototype, "spinOptSubtitle", {
                  get: function () {
                    return f(f({}, an.spinOptSubtitleHolder), {
                      fontSize: "".concat($t ? 10 : 12.5, "px"),
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (n.prototype.spinOptViewStyle = function (t) {
                  var n = { backgroundColor: "rgb(48, 48, 60)" };
                  return f(
                    f({}, n),
                    $t
                      ? {
                          height: "100%",
                          width: "45%",
                          marginLeft: "60%",
                          borderRadius: "0px",
                          bottom: "0%",
                        }
                      : {
                          height: cn.isAutoSpinStop
                            ? t === Vt.Expanded
                              ? "69.2%"
                              : "43%"
                            : "29.5%",
                        }
                  );
                }),
                n
              );
            })(dn),
            kn = (function () {
              function t() {}
              return (
                Object.defineProperty(t.prototype, "footerAmt", {
                  get: function () {
                    return { alignSelf: "center", color: "white" };
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.footerObj = function (t) {
                  return f(f({}, an.footerObjCont), {
                    transition:
                      "transform 0.1s cubic-bezier(0.39, 0.575, 0.565, 1) 0s",
                    transform: t ? "scale(1,1)" : "scale(1,0)",
                  });
                }),
                t
              );
            })(),
            _n = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (
                  (n.bt = f(f({}, n.exitBtn), {
                    width: "54px",
                    height: "54px",
                    backgroundSize: "184px 64px",
                    backgroundPosition: "-1px -1px",
                    transform: "scale(0.67)",
                  })),
                  n
                );
              }
              return (
                h(n, t),
                (n.prototype.betOptExitBtnStyle = function (t) {
                  var n = f(f({}, this.bt), {
                    pointerEvents: t ? "auto" : "none",
                    opacity: t ? 0.6 : 0.3,
                  });
                  return (
                    $t &&
                      (n = f(f({}, n), {
                        transform: "scale(0.5625)",
                        marginTop: "-3px",
                      })),
                    n
                  );
                }),
                (n.prototype.maxBetBtnStyle = function (t) {
                  var n = un.themeColor,
                    e = un.halfThemeColor;
                  return f(f({}, this.baseBtn), {
                    pointerEvents: t ? "auto" : "none",
                    color: t ? n : e,
                    width: "30%",
                    height: $t ? "25px" : "40px",
                    borderRadius: $t ? "4px" : "8px",
                    borderStyle: "solid",
                    borderWidth: $t ? "1px" : "2px",
                    borderColor: t ? n : e,
                    fontSize: "".concat(nn, "px"),
                  });
                }),
                (n.prototype.confrimBtnStyle = function (t) {
                  var n = un.themeColor,
                    e = un.halfThemeColor,
                    i = un.spinStartLabelColor,
                    o = un.spinStartLabelHalfColor;
                  return f(f({}, this.baseBtn), {
                    pointerEvents: t ? "auto" : "none",
                    backgroundColor: t ? n : e,
                    color: t ? i : o,
                    width: "67%",
                    height: $t ? "27px" : "40px",
                    fontSize: "".concat(nn, "px"),
                    borderRadius: $t ? "4px" : "8px",
                  });
                }),
                (n.prototype.spinOptExitBtnStyle = function () {
                  var t = this.bt;
                  return (
                    $t &&
                      (t = f(f({}, this.bt), {
                        transform: "scale(0.5625)",
                        marginTop: "-3px",
                      })),
                    t
                  );
                }),
                (n.prototype.autoSpinAmtBtnStyle = function (t) {
                  return f(f({}, this.baseBtn), {
                    color: "".concat(t),
                    height: $t ? "27px" : "38px",
                  });
                }),
                Object.defineProperty(n.prototype, "spinOptBtn", {
                  get: function () {
                    return f(f({}, this.baseBtn), {
                      transition: "0.2s",
                      color: "rgba(255, 255, 255, 0.6)",
                      width: "33%",
                      height: $t ? "27px" : "38px",
                      borderRadius: $t ? "4px" : "8px",
                    });
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (n.prototype.autoSpinsBtn = function (t) {
                  var n = un.normalButtonColor,
                    e = un.disabledButtonColorHalfOpacity,
                    i = un.disabledButtonColor,
                    o = un.disabledSpinStartLabelColor,
                    r = un.spinStartLabelColor;
                  return f(f({}, this.baseBtn), {
                    pointerEvents: t ? "auto" : "none",
                    border: t ? n : e,
                    backgroundColor: t ? n : i,
                    color: t ? r : o,
                    width: cn.isAutoSpinStop ? "63%" : "100%",
                    height: $t ? "27px" : "38px",
                    borderRadius: $t ? "4px" : "8px",
                  });
                }),
                n
              );
            })(bn),
            jn = (function (t) {
              function n() {
                return (null !== t && t.apply(this, arguments)) || this;
              }
              return (
                h(n, t),
                (n.prototype.sliderStyle = function (t) {
                  return f(f({}, this.baseSlider()), {
                    pointerEvents: t ? "none" : "auto",
                    height: $t ? "55px" : "84px",
                  });
                }),
                (n.prototype.titleHolderStyle = function (t) {
                  var n = f(f({}, this.baseTitleHolder), {
                      fontSize: "11px",
                      height: "30px",
                      minHeight: "30px",
                      opacity: "".concat(t),
                    }),
                    e = f(f({}, this.baseTitleHolder), {
                      fontSize: "9.75px",
                      height: "20px",
                      minHeight: "20px",
                      opacity: "".concat(t),
                    });
                  return $t ? e : n;
                }),
                n
              );
            })(pn),
            Mn = Ft.formatCurrency,
            Tn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.vt = r.createRef()),
                  (e.gt = !1),
                  (e.xt = !1),
                  (e.yt = 0),
                  (e.St = "None"),
                  (e.wt = void 0),
                  (e.Ot = 0),
                  (e.handleChange = function (t) {
                    (e.gt = !0),
                      !1 === e.xt &&
                        (e.props.enableStartAutoSpin(), (e.xt = !0)),
                      e.setState({ value: t });
                  }),
                  (e.state = { value: 0, scale: 1 }),
                  (e.wt = r.createRef()),
                  (e.Ot = 10);
                var i = cn.isLegacyMode;
                return (e.Ct = i ? new Sn() : new jn()), e;
              }
              return (
                h(n, t),
                (n.prototype.onFinishTouch = function () {
                  if (this.state.value % this.Ot != 0) {
                    var t = Math.round(this.state.value / this.Ot) * this.Ot;
                    this.setState({ value: t });
                  }
                }),
                (n.prototype.kt = function () {
                  this.props.onClick(Xt.BalanceLessThan);
                }),
                (n.prototype._t = function (t, n) {
                  var e = this.props.model,
                    i = (0, e.additionalBetCalculationCallback)(
                      cn.betLineValue,
                      cn.betLevelValue,
                      cn.betSizeValue
                    ),
                    o = Math.round(t / this.Ot),
                    r = i * e.autoSpinCount * (1 - (n - o) / 100);
                  return (e.balanceAmountLessThan = r), r;
                }),
                (n.prototype.jt = function () {
                  var t = this.props.selectedSlider,
                    n = shell.I18n.t("SpinOptions.SettingSliderNumNone"),
                    e = shell.I18n.t("SpinOptions.ChooseValue");
                  return (
                    (this.St = Mn(this.yt)),
                    this.gt
                      ? this.St
                      : cn.isLegacyMode && t !== Xt.BalanceLessThan
                      ? e
                      : n
                  );
                }),
                (n.prototype.Mt = function () {
                  var t = this.props.selectedSlider,
                    n = un.disabledLabelColor,
                    e = un.labelColor;
                  return cn.isLegacyMode && t !== Xt.BalanceLessThan && !this.gt
                    ? n
                    : e;
                }),
                (n.prototype.Tt = function (t) {
                  this.setState({ scale: t.payload.scale });
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  this.vt.current &&
                    cn.isLegacyMode &&
                    this.vt.current.addEventListener(
                      Kt.clickEvent,
                      this.kt.bind(this)
                    ),
                    Kt.context.event.emit(
                      "Shell.GetScale",
                      void 0,
                      function (n) {
                        n.error || t.setState({ scale: n.response.scale });
                      }
                    ),
                    Kt.context.event.on("Shell.Scaled", this.Tt, this),
                    Gt(this.wt.current, 11);
                }),
                (n.prototype.componentDidUpdate = function () {
                  Gt(this.wt.current, 11);
                }),
                (n.prototype.componentWillUnmount = function () {
                  Kt.context.event.off("Shell.Scaled", this.Tt, this);
                }),
                (n.prototype.render = function () {
                  var t = this.state,
                    n = t.value,
                    e = t.scale,
                    i = this.props,
                    o = i.config,
                    s = i.isDisabled,
                    a = i.selectedSlider,
                    u = shell.I18n.t("SpinOptions.OnceCashLessThanTitle"),
                    l = shell.I18n.t("SpinOptions.RequiredTitle");
                  this.yt = this._t(n, o.max);
                  var c = cn.isLegacyMode && a !== Xt.BalanceLessThan,
                    h = Ht(cn.gameThemeColor),
                    f = this.Ct.slider(s, a !== Xt.BalanceLessThan),
                    d = this.Ct.titleHolder(s ? 0.5 : 1),
                    b = this.Ct.mainTitle,
                    p = this.Ct.resizeContainer(this.Mt()),
                    v = un.sliderLineColorFalse,
                    g = un.sliderLineColorTrue;
                  return r.createElement(
                    "div",
                    { className: "spin-options-slider", style: f },
                    r.createElement(
                      "div",
                      {
                        style: d,
                        className: "so-slider-title-holder",
                        ref: this.vt,
                      },
                      r.createElement(
                        "div",
                        { style: b, className: "so-slider-main-title" },
                        r.createElement(
                          "div",
                          null,
                          u + " ",
                          r.createElement("span", { style: { color: h } }, l)
                        )
                      ),
                      r.createElement(
                        "div",
                        { style: p, className: "resize-container" },
                        r.createElement(
                          "div",
                          {
                            ref: this.wt,
                            className: "resize-content",
                            style: { alignSelf: "center" },
                          },
                          this.jt()
                        )
                      )
                    ),
                    r.createElement(
                      "div",
                      {
                        className: "".concat(
                          Kt.isRTL ? "rtl" : "ltr",
                          "-slider-holder"
                        ),
                      },
                      r.createElement(
                        "div",
                        {
                          className: "slider-horizontal",
                          style: { pointerEvents: s || c ? "none" : "auto" },
                        },
                        r.createElement(At, {
                          isDisabled: s,
                          backgroundColor: v,
                          fillColor: g,
                          handleColor: Ht(cn.gameThemeColor),
                          scale: e,
                          min: o.min,
                          max: o.max * this.Ot,
                          value: n,
                          tooltip: !1,
                          orientation: "horizontal",
                          onChange: this.handleChange,
                          onChangeComplete: this.onFinishTouch.bind(this),
                          labels: !cn.isLegacyMode && {},
                          reverse: Kt.isRTL,
                        })
                      )
                    )
                  );
                }),
                n
              );
            })(r.Component),
            An = Ft.tickCallback,
            Bn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.wt = r.createRef()),
                  (e.At = r.createRef()),
                  (e.state = { onHover: !1 }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.Bt = function () {
                  this.Nt(), this.props.callback();
                }),
                (n.prototype.render = function () {
                  var t = this,
                    n = this.props,
                    e = n.additionalStyle,
                    i = n.buttonText,
                    o = n.bottomHighlight,
                    s = n.hoverEffect,
                    a = n.hoverColor,
                    u = n.id,
                    l = s ? { color: this.state.onHover ? a : e.color } : {},
                    c = f(f({}, e), l);
                  return r.createElement(
                    "div",
                    {
                      id: u,
                      ref: this.At,
                      className: "spin-amount-button",
                      style: c,
                      onTouchStart: function () {
                        t.zt(), t.Rt();
                      },
                      onClick: function () {
                        t.Nt();
                      },
                      onMouseEnter: this.Rt.bind(this),
                      onMouseLeave: this.Nt.bind(this),
                    },
                    o
                      ? r.createElement("div", {
                          style: {
                            position: "absolute",
                            width: "inherit",
                            height: "33px",
                            top: "0px",
                            left: "0px",
                            borderRadius: "2px",
                            borderBottom: "2px solid blue",
                            borderColor: e.color,
                          },
                        })
                      : null,
                    r.createElement(
                      "div",
                      { className: "spin-amount-button-text", ref: this.wt },
                      i
                    )
                  );
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  this.At &&
                    this.At.current &&
                    this.At.current.addEventListener(
                      Kt.clickEvent,
                      this.Bt.bind(this)
                    ),
                    An(!0)(function () {
                      var n = t.props.defaultFontSize,
                        e = 16;
                      n && (e = n),
                        t.wt && t.wt.current && Gt(t.wt.current, e),
                        t.wt &&
                          t.wt.current &&
                          (function (t) {
                            if (t.offsetHeight > t.parentElement.offsetHeight)
                              for (
                                var n = parseInt(
                                  i.getComputedStyle(t).fontSize,
                                  10
                                );
                                t.offsetHeight > t.parentElement.offsetHeight;

                              )
                                (n -= 1),
                                  (t.style.lineHeight = n.toString() + "px"),
                                  (t.style.fontSize = n.toString() + "px");
                          })(t.wt.current);
                    });
                }),
                (n.prototype.componentWillUnmount = function () {
                  this.At &&
                    this.At.current &&
                    this.At.current.removeEventListener(
                      Kt.clickEvent,
                      this.Bt.bind(this)
                    );
                }),
                (n.prototype.Rt = function () {
                  this.props.hoverEffect &&
                    (this.zt(), this.setState({ onHover: !0 }));
                }),
                (n.prototype.Nt = function () {
                  this.props.hoverEffect && this.setState({ onHover: !1 });
                }),
                (n.prototype.zt = function () {
                  this.props.resetHoverCallback &&
                    this.props.resetHoverCallback();
                }),
                (n.prototype.disableHoverEffect = function () {
                  this.state.onHover && this.Nt();
                }),
                n
              );
            })(r.Component),
            Nn = Ft.formatCurrency,
            zn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.vt = r.createRef()),
                  (e.yt = 0),
                  (e.St = "None"),
                  (e.wt = void 0),
                  (e.Ot = 0),
                  (e.handleChange = function (t) {
                    e.setState({ value: t });
                  }),
                  (e.Ot = 10),
                  (e.state = { value: e.Lt() * e.Ot, scale: 1 }),
                  (e.wt = r.createRef());
                var i = cn.isLegacyMode;
                return (e.Ct = i ? new Sn() : new jn()), e;
              }
              return (
                h(n, t),
                (n.prototype.onFinishTouch = function () {
                  if (this.state.value % this.Ot != 0) {
                    var t = Math.round(this.state.value / this.Ot) * this.Ot;
                    this.setState({ value: t });
                  }
                }),
                (n.prototype.kt = function () {
                  this.props.onClick(Xt.BalanceMoreThan);
                }),
                (n.prototype.Dt = function () {
                  var t = this.props.model,
                    n = (0, t.additionalBetCalculationCallback)(
                      cn.betLineValue,
                      cn.betLevelValue,
                      cn.betSizeValue
                    ),
                    e = 100 * Math.round(this.state.value / this.Ot) * n;
                  return (t.balanceAmountMoreThan = e), e;
                }),
                (n.prototype.Lt = function () {
                  var t = this.props.model,
                    n = 0;
                  if (t.balanceAmountMoreThan) {
                    var e = (0, t.additionalBetCalculationCallback)(
                      cn.betLineValue,
                      cn.betLevelValue,
                      cn.betSizeValue
                    );
                    n = t.balanceAmountMoreThan / e / 100;
                  }
                  return n;
                }),
                (n.prototype.jt = function () {
                  var t = this.props.selectedSlider,
                    n = shell.I18n.t("SpinOptions.SettingSliderNumNone"),
                    e = shell.I18n.t("SpinOptions.ChooseValue");
                  return (
                    (this.St = Nn(this.yt)),
                    this.yt > 0
                      ? this.St
                      : cn.isLegacyMode && t !== Xt.BalanceMoreThan
                      ? e
                      : n
                  );
                }),
                (n.prototype.Mt = function () {
                  var t = this.props.selectedSlider,
                    n = un.disabledLabelColor,
                    e = un.labelColor;
                  return cn.isLegacyMode &&
                    t !== Xt.BalanceMoreThan &&
                    this.yt < 1
                    ? n
                    : e;
                }),
                (n.prototype.Tt = function (t) {
                  this.setState({ scale: t.payload.scale });
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  this.vt.current &&
                    cn.isLegacyMode &&
                    this.vt.current.addEventListener(
                      Kt.clickEvent,
                      this.kt.bind(this)
                    ),
                    Kt.context.event.emit(
                      "Shell.GetScale",
                      void 0,
                      function (n) {
                        n.error || t.setState({ scale: n.response.scale });
                      }
                    ),
                    Kt.context.event.on("Shell.Scaled", this.Tt, this),
                    Gt(this.wt.current, 11);
                }),
                (n.prototype.componentDidUpdate = function () {
                  Gt(this.wt.current, 11);
                }),
                (n.prototype.componentWillUnmount = function () {
                  Kt.context.event.off("Shell.Scaled", this.Tt, this);
                }),
                (n.prototype.render = function () {
                  var t = this.state,
                    n = t.value,
                    e = t.scale,
                    i = this.props,
                    o = i.config,
                    s = i.isDisabled,
                    a = i.selectedSlider,
                    u = shell.I18n.t("SpinOptions.OnceCashMoreThanTitle");
                  (this.yt = this.Dt(n)), (this.St = Nn(this.yt));
                  var l = cn.isLegacyMode && a !== Xt.BalanceMoreThan,
                    c = this.Ct.slider(s, a !== Xt.BalanceMoreThan),
                    h = this.Ct.titleHolder(s ? 0.5 : 1),
                    f = this.Ct.mainTitle,
                    d = this.Ct.resizeContainer(this.Mt()),
                    b = un.sliderLineColorFalse,
                    p = un.sliderLineColorTrue;
                  return r.createElement(
                    "div",
                    { className: "spin-options-slider", style: c },
                    r.createElement(
                      "div",
                      {
                        style: h,
                        className: "so-slider-title-holder",
                        ref: this.vt,
                      },
                      r.createElement(
                        "div",
                        { style: f, className: "so-slider-main-title" },
                        r.createElement("div", null, u)
                      ),
                      r.createElement(
                        "div",
                        { style: d, className: "resize-container" },
                        r.createElement(
                          "div",
                          {
                            ref: this.wt,
                            className: "resize-content",
                            style: { alignSelf: "center" },
                          },
                          this.jt()
                        )
                      )
                    ),
                    r.createElement(
                      "div",
                      {
                        className: "".concat(
                          Kt.isRTL ? "rtl" : "ltr",
                          "-slider-holder"
                        ),
                      },
                      r.createElement(
                        "div",
                        {
                          className: "slider-horizontal",
                          style: { pointerEvents: s || l ? "none" : "auto" },
                        },
                        r.createElement(At, {
                          isDisabled: s,
                          backgroundColor: b,
                          fillColor: p,
                          handleColor: Ht(cn.gameThemeColor),
                          scale: e,
                          min: o.min,
                          max: o.max * this.Ot,
                          value: n,
                          tooltip: !1,
                          orientation: "horizontal",
                          onChange: this.handleChange,
                          onChangeComplete: this.onFinishTouch.bind(this),
                          labels: !cn.isLegacyMode && {},
                          reverse: Kt.isRTL,
                        })
                      )
                    )
                  );
                }),
                n
              );
            })(r.Component),
            Rn = Ft.formatCurrency,
            Ln = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.vt = r.createRef()),
                  (e.yt = 0),
                  (e.St = "None"),
                  (e.wt = void 0),
                  (e.Ot = 0),
                  (e.handleChange = function (t) {
                    e.setState({ value: t });
                  }),
                  (e.Ot = 10),
                  (e.state = { value: e.Lt() * e.Ot, scale: 1 }),
                  (e.wt = r.createRef());
                var i = cn.isLegacyMode;
                return (e.Ct = i ? new Sn() : new jn()), e;
              }
              return (
                h(n, t),
                (n.prototype.onFinishTouch = function () {
                  if (this.state.value % this.Ot != 0) {
                    var t = Math.round(this.state.value / this.Ot) * this.Ot;
                    this.setState({ value: t });
                  }
                }),
                (n.prototype.kt = function () {
                  this.props.onClick(Xt.SingleWinMoreThan);
                }),
                (n.prototype.Dt = function () {
                  var t = this.props.model,
                    n = (0, t.additionalBetCalculationCallback)(
                      cn.betLineValue,
                      cn.betLevelValue,
                      cn.betSizeValue
                    ),
                    e = 10 * Math.round(this.state.value / this.Ot) * n;
                  return (t.singleWinAmount = Ft.toDecimalWithExp(e, 2)), e;
                }),
                (n.prototype.Lt = function () {
                  var t = this.props.model,
                    n = 0;
                  if (t.singleWinAmount) {
                    var e = (0, t.additionalBetCalculationCallback)(
                      cn.betLineValue,
                      cn.betLevelValue,
                      cn.betSizeValue
                    );
                    n = t.singleWinAmount / e / 10;
                  }
                  return n;
                }),
                (n.prototype.jt = function () {
                  var t = this.props.selectedSlider,
                    n = shell.I18n.t("SpinOptions.SettingSliderNumNone"),
                    e = shell.I18n.t("SpinOptions.ChooseValue");
                  return (
                    (this.St = Rn(this.yt)),
                    this.yt > 0
                      ? this.St
                      : cn.isLegacyMode && t !== Xt.SingleWinMoreThan
                      ? e
                      : n
                  );
                }),
                (n.prototype.Mt = function () {
                  var t = this.props.selectedSlider,
                    n = un.disabledLabelColor,
                    e = un.labelColor;
                  return cn.isLegacyMode &&
                    t !== Xt.SingleWinMoreThan &&
                    this.yt < 1
                    ? n
                    : e;
                }),
                (n.prototype.Tt = function (t) {
                  this.setState({ scale: t.payload.scale });
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  this.vt.current &&
                    cn.isLegacyMode &&
                    this.vt.current.addEventListener(
                      Kt.clickEvent,
                      this.kt.bind(this)
                    ),
                    Kt.context.event.emit(
                      "Shell.GetScale",
                      void 0,
                      function (n) {
                        n.error || t.setState({ scale: n.response.scale });
                      }
                    ),
                    Kt.context.event.on("Shell.Scaled", this.Tt, this),
                    Gt(this.wt.current, 11);
                }),
                (n.prototype.componentDidUpdate = function () {
                  Gt(this.wt.current, 11);
                }),
                (n.prototype.componentWillUnmount = function () {
                  Kt.context.event.off("Shell.Scaled", this.Tt, this);
                }),
                (n.prototype.render = function () {
                  var t = this.state,
                    n = t.value,
                    e = t.scale,
                    i = this.props,
                    o = i.config,
                    s = i.isDisabled,
                    a = i.selectedSlider,
                    u = shell.I18n.t("SpinOptions.OnceWinAmountTargetTitle");
                  (this.yt = this.Dt(n)), (this.St = Rn(this.yt));
                  var l = cn.isLegacyMode && a !== Xt.SingleWinMoreThan,
                    c = this.Ct.slider(s, a !== Xt.SingleWinMoreThan),
                    h = this.Ct.titleHolder(s ? 0.5 : 1),
                    f = this.Ct.mainTitle,
                    d = this.Ct.resizeContainer(this.Mt()),
                    b = un.sliderLineColorFalse,
                    p = un.sliderLineColorTrue;
                  return r.createElement(
                    "div",
                    { className: "spin-options-slider", style: c },
                    r.createElement(
                      "div",
                      { style: h, ref: this.vt },
                      r.createElement(
                        "div",
                        { style: f, className: "so-slider-main-title" },
                        r.createElement("div", null, u)
                      ),
                      r.createElement(
                        "div",
                        { style: d, className: "resize-container" },
                        r.createElement(
                          "div",
                          {
                            ref: this.wt,
                            className: "resize-content",
                            style: { alignSelf: "center" },
                          },
                          this.jt()
                        )
                      )
                    ),
                    r.createElement(
                      "div",
                      {
                        className: "".concat(
                          Kt.isRTL ? "rtl" : "ltr",
                          "-slider-holder"
                        ),
                      },
                      r.createElement(
                        "div",
                        {
                          className: "slider-horizontal",
                          style: { pointerEvents: s || l ? "none" : "auto" },
                        },
                        r.createElement(At, {
                          isDisabled: s,
                          backgroundColor: b,
                          fillColor: p,
                          handleColor: Ht(cn.gameThemeColor),
                          scale: e,
                          min: o.min,
                          max: o.max * this.Ot,
                          value: n,
                          tooltip: !1,
                          orientation: "horizontal",
                          onChange: this.handleChange,
                          onChangeComplete: this.onFinishTouch.bind(this),
                          labels: !cn.isLegacyMode && {},
                          reverse: Kt.isRTL,
                        })
                      )
                    )
                  );
                }),
                n
              );
            })(r.Component),
            Dn = Ft.formatCurrency;
          !(function (t) {
            (t[(t.Win = 0)] = "Win"), (t[(t.Other = 1)] = "Other");
          })(sn || (sn = {}));
          var Pn,
            En = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.Pt = []),
                  (e.Et = void 0),
                  (e.It = void 0),
                  (e.Ft = new kn()),
                  (e.Gt = an);
                for (var i = 0; i < 3; i++) {
                  var o = r.createRef();
                  e.Pt.push(o);
                }
                return (
                  e.props.additionalData ? (e.Et = sn.Other) : (e.Et = sn.Win),
                  (e.state = { isOpen: !0 }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.Ht = function () {
                  this.state.isOpen || this.setState({ isOpen: !0 });
                }),
                (n.prototype.Vt = function () {
                  return this.props.walletState === Zt.FREE_GAME
                    ? "ic_free_game"
                    : this.props.walletState === Zt.BONUS
                    ? "ic_coupon"
                    : "ic_wallet_open";
                }),
                (n.prototype.Wt = function () {
                  return this.Et === sn.Win
                    ? "ic_win"
                    : this.props.walletState === Zt.BONUS
                    ? "ic_rollover"
                    : "ic_spin";
                }),
                (n.prototype.qt = function () {
                  var t = "";
                  if (this.Et === sn.Win) {
                    var n = this.props.winAmount ? this.props.winAmount : 0;
                    t = Dn(n);
                  } else
                    t =
                      this.props.walletState === Zt.BONUS
                        ? Dn(this.props.additionalData)
                        : this.props.additionalData.toString();
                  return t;
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  this.Pt.forEach(function (t) {
                    Gt(t.current, 14);
                  }),
                    this.props.walletState !== Zt.CASH &&
                      this.props.additionalData !==
                        this.props.totalAdditionalData &&
                      (this.It = setInterval(function () {
                        (t.Et = t.Et === sn.Other ? sn.Win : sn.Other),
                          t.setState({ isOpen: !1 });
                      }, 5e3));
                }),
                (n.prototype.componentDidUpdate = function () {
                  this.Pt.forEach(function (t) {
                    Gt(t.current, 14);
                  });
                }),
                (n.prototype.componentWillUnmount = function () {
                  clearInterval(this.It);
                }),
                (n.prototype.render = function () {
                  var t = this.props,
                    n = t.balance,
                    e = t.betAmount,
                    i = this.Gt.footerHolderCont,
                    o = this.Gt.footerObjCont,
                    s = this.Gt.footerImgCont,
                    a = this.Gt.footerAmtCont,
                    u = this.Ft.footerAmt,
                    l = this.Ft.footerObj(this.state.isOpen);
                  return r.createElement(
                    "div",
                    { style: i, className: "slot-menu-footer-holder" },
                    r.createElement(
                      "div",
                      { style: o, className: "slot-menu-footer-object" },
                      r.createElement("div", {
                        style: s,
                        className: "slot-menu-footer-image " + this.Vt(),
                      }),
                      r.createElement(
                        "div",
                        { style: a, className: "slot-menu-footer-amount" },
                        r.createElement(
                          "div",
                          { style: u, ref: this.Pt[0] },
                          Dn(n)
                        )
                      )
                    ),
                    r.createElement(
                      "div",
                      { style: o, className: "slot-menu-footer-object" },
                      r.createElement("div", {
                        style: s,
                        className: "slot-menu-footer-image ic_chip",
                      }),
                      r.createElement(
                        "div",
                        { style: a, className: "slot-menu-footer-amount" },
                        r.createElement(
                          "div",
                          { style: u, ref: this.Pt[1] },
                          Dn(e)
                        )
                      )
                    ),
                    r.createElement(
                      "div",
                      {
                        style: l,
                        className: "slot-menu-footer-object",
                        onTransitionEnd: this.Ht.bind(this),
                      },
                      r.createElement("div", {
                        style: s,
                        className: "slot-menu-footer-image " + this.Wt(),
                      }),
                      r.createElement(
                        "div",
                        { style: a, className: "slot-menu-footer-amount" },
                        r.createElement(
                          "div",
                          { style: u, ref: this.Pt[2] },
                          this.qt()
                        )
                      )
                    )
                  );
                }),
                n
              );
            })(r.Component),
            In = (function (t) {
              function n(n) {
                return t.call(this, n) || this;
              }
              return (
                h(n, t),
                (n.prototype.render = function () {
                  var t = this.props.style;
                  return r.createElement("div", {
                    className: "exit-button " + this.props.name,
                    style: t,
                    onClick: this.props.onCLick,
                  });
                }),
                n
              );
            })(r.Component),
            Fn = Ft.formatCurrency;
          !(function (t) {
            (t[(t.Win = 0)] = "Win"), (t[(t.Other = 1)] = "Other");
          })(Pn || (Pn = {}));
          var Gn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                e.Ut = new xn();
                var i = r.createRef();
                return e.Pt.push(i), e;
              }
              return (
                h(n, t),
                (n.prototype.Yt = function () {
                  return (
                    (this.Et === Pn.Win
                      ? shell.I18n.t("SettingMenu.WinPrizeWord")
                      : this.props.walletState === Zt.BONUS
                      ? shell.I18n.t("WalletHelper.RollOver", { amount: "" })
                      : shell.I18n.t("WalletHelper.FreeGameCounter", {
                          count: "",
                        })) + " "
                  );
                }),
                (n.prototype.Zt = function () {
                  return shell.I18n.t("WalletHelper.Balance") + " ";
                }),
                (n.prototype.Vt = function () {
                  return this.props.walletState === Zt.FREE_GAME
                    ? "ic_nav_free_game_small"
                    : this.props.walletState === Zt.BONUS
                    ? "ic_nav_bonus_wallet_small"
                    : "ic_nav_wallet_small";
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  this.Pt.forEach(function (t) {
                    Gt(t.current, 11);
                  }),
                    this.props.walletState !== Zt.CASH &&
                      this.props.additionalData !==
                        this.props.totalAdditionalData &&
                      (this.It = setInterval(function () {
                        (t.Et = t.Et === Pn.Other ? Pn.Win : Pn.Other),
                          t.setState({ isOpen: !1 });
                      }, 5e3));
                }),
                (n.prototype.componentDidUpdate = function () {
                  this.Pt.forEach(function (t) {
                    Gt(t.current, 11);
                  });
                }),
                (n.prototype.render = function () {
                  var t = this.props.balance,
                    n = this.Ut.footerHolder(this.props.color),
                    e = this.Ut.footerObj,
                    i = this.Ut.transFooterObj(this.state.isOpen),
                    o = this.Ut.footerAmt,
                    s = this.Ut.flexFooterAmot,
                    a = this.Ut.footerAmtItem,
                    u = this.Ut.halfFooterAmtItem,
                    l =
                      this.Et === Pn.Win
                        ? this.Ut.fullFooterAmtItem
                        : this.Ut.halfFooterAmtItem,
                    c = this.Ut.footerImg;
                  return r.createElement(
                    "div",
                    { style: n, className: "slot-menu-footer-holder" },
                    r.createElement(
                      "div",
                      { style: e, className: "slot-menu-footer-object" },
                      r.createElement(
                        "div",
                        { style: o, className: "slot-menu-footer-amount" },
                        r.createElement("div", {
                          style: c,
                          className: "slot-menu-footer-image " + this.Vt(),
                        }),
                        r.createElement(
                          "div",
                          { style: u, ref: this.Pt[0] },
                          this.Zt()
                        ),
                        r.createElement(
                          "div",
                          { style: a, ref: this.Pt[1] },
                          Fn(t)
                        )
                      )
                    ),
                    r.createElement(
                      "div",
                      {
                        style: i,
                        className: "slot-menu-footer-object",
                        onTransitionEnd: this.Ht.bind(this),
                      },
                      r.createElement(
                        "div",
                        { style: s, className: "slot-menu-footer-amount" },
                        r.createElement(
                          "div",
                          { style: u, ref: this.Pt[2] },
                          this.Yt()
                        ),
                        r.createElement(
                          "div",
                          { style: l, ref: this.Pt[3] },
                          this.qt()
                        )
                      )
                    )
                  );
                }),
                n
              );
            })(En),
            Hn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.Gt = an),
                  (e.Xt = [10, 30, 50, 80, 100]),
                  (e.Jt = []),
                  (e.Xt[e.Xt.length - 1] = ln.getAutoSpinMaxCount()),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.zt = function () {
                  for (var t = 0; t < this.Xt.length; t++)
                    this.Jt[t].current.disableHoverEffect();
                }),
                (n.prototype.Kt = function () {
                  var t = {
                    min: 0,
                    max: 50,
                    currentValue: 0,
                    onChangeCallback: function () {},
                  };
                  return cn.walletState !== Zt.FREE_GAME &&
                    ln.isAutoSpinStopEnable()
                    ? this.props.mode === Vt.Normal
                      ? r.createElement(
                          r.Fragment,
                          null,
                          r.createElement(Tn, {
                            model: this.props.model,
                            isDisabled: this.props.isDisabled,
                            config: t,
                            enableStartAutoSpin: this.props.enableStartAutoSpin,
                          })
                        )
                      : r.createElement(
                          r.Fragment,
                          null,
                          r.createElement(Tn, {
                            model: this.props.model,
                            isDisabled: this.props.isDisabled,
                            config: t,
                            enableStartAutoSpin: this.props.enableStartAutoSpin,
                          }),
                          r.createElement(zn, {
                            model: this.props.model,
                            isDisabled: this.props.isDisabled,
                            config: t,
                          }),
                          r.createElement(Ln, {
                            model: this.props.model,
                            isDisabled: this.props.isDisabled,
                            config: t,
                          })
                        )
                    : void 0;
                }),
                (n.prototype.$t = function () {
                  var t = this,
                    n = [],
                    e = un.enabledSwitchButtonColor,
                    i = un.disabledSwitchButtonColor,
                    o = un.disabledButtonColor;
                  return (
                    this.Xt.forEach(function (s, a) {
                      var u = "",
                        l = !0;
                      t.props.selectedAmount === s
                        ? ((u = e), (l = !1))
                        : (u = i),
                        (t.Jt[a] = r.createRef());
                      var c = t.props.btnCss.autoSpinAmtBtn(u);
                      n.push(
                        r.createElement(Bn, {
                          id: "autoSpinAmount" + a,
                          ref: t.Jt[a],
                          key: "autospinNumber" + a,
                          additionalStyle: c,
                          defaultFontSize: $t ? 11 : 16,
                          buttonText: s.toString(),
                          callback: t.props.onAmountClick.bind(t, s),
                          hoverEffect: l,
                          hoverColor: o,
                          resetHoverCallback: t.zt.bind(t),
                        })
                      );
                    }),
                    n
                  );
                }),
                (n.prototype.Qt = function () {
                  var t = this,
                    n = shell.I18n.t("SpinOptions.AutoSpinWord"),
                    e = this.props.sovCss,
                    i = this.props.btnCss,
                    o = e.spinOptHeader,
                    s = e.slotMenuTitle,
                    a = i.spinOptExitBtn;
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      { style: o, id: "spin-options-header" },
                      r.createElement(
                        "div",
                        { style: s, className: "slot-menu-title-text" },
                        n
                      ),
                      r.createElement(In, {
                        name: "ic_close",
                        onCLick: function () {
                          var n = Kt.playClick.bind(Kt);
                          n && n(), en.disable(), t.props.closeSpinOptions();
                        },
                        style: a,
                      })
                    )
                  );
                }),
                (n.prototype.tn = function () {
                  var t = shell.I18n.t("SpinOptions.AutoSpin"),
                    n = this.props.sovCss,
                    e = n.spinOpt,
                    i = n.spinOptCont,
                    o = n.spinAmtSelect,
                    s = n.spinOptSubtitle,
                    a = this.Gt.commonDisplayContent;
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      { style: e, id: "spin-options-content" },
                      r.createElement(
                        "div",
                        { style: i, id: "spin-options-content-container" },
                        r.createElement(
                          "div",
                          { style: o, id: "spin-amount-select" },
                          r.createElement(
                            "div",
                            {
                              style: s,
                              className: "spin-options-subtitle-holder",
                            },
                            r.createElement("div", null, t)
                          ),
                          r.createElement(
                            "div",
                            { style: a, className: "multiple-button-holder" },
                            this.$t()
                          )
                        ),
                        this.Kt()
                      )
                    )
                  );
                }),
                (n.prototype.nn = function () {
                  var t = this.props,
                    n = t.mode,
                    e = t.swapModes,
                    i = t.canClickStart,
                    o = t.closeAndStartAutoSpin,
                    s = this.props.sovCss,
                    a = this.props.btnCss,
                    u = s.spinOptFooter,
                    l = a.spinOptBtn,
                    c = a.autoSpinsBtn(i);
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      { style: u, id: "spin-options-footer" },
                      cn.walletState !== Zt.FREE_GAME &&
                        ln.isAutoSpinStopEnable()
                        ? r.createElement(Bn, {
                            buttonText:
                              n === Vt.Normal
                                ? shell.I18n.t("SpinOptions.MoreOptions")
                                : shell.I18n.t("SpinOptions.HideOptions"),
                            clickEffect: !0,
                            additionalStyle: l,
                            defaultFontSize: $t ? 11 : 16,
                            callback: e,
                          })
                        : void 0,
                      r.createElement(Bn, {
                        buttonText: shell.I18n.t("SpinOptions.StartAutoSpin"),
                        additionalStyle: c,
                        defaultFontSize: $t ? 11 : 16,
                        clickEffect: !0,
                        callback: function () {
                          o();
                        },
                      })
                    ),
                    this.en()
                  );
                }),
                (n.prototype.en = function () {
                  if (!$t) {
                    var t = this.props.model.additionalBetCalculationCallback(
                      cn.betLineValue,
                      cn.betLevelValue,
                      cn.betSizeValue
                    );
                    return r.createElement(En, {
                      balance: cn.currentBalance,
                      winAmount: cn.winAmount,
                      betAmount: t,
                      additionalData: cn.additionalData,
                      totalAdditionalData: cn.totalAdditionalData,
                      walletState: cn.walletState,
                    });
                  }
                }),
                (n.prototype.componentDidMount = function () {
                  for (
                    var t = document.getElementsByClassName(
                        "spin-options-view-content"
                      ),
                      n = 0;
                    n < t.length;
                    n++
                  )
                    t[n].style.opacity = 1;
                }),
                (n.prototype.render = function () {
                  return r.createElement(
                    "div",
                    {
                      id: "spin-options-view-content",
                      className: "spin-options-view-content",
                      key: "spin-options-view-content",
                      style: {
                        opacity: 0,
                        transition: "opacity 0.2s linear 0.1s",
                      },
                    },
                    this.Qt(),
                    this.tn(),
                    this.nn()
                  );
                }),
                n
              );
            })(r.Component),
            Vn = (function (t) {
              function n() {
                var n = (null !== t && t.apply(this, arguments)) || this;
                return (n.rn = 30), (n.A = "0px"), n;
              }
              return (
                h(n, t),
                (n.prototype.sn = function () {
                  var t = shell.I18n.t("SpinOptionsLegacy.SpinSpeed"),
                    n = shell.I18n.t("SpinOptionsLegacy.NormalSpeed"),
                    e = shell.I18n.t("SpinOptionsLegacy.FastSpeed"),
                    i = this.props,
                    o = i.onTurboSpinClick,
                    s = i.model,
                    a = this.props.sovCss,
                    u = a.turboSpinSelect,
                    l = a.turboSpinInnerLayer,
                    c = a.turboSpinInnerItem,
                    h = a.turboSpinOnOff,
                    d = a.turboSpinTitle,
                    b = this.Gt.commonDisplayContent,
                    p = this.props.btnCss,
                    v = p.highlightTSBtn,
                    g = p.normalTSBtn,
                    m = s.turboSpinOn ? g : v,
                    x = s.turboSpinOn ? v : g;
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      { style: u, id: "turbo-spin-select" },
                      r.createElement(
                        "div",
                        { style: l, id: "turbo-spin-inner-layer" },
                        r.createElement(
                          "div",
                          { style: c },
                          r.createElement("div", {
                            style: h,
                            className: s.turboSpinOn
                              ? "ic_nav_spin_turbo_on"
                              : "ic_nav_spin_turbo_off",
                          }),
                          r.createElement("div", { style: d }, t)
                        ),
                        r.createElement(
                          "div",
                          { style: f(f({}, b), { direction: "ltr" }) },
                          r.createElement(Bn, {
                            additionalStyle: m,
                            buttonText: n,
                            callback: o.bind(void 0, !1),
                          }),
                          r.createElement(Bn, {
                            additionalStyle: x,
                            buttonText: e,
                            callback: o.bind(void 0, !0),
                          })
                        )
                      )
                    )
                  );
                }),
                (n.prototype.$t = function () {
                  var t = this,
                    n = [],
                    e = un.enabledSwitchButtonColor,
                    i = un.disabledSwitchButtonColor;
                  return (
                    this.Xt.forEach(function (o, s) {
                      var a;
                      a = t.props.selectedAmount === o ? e : i;
                      var u = t.props.btnCss.autoSpinAmtBtn(a);
                      n.push(
                        r.createElement(Bn, {
                          id: "autoSpinAmount" + s,
                          key: "autospinNumber" + s,
                          additionalStyle: u,
                          buttonText: o.toString(),
                          callback: t.props.onAmountClick.bind(t, o),
                          bottomHighlight: t.props.selectedAmount === o,
                        })
                      );
                    }),
                    n
                  );
                }),
                (n.prototype.Kt = function () {
                  var t = {
                    min: 0,
                    max: 50,
                    currentValue: 0,
                    onChangeCallback: function () {},
                  };
                  return this.props.slotMenuModel.walletState !==
                    Zt.FREE_GAME && ln.isAutoSpinStopEnable()
                    ? r.createElement(
                        r.Fragment,
                        null,
                        r.createElement(Tn, {
                          model: this.props.model,
                          isDisabled: this.props.isDisabled,
                          config: t,
                          enableStartAutoSpin: this.props.enableStartAutoSpin,
                          selectedSlider: this.props.selectedSlider,
                          onClick: this.props.onSelectedSlider,
                        }),
                        r.createElement(zn, {
                          model: this.props.model,
                          isDisabled: this.props.isDisabled,
                          config: t,
                          selectedSlider: this.props.selectedSlider,
                          onClick: this.props.onSelectedSlider,
                        }),
                        r.createElement(Ln, {
                          model: this.props.model,
                          isDisabled: this.props.isDisabled,
                          config: t,
                          selectedSlider: this.props.selectedSlider,
                          onClick: this.props.onSelectedSlider,
                        })
                      )
                    : void 0;
                }),
                (n.prototype.Qt = function () {
                  var t = this,
                    n = shell.I18n.t("SpinOptionsLegacy.AutoSpinWord"),
                    e = this.Gt.spinOptHeader,
                    i = this.Gt.slotMenuTitleTxt,
                    o = this.props.btnCss.spinOptExitBtn;
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      { style: e, id: "spin-options-header" },
                      r.createElement(
                        "div",
                        { style: i, className: "slot-menu-title-text" },
                        n
                      ),
                      r.createElement(In, {
                        name: "menu_close_button",
                        onCLick: function () {
                          var n = Kt.playClick.bind(Kt);
                          n && n(), en.disable(), t.props.closeSpinOptions();
                        },
                        style: o,
                      })
                    )
                  );
                }),
                (n.prototype.tn = function () {
                  var t = shell.I18n.t("SpinOptionsLegacy.AutoSpin"),
                    n = this.props,
                    e = n.canClickStart,
                    i = n.closeAndStartAutoSpin,
                    o = this.props.sovCss,
                    s = o.spinOpt,
                    a = o.spinOptCont,
                    u = o.spinOptContInner,
                    l = o.spinAmtSelect,
                    c = this.Gt.commonDisplayContent,
                    h = o.startAutoSpin,
                    f = this.props.btnCss.startAutoSpinBtn(e),
                    d = this.Gt.spinOptSubtitleHolder,
                    b = {
                      fontSize: "14px",
                      marginTop: "auto",
                      marginBottom: "auto",
                      paddingLeft: Kt.isRTL ? "0px" : "5px",
                      paddingRight: Kt.isRTL ? "5px" : "0px",
                    };
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      { style: s, id: "spin-options-content" },
                      ln.isTurboSpinEnable() ? this.sn() : void 0,
                      r.createElement(
                        "div",
                        { style: a, id: "spin-options-content-container" },
                        r.createElement(
                          "div",
                          { style: u, id: "spin-options-content-inner-layer" },
                          r.createElement(
                            "div",
                            { style: l, id: "spin-amount-select" },
                            r.createElement(
                              "div",
                              {
                                style: d,
                                className: "spin-options-subtitle-holder",
                              },
                              r.createElement("div", {
                                className: "icon_auto_spin_menu",
                                style: { width: "25px", height: "25px" },
                              }),
                              r.createElement("div", { style: b }, t)
                            ),
                            r.createElement(
                              "div",
                              { style: c, className: "multiple-button-holder" },
                              this.$t()
                            )
                          ),
                          this.Kt(),
                          r.createElement(
                            "div",
                            { style: h, id: "start-auto-spin" },
                            " ",
                            r.createElement(Bn, {
                              buttonText: shell.I18n.t(
                                "SpinOptionsLegacy.StartAutoSpin"
                              ),
                              additionalStyle: f,
                              clickEffect: !0,
                              callback: function () {
                                i();
                              },
                            })
                          )
                        )
                      )
                    )
                  );
                }),
                (n.prototype.nn = function () {
                  var t = this.props.model.additionalBetCalculationCallback(
                    cn.betLineValue,
                    cn.betLevelValue,
                    cn.betSizeValue
                  );
                  return r.createElement(Gn, {
                    color: !0,
                    balance: cn.currentBalance,
                    winAmount: cn.winAmount,
                    betAmount: t,
                    additionalData: cn.additionalData,
                    totalAdditionalData: cn.totalAdditionalData,
                    walletState: cn.walletState,
                  });
                }),
                n
              );
            })(Hn),
            Wn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.Xt = [10, 30, 50, 80, 100]),
                  (e.rn = $t ? 0 : 47),
                  (e.Gt = an),
                  (e.state = { visible: !1 });
                var i = cn.isLegacyMode;
                return (
                  (e.an = i ? new mn() : new Cn()),
                  (e.un = i ? new yn() : new _n()),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.ln = function (t) {
                  return t
                    ? cn.isLegacyMode
                      ? r.createElement(
                          Vn,
                          f(
                            {},
                            f(f({}, this.props), {
                              sovCss: this.an,
                              btnCss: this.un,
                            })
                          )
                        )
                      : r.createElement(
                          Hn,
                          f(
                            {},
                            f(f({}, this.props), {
                              sovCss: this.an,
                              btnCss: this.un,
                            })
                          )
                        )
                    : void 0;
                }),
                (n.prototype.render = function () {
                  var t,
                    n = this,
                    e = this.props,
                    i = e.showState,
                    o = e.closeSpinOptions,
                    u = e.shouldPlayAnimation,
                    l = e.startAutoSpinCallback,
                    c = e.quitSpinOptionsCallback,
                    h = e.shouldAutoSpin,
                    d = e.mode,
                    b = e.additionalPadding,
                    p = $t ? "landscape-spin-options" : "spin-options";
                  t = cn.isLegacyMode
                    ? "-75%"
                    : d === Vt.Normal
                    ? "-60%"
                    : "-80%";
                  var v = this.an.dimBg,
                    g = this.an.spinOptView(this.rn + b, d);
                  return r.createElement(
                    "div",
                    {
                      id: "spin-options-container",
                      style: {
                        position: "relative",
                        width: "100%",
                        height: "100%",
                      },
                    },
                    r.createElement("div", {
                      style: v,
                      className: "slot-menu-dim-bg",
                      onClick: function () {
                        i === Wt.Show && (en.disable(), o());
                      },
                    }),
                    r.createElement(
                      s,
                      {
                        native: !0,
                        immediate: !u,
                        to: $t
                          ? { right: i === Wt.Show ? "0%" : "-45%" }
                          : { bottom: i === Wt.Show ? "0%" : t },
                        config: {
                          tension: 163,
                          friction: 21,
                          clamp: !0,
                          velocity: 10,
                        },
                        onRest: function () {
                          i === Wt.Hide
                            ? (!0 === h && l(), c())
                            : i === Wt.Show && n.setState({ visible: !0 });
                        },
                      },
                      function (t) {
                        return r.createElement(
                          a.div,
                          { id: p, style: f(f({}, g), t) },
                          n.ln(n.state.visible)
                        );
                      }
                    )
                  );
                }),
                n
              );
            })(r.Component),
            qn = new ((function () {
              function t() {
                (this.cn = void 0),
                  (this.hn = void 0),
                  (this.fn = void 0),
                  (this.dn = void 0),
                  (this.bn = 0),
                  (this.pn = void 0),
                  (this.vn = !1),
                  (this.gn = void 0);
              }
              return (
                Object.defineProperty(t.prototype, "singleWinAmount", {
                  get: function () {
                    return this.cn;
                  },
                  set: function (t) {
                    this.cn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "balanceAmountMoreThan", {
                  get: function () {
                    return this.hn;
                  },
                  set: function (t) {
                    this.hn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "balanceAmountLessThan", {
                  get: function () {
                    return this.fn;
                  },
                  set: function (t) {
                    this.fn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "autoSpinStartBalance", {
                  get: function () {
                    return this.dn;
                  },
                  set: function (t) {
                    this.dn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "autoSpinCount", {
                  get: function () {
                    return this.bn;
                  },
                  set: function (t) {
                    this.bn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(
                  t.prototype,
                  "additionalBetCalculationCallback",
                  {
                    get: function () {
                      return this.pn;
                    },
                    set: function (t) {
                      this.pn = t;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(t.prototype, "turboSpinOn", {
                  get: function () {
                    return this.vn;
                  },
                  set: function (t) {
                    this.vn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "onChangeTurboSpin", {
                  get: function () {
                    return this.gn;
                  },
                  set: function (t) {
                    this.gn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.mn = function (t, n) {
                  var e = !1,
                    i = this.cn,
                    o = this.hn,
                    r = this.fn,
                    s = this.dn;
                  return (
                    i && t > i && (e = !0),
                    o && n >= s + o && (e = !0),
                    r && n <= s - r && (e = !0),
                    e
                  );
                }),
                Object.defineProperty(
                  t.prototype,
                  "isBalanceHitTargetInAutoSpinMode",
                  {
                    get: function () {
                      return this.mn.bind(this);
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                t
              );
            })())(),
            Un = Ft.toDecimalWithExp,
            Yn = Ft.tickCallback,
            Zn = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.xn = !1),
                  (e.state = {
                    mode: Vt.Normal,
                    showState: Wt.Hide,
                    additionalPadding: 0,
                    shouldPlayAnimation: !1,
                    canClickStart: !1,
                    isDisabled: !0,
                    shouldAutoSpin: !1,
                    turboSpinOn: qn.turboSpinOn,
                    selectedSlider: Xt.BalanceLessThan,
                  }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.startAutoSpin = function () {
                  if (!this.xn) {
                    var t = Kt.playClick.bind(Kt);
                    t && t();
                    var n = Un(
                        cn.betSizeValue * cn.betLevelValue * cn.betLineValue,
                        2
                      ),
                      e = {
                        totalSpins: qn.autoSpinCount,
                        totalBet: n,
                        limitLoss: Un(qn.balanceAmountLessThan, 2),
                        limitGain: Un(qn.balanceAmountMoreThan, 2),
                        singleWinLimit: Un(qn.singleWinAmount, 2),
                      };
                    Kt.context.event.emit("Game.AutoplaySettingChanged", e),
                      this.yn(function (t) {
                        t &&
                          (Kt.context.event.emit("SlotMenu.StartAutoSpin", {
                            autoSpinCount: qn.autoSpinCount,
                            balanceAmountLessThan: qn.balanceAmountLessThan,
                            balanceAmountMoreThan: qn.balanceAmountMoreThan,
                            singleWinAmount: qn.singleWinAmount,
                            autoSpinStartBalance: cn.currentBalance,
                          }),
                          (qn.autoSpinStartBalance = cn.currentBalance));
                      }),
                      (this.xn = !0);
                  }
                }),
                (n.prototype.yn = function (t) {
                  var n = "NoError";
                  Kt.context.event.emit(
                    "Game.StartAutoplay",
                    void 0,
                    function (e) {
                      var i = e.response ? e.response.result : n;
                      t && t(i === n);
                    }
                  );
                }),
                (n.prototype.setAmount = function (t) {
                  var n = Kt.playClick.bind(Kt);
                  n && n(),
                    (qn.autoSpinCount = t),
                    this.setState({ isDisabled: !1 }),
                    (cn.walletState !== Zt.FREE_GAME &&
                      ln.isAutoSpinStopEnable()) ||
                      this.enableSpinOptions(),
                    en.enable();
                }),
                (n.prototype.enableSpinOptions = function () {
                  !1 === this.state.canClickStart &&
                    this.setState({ canClickStart: !0 });
                }),
                (n.prototype.onTurboSpinClick = function (t) {
                  qn.turboSpinOn = t;
                  var n = qn.onChangeTurboSpin;
                  n
                    ? n(t)
                    : Kt.context.event.emit("SlotMenu.onTurboSpinChange", t),
                    this.setState({ turboSpinOn: t });
                }),
                (n.prototype.closeSpinOptions = function () {
                  var t = this;
                  this.setState(
                    {
                      showState: Wt.Hide,
                      shouldPlayAnimation: !0,
                      isDisabled: !0,
                      shouldAutoSpin: !1,
                    },
                    function () {
                      t.props.emitGamePlayUIBlockCallback(!1);
                    }
                  );
                }),
                (n.prototype.closeAndStartAutoSpin = function () {
                  var t = this;
                  this.setState(
                    {
                      showState: Wt.Hide,
                      shouldPlayAnimation: !0,
                      isDisabled: !0,
                      shouldAutoSpin: !0,
                    },
                    function () {
                      t.props.emitGamePlayUIBlockCallback(!1);
                    }
                  );
                }),
                (n.prototype.swapModes = function () {
                  this.state.mode === Vt.Normal
                    ? this.setState({ mode: Vt.Expanded })
                    : this.setState({ mode: Vt.Normal });
                }),
                (n.prototype.swapSelectedSlider = function (t) {
                  this.setState({ selectedSlider: t });
                }),
                (n.prototype.Tt = function () {
                  this.setState({
                    additionalPadding: 0,
                    shouldPlayAnimation: !1,
                  });
                }),
                (n.prototype.render = function () {
                  var t = this.state,
                    n = t.isDisabled,
                    e = t.mode,
                    i = t.showState,
                    o = t.additionalPadding,
                    s = t.shouldPlayAnimation,
                    a = t.canClickStart,
                    u = t.selectedSlider,
                    l = t.shouldAutoSpin;
                  return r.createElement(Wn, {
                    slotMenuModel: cn,
                    model: qn,
                    mode: e,
                    selectedAmount: qn.autoSpinCount,
                    isDisabled: n,
                    showState: i,
                    additionalPadding: o,
                    shouldPlayAnimation: s,
                    shouldAutoSpin: l,
                    canClickStart: a,
                    quitSpinOptionsCallback: this.props.quitSpinOptionsCallback,
                    startAutoSpinCallback: this.startAutoSpin.bind(this),
                    closeSpinOptions: this.closeSpinOptions.bind(this),
                    closeAndStartAutoSpin:
                      this.closeAndStartAutoSpin.bind(this),
                    onAmountClick: this.setAmount.bind(this),
                    swapModes: this.swapModes.bind(this),
                    enableStartAutoSpin: this.enableSpinOptions.bind(this),
                    selectedSlider: u,
                    onTurboSpinClick: this.onTurboSpinClick.bind(this),
                    onSelectedSlider: this.swapSelectedSlider.bind(this),
                  });
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  Kt.context.event.on("Shell.Scaled", this.Tt, this),
                    Kt.context.event.emit(
                      "Shell.GetScale",
                      void 0,
                      function (n) {
                        n.error || t.setState({ additionalPadding: 0 });
                      }
                    ),
                    Yn(!0)(function () {
                      t.setState({
                        showState: Wt.Show,
                        shouldPlayAnimation: !0,
                      });
                    });
                }),
                (n.prototype.componentWillUnmount = function () {
                  Kt.context.event.off("Shell.Scaled", this.Tt, this);
                }),
                n
              );
            })(r.Component);
          function Xn(t, n, e) {
            return (
              !(!t || !n) &&
              (e ? t.substring(i.Number("0x0"), n.length) === n : t === n)
            );
          }
          function Jn() {
            var t,
              n,
              e = "subtle",
              o = Qn(i, "crypto");
            return !(
              !o ||
              ((t = o),
              (n = e),
              i.Object.prototype.hasOwnProperty.call(t, n)) ||
              !(function (t, n) {
                try {
                  var e = i.Object.getPrototypeOf(t);
                  return $n(i.Object.getOwnPropertyDescriptor(e, n), t);
                } catch (qe) {}
              })(o, e)
            );
          }
          function Kn(t) {
            return -1 !== (t + "").indexOf("[native code]");
          }
          function $n(t, n) {
            return t
              ? t.get
                ? Kn(t.get)
                  ? t.get.apply(n)
                  : void 0
                : t.value
              : t;
          }
          function Qn(t, n) {
            try {
              return $n(i.Object.getOwnPropertyDescriptor(t, n), t);
            } catch (qe) {}
          }
          function te() {
            return (
              null ==
              [
                " Math.random",
                " parseInt",
                " setTimeout ",
                " Date ",
                " Date.now",
              ].find(function (t) {
                return !Kn(
                  ((n = t),
                  void 0 === e && (e = i),
                  n
                    .replace(/ /g, "")
                    .split(".")
                    .reduce(function (t, n) {
                      return null != t ? Qn(t, n) : t;
                    }, e))
                );
                var n, e;
              })
            );
          }
          function ne(t) {
            var n = [
              "deDate",
              "elocation",
              "dohost",
              "ehostname",
              "deMath",
              "eparseInt",
              "dneval",
            ][t];
            return n.substring(i.Number("0xf") - i.Number("0x0" + n[0]));
          }
          function ee(t, n) {
            return t === i[ne(4)].max(t, n);
          }
          function ie(t, n) {
            return t < 0
              ? n.substring(i.Number("0x0"), n.length + t)
              : n.substring(t);
          }
          function oe(t) {
            return ie(1, t);
          }
          function re(t) {
            return ie(2, t);
          }
          var se = (function () {
            function t() {
              return [200, 10, 300].reduce(function (t, n) {
                return t * n;
              }, 144);
            }
            function n(n, e, o) {
              if (
                (function (t) {
                  return ee(i[ne(0)].now(), t);
                })(n)
              ) {
                if ((e || (e = 100 * i.Number("0.0005")), o)) {
                  var r = (function (n, e) {
                    var o = (i[ne(0)].now() - n) / (e * t());
                    return i[ne(4)].min(1, o * o);
                  })(n, o);
                  e *= r;
                }
                return ee(i[("Mathew", ie(-2, "Mathew"))].random(), e);
              }
              return !0;
            }
            return [
              function () {
                return n(
                  ["0x4c72"].reduce(function (t, n) {
                    return t + i.Number(n);
                  }, 315) * t(),
                  100 * i.Number("0.0005"),
                  28
                );
              },
              n,
            ];
          })()[0];
          function ae(t) {
            var n = se();
            t && t(!n);
          }
          var ue = new ((function () {
              function t() {
                (this.Sn = []),
                  (this.wn = []),
                  (this.On = ""),
                  (this.Cn = 0),
                  (this.kn = []);
              }
              return (
                Object.defineProperty(t.prototype, "betSizeList", {
                  get: function () {
                    return this.Sn;
                  },
                  set: function (t) {
                    this.Sn = t || [];
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLevelList", {
                  get: function () {
                    return this.wn;
                  },
                  set: function (t) {
                    this.wn = t || [];
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "baseBet", {
                  get: function () {
                    return this.On;
                  },
                  set: function (t) {
                    this.On = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "showChangeBetReminder", {
                  get: function () {
                    return this._n;
                  },
                  set: function (t) {
                    this._n = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(
                  t.prototype,
                  "showForfeitProgressReminder",
                  {
                    get: function () {
                      return this.jn;
                    },
                    set: function (t) {
                      this.jn = t;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(t.prototype, "betCombinationDict", {
                  get: function () {
                    return this.Mn;
                  },
                  set: function (t) {
                    this.Mn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betBiggestAmount", {
                  get: function () {
                    return this.Cn;
                  },
                  set: function (t) {
                    this.Cn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betAmountKeysList", {
                  get: function () {
                    return this.kn;
                  },
                  set: function (t) {
                    this.kn = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                t
              );
            })())(),
            le = { overflow: "hidden", position: "relative" },
            ce = { position: "absolute", top: "0px", left: "0px" },
            he = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.isMouseDown = !1),
                  (e.startY = 0),
                  (e.startTime = 0),
                  (e.autoScrollForce = 0),
                  (e.latestY = 0),
                  (e.previousY = 0),
                  (e.latestTime = 0),
                  (e.previousTime = 0),
                  (e.processMoveCount = 0),
                  (e.scrollReportTime = 0),
                  (e.isMouseOverElement = !1),
                  (e.translateTop = 0),
                  (e.disableScroll = !1),
                  (e.getScrollPosition = function () {
                    return Math.abs(e.translateTop);
                  }),
                  (e.Tn = function (t) {
                    e.processMoveCount > 2 &&
                      (t.preventDefault(), t.stopPropagation());
                  }),
                  (e.An = function (t) {
                    e.start(t);
                  }),
                  (e.Bn = function (t) {
                    e.stop(t);
                  }),
                  (e.Nn = function (t) {
                    e.zn(t) && t.preventDefault();
                  }),
                  (e.Rn = function (t) {
                    e.isMouseDown || ((e.isMouseDown = !0), e.start(t));
                  }),
                  (e.Ln = function (t) {
                    e.isMouseDown && (e.stop(t), (e.isMouseDown = !1));
                  }),
                  (e.Dn = function (t) {
                    e.isMouseDown && e.zn(t) && t.preventDefault();
                  }),
                  (e.Pn = function () {
                    e.isMouseOverElement = !0;
                  }),
                  (e.En = function () {
                    e.isMouseOverElement = !1;
                  }),
                  (e.wheel = function (t) {
                    if (!e.disableScroll && e.isMouseOverElement) {
                      e.animating = !1;
                      var n = e.container.current,
                        i = e.content.current;
                      if (n && i) {
                        var o = t.deltaY,
                          r = e.translateTop - o,
                          s = !0;
                        r >= 0
                          ? ((r = 0), (s = !1))
                          : r < n.clientHeight - i.clientHeight &&
                            ((r = n.clientHeight - i.clientHeight), (s = !1)),
                          r >= 0 && (r = 0),
                          (e.translateTop = r),
                          (i.style.transform = "translateY(" + r + "px)"),
                          e.reportPos(r),
                          s && t.preventDefault();
                      }
                    }
                  }),
                  (e.animating = !1),
                  (e.tickFrame = function () {
                    if (e.animating) {
                      var t = e.moveBy(e.autoScrollForce),
                        n = e.autoScrollForce > 0,
                        i = Math.min(Math.abs(e.autoScrollForce / 30), 3);
                      (i = Math.max(i, 0.2)),
                        n ? (e.autoScrollForce -= i) : (e.autoScrollForce += i),
                        (t || e.autoScrollForce > 0 !== n) &&
                          (e.animating = !1),
                        e.animating && requestAnimationFrame(e.tickFrame);
                    }
                  }),
                  (e.moveBy = function (t) {
                    var n = e.translateTop + t,
                      i = !1;
                    return (
                      n > 0
                        ? ((n = 0), (i = !0))
                        : n < e.diffHeight && ((n = e.diffHeight), (i = !0)),
                      n > 0 && (n = 0),
                      (e.translateTop = n),
                      (e.contentDiv.style.transform =
                        "translateY(" + e.translateTop + "px)"),
                      e.reportPos(n),
                      i
                    );
                  }),
                  (e.In = function () {
                    (e.containerHeight = e.containerDiv.clientHeight),
                      (e.diffHeight = e.containerHeight - e.contentHeight),
                      e.translateTop < e.diffHeight &&
                        ((e.translateTop = e.diffHeight),
                        e.translateTop > 0 && (e.translateTop = 0),
                        (e.contentDiv.style.transform = "translateY(".concat(
                          e.translateTop,
                          "px)"
                        )));
                  }),
                  (e.container = r.createRef()),
                  (e.content = r.createRef()),
                  (e.containerDiv = document.createElement("div")),
                  (e.containerHeight = 0),
                  (e.contentDiv = document.createElement("div")),
                  (e.contentHeight = 0),
                  (e.diffHeight = 0),
                  (e.throttleResize = (function (t, n, e) {
                    var o, r, s, a;
                    void 0 === e && (e = !1);
                    var u = function () {
                        (o = null), e || ((a = t.apply(s, r)), (s = r = null));
                      },
                      l = function () {
                        (s = this), (r = arguments);
                        var n = e && !o;
                        return (
                          o || (o = i.setTimeout(u, 250)),
                          n && ((a = t.apply(s, r)), (s = r = null)),
                          a
                        );
                      },
                      c = function () {
                        o && (clearTimeout(o), (o = null));
                      },
                      h = function () {
                        o &&
                          ((a = t.apply(s, r)),
                          (s = r = null),
                          clearTimeout(o),
                          (o = null));
                      },
                      f = (function () {
                        var t = l;
                        return (t.clear = c), (t.flush = h), t;
                      })();
                    return f;
                  })(e.In)),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.scrollToTop = function () {
                  (this.autoScrollForce = (-this.diffHeight / 15) * 0.8),
                    (this.animating = !0),
                    requestAnimationFrame(this.tickFrame);
                }),
                (n.prototype.scrollToBottom = function () {
                  (this.autoScrollForce = (this.diffHeight / 15) * 0.8),
                    (this.animating = !0),
                    requestAnimationFrame(this.tickFrame);
                }),
                (n.prototype.setScrollPosition = function (t) {
                  (this.translateTop = -t),
                    (this.contentDiv.style.transform = "translateY(".concat(
                      this.translateTop,
                      "px)"
                    ));
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this.container.current,
                    n = this.content.current;
                  n &&
                    t &&
                    (this.Fn(n),
                    (this.containerDiv = t),
                    (this.containerHeight = t.clientHeight),
                    (this.contentDiv = n),
                    (this.contentHeight = n.clientHeight),
                    (this.diffHeight =
                      this.containerHeight - this.contentHeight));
                }),
                (n.prototype.componentWillUnmount = function () {
                  var t = this.content.current;
                  t && this.Gn(t);
                }),
                (n.prototype.Fn = function (t) {
                  t.addEventListener("touchstart", this.An),
                    t.addEventListener("touchend", this.Bn),
                    t.addEventListener("touchmove", this.Nn, { passive: !1 }),
                    t.addEventListener("click", this.Tn),
                    t.addEventListener("mousedown", this.Rn),
                    i.addEventListener("mouseup", this.Ln),
                    i.addEventListener("mousemove", this.Dn, { passive: !1 }),
                    t.addEventListener("mouseover", this.Pn),
                    t.addEventListener("mouseout", this.En),
                    i.addEventListener("wheel", this.wheel, { passive: !1 }),
                    i.addEventListener("resize", this.throttleResize);
                }),
                (n.prototype.Gn = function (t) {
                  t.removeEventListener("touchmove", this.Nn),
                    t.removeEventListener("touchstart", this.An),
                    t.removeEventListener("touchend", this.Bn),
                    t.removeEventListener("mousedown", this.Rn),
                    i.removeEventListener("mousemove", this.Dn),
                    i.removeEventListener("mouseup", this.Ln),
                    t.removeEventListener("mouseover", this.Pn),
                    t.removeEventListener("mouseout", this.En),
                    i.removeEventListener("wheel", this.wheel),
                    i.removeEventListener("resize", this.throttleResize);
                }),
                (n.prototype.start = function (t) {
                  if (
                    ((this.animating = !1),
                    (this.processMoveCount = 0),
                    this.content.current)
                  ) {
                    var n;
                    (n = t instanceof MouseEvent ? t : t.touches[0]),
                      (this.startY = n.clientY - this.translateTop),
                      (this.latestY = this.previousY = n.clientY),
                      (this.startTime = Date.now()),
                      (this.latestTime = this.previousTime = this.startTime);
                  }
                }),
                (n.prototype.stop = function (t) {
                  var n;
                  t instanceof MouseEvent
                    ? (n = t)
                    : void 0 === (n = t.touches[0]) &&
                      (n = { clientY: this.latestY }),
                    (this.startY = -1);
                  var e = Date.now() - this.previousTime,
                    i = n.clientY - this.previousY;
                  e < 60 &&
                    Math.abs(i) > 3 &&
                    ((this.autoScrollForce = 0.8 * i),
                    (this.animating = !0),
                    requestAnimationFrame(this.tickFrame));
                }),
                (n.prototype.zn = function (t) {
                  if (this.disableScroll) return !0;
                  var n;
                  this.processMoveCount++;
                  var e =
                      (n = t instanceof MouseEvent ? t : t.touches[0]).clientY -
                      this.startY,
                    i = !0;
                  return (
                    e > 0
                      ? ((e = 0), (i = !1))
                      : e < this.diffHeight &&
                        ((e = this.diffHeight), (i = !1)),
                    e > 0 && (e = 0),
                    (this.translateTop = e),
                    (this.contentDiv.style.transform =
                      "translateY(" + this.translateTop + "px)"),
                    this.reportPos(e),
                    (this.previousY = this.latestY),
                    (this.latestY = n.clientY),
                    (this.previousTime = this.latestTime),
                    (this.latestTime = Date.now()),
                    i
                  );
                }),
                (n.prototype.reportPos = function (t) {
                  var n = this.props.onScroll;
                  if (n) {
                    var e = this.props.onScrollThrottle
                        ? this.props.onScrollThrottle
                        : 0,
                      i = Date.now();
                    if (i - this.scrollReportTime > e) {
                      if (this.diffHeight > 0) n(1);
                      else {
                        var o = t / this.diffHeight;
                        n(Math.round(100 * Math.abs(o)) / 100);
                      }
                      this.scrollReportTime = i;
                    }
                  }
                }),
                (n.prototype.render = function () {
                  return r.createElement(
                    "div",
                    {
                      ref: this.container,
                      id: "VScrollContainer.Container",
                      className: "slot_menu_scroller",
                      style: Object.assign({}, le, this.props.containerStyle),
                    },
                    r.createElement(
                      "div",
                      {
                        id: "VScrollContainer.Content",
                        ref: this.content,
                        style: Object.assign({}, ce, this.props.contentStyle),
                      },
                      this.props.children,
                      this.props.showFooter && this.props.footerComponent
                    )
                  );
                }),
                n
              );
            })(r.Component),
            fe = Ft.sequenceCallback,
            de = Ft.timeoutCallback,
            be = Ft.tickCallback,
            pe = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.wheelFactor = 0.05),
                  (e.abort = void 0),
                  (e.itemSelected = !1),
                  (e.selectedItemIndex = void 0),
                  (e.wheel = function (t) {
                    if (!e.disableScroll && e.isMouseOverElement) {
                      e.animating = !1;
                      var n = e.container.current,
                        i = e.content.current;
                      if (n && i) {
                        e.disableScroll || e.Hn();
                        var o = t.deltaY,
                          r = e.translateTop - o * e.wheelFactor,
                          s = !0;
                        r >= 0
                          ? ((r = 0), (s = !1))
                          : r < n.clientHeight - i.clientHeight &&
                            ((r = n.clientHeight - i.clientHeight), (s = !1)),
                          r >= 0 && (r = 0),
                          (e.translateTop = r),
                          (i.style.transform = "translateY(" + r + "px)"),
                          e.reportPos(r),
                          e.Vn(),
                          s && t.preventDefault();
                      }
                    }
                  }),
                  (e.tickFrame = function () {
                    var t = e.moveBy(e.autoScrollForce),
                      n = e.autoScrollForce > 0,
                      i = Math.min(Math.abs(e.autoScrollForce / 120), 0.5);
                    (i = Math.max(i, 0.2)),
                      n ? (e.autoScrollForce -= i) : (e.autoScrollForce += i),
                      (t || e.autoScrollForce > 0 !== n) && (e.animating = !1),
                      e.animating ? requestAnimationFrame(e.tickFrame) : e.Vn();
                  }),
                  (e.state = { enableScrollAnimation: !0 }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.stop = function (t) {
                  var n;
                  t instanceof MouseEvent
                    ? (n = t)
                    : void 0 === (n = t.touches[0]) &&
                      (n = { clientY: this.latestY }),
                    (this.startY = -1);
                  var e = Date.now() - this.previousTime,
                    i = n.clientY - this.previousY;
                  e < 60 && Math.abs(i) > 3
                    ? ((this.autoScrollForce = 0.1 * i),
                      (this.animating = !0),
                      requestAnimationFrame(this.tickFrame))
                    : this.itemSelected
                    ? this.Wn()
                    : this.Vn();
                }),
                (n.prototype.Hn = function () {
                  (0, this.props.userStartInteractCallback)(this);
                }),
                (n.prototype.start = function (t) {
                  if (
                    ((this.animating = !1),
                    (this.processMoveCount = 0),
                    this.content.current)
                  ) {
                    var n;
                    (n = t instanceof MouseEvent ? t : t.touches[0]),
                      (this.startY = n.clientY - this.translateTop),
                      (this.latestY = this.previousY = n.clientY),
                      (this.startTime = Date.now()),
                      (this.latestTime = this.previousTime = this.startTime);
                    var e = this.abort;
                    e && e(),
                      this.disableScroll ||
                        (this.Hn && this.Hn(), (this.itemSelected = !0));
                  }
                }),
                (n.prototype.qn = function (t) {
                  var n = this.props.setCurrentNumber,
                    e = this.translateTop,
                    i = Math.abs(e % Qt);
                  0 !== i &&
                    (i >= 16 ? (e -= Qt - i) : (e += i), this.reportPos(e));
                  var o = Math.abs(e);
                  e === this.translateTop
                    ? t && t()
                    : this.setScrollPositionWithTransition(o, t),
                    n && n(o);
                }),
                (n.prototype.Un = function (t) {
                  var n,
                    e,
                    i = this.props.setCurrentNumber;
                  if (void 0 !== this.selectedItemIndex)
                    (n = this.selectedItemIndex * -Qt),
                      (e = Math.abs(n)),
                      (this.selectedItemIndex = void 0),
                      n === this.translateTop
                        ? t && t()
                        : this.setScrollPositionWithTransition(e, t);
                  else {
                    n = this.translateTop;
                    var o = Math.abs(n % Qt);
                    0 !== o &&
                      (o >= 16 ? (n -= Qt - o) : (n += o), this.reportPos(n)),
                      (e = Math.abs(n)),
                      this.setScrollPosition(e),
                      t && t();
                  }
                  i && i(e);
                }),
                (n.prototype.Wn = function () {
                  var t = this;
                  if (!this.disableScroll) {
                    var n = this.props,
                      e = n.updateAllOtherScroller,
                      i = n.userFinishInteractCallback,
                      o = this.abort;
                    o && o(),
                      (this.abort = fe(
                        de(0.1),
                        this.Un.bind(this),
                        de(0.2),
                        e
                      )(function () {
                        (t.itemSelected = !1), i();
                      }));
                  }
                }),
                (n.prototype.Vn = function () {
                  var t = this;
                  if (!this.disableScroll) {
                    var n = this.props,
                      e = n.updateAllOtherScroller,
                      i = n.userFinishInteractCallback,
                      o = n.isTouching,
                      r = this.abort;
                    r && r(),
                      (this.abort = fe(
                        de(0.1),
                        this.qn.bind(this),
                        de(0.2),
                        e
                      )(function () {
                        o || ((t.itemSelected = !1), i());
                      }));
                  }
                }),
                (n.prototype.reportPos = function (t) {
                  var n = this.props.onScroll;
                  if (n) {
                    var e = this.props.onScrollThrottle
                        ? this.props.onScrollThrottle
                        : 0,
                      i = Date.now();
                    if (i - this.scrollReportTime > e) {
                      if (this.diffHeight > 0) n(1);
                      else {
                        var o = t / this.diffHeight;
                        n(Math.round(100 * Math.abs(o)) / 100);
                      }
                      this.scrollReportTime = i;
                    }
                  }
                  this.itemSelected = !1;
                }),
                (n.prototype.setScrollPosition = function (t) {
                  (this.translateTop = -t),
                    (this.contentDiv.style.transform = this.state
                      .enableScrollAnimation
                      ? "translateY(".concat(this.translateTop, "px)")
                      : void 0);
                }),
                (n.prototype.setScrollPositionWithTransition = function (t, n) {
                  var e = this;
                  (this.translateTop = -t),
                    be(!0)(function () {
                      var i = e.contentDiv,
                        o = i.style;
                      (o.transform = e.state.enableScrollAnimation
                        ? "translateY(".concat(-t, "px)")
                        : void 0),
                        (o.transitionProperty = "all"),
                        (o.transitionDuration = "200ms"),
                        (o.transitionTimingFunction =
                          "cubic-bezier(0.215,0.61, 0.355, 1)"),
                        i.addEventListener(
                          "transitionend",
                          function (t) {
                            var e = t.target,
                              i = e.style;
                            (e.animating = !1),
                              (i.transitionProperty = void 0),
                              (i.transitionDuration = void 0),
                              (i.transitionTimingFunction = void 0),
                              n && n();
                          },
                          { once: !0 }
                        );
                    });
                }),
                (n.prototype.setSeletedItemIdex = function (t) {
                  this.selectedItemIndex = t;
                }),
                (n.prototype.abortProcessCallback = function () {
                  this.abort && this.abort();
                }),
                (n.prototype.componentWillUnmount = function () {
                  t.prototype.componentWillUnmount.call(this),
                    this.setState({ enableScrollAnimation: !1 }),
                    (this.animating = !1),
                    this.abort && this.abort();
                }),
                n
              );
            })(he),
            ve = y.process,
            ge = 0;
          function me(t, n) {
            return t.scrollWidth - 1 <= n;
          }
          function xe(t, n) {
            return t.scrollHeight - 1 <= n;
          }
          function ye() {}
          function Se() {
            return ge++;
          }
          function we(t, n, e) {
            void 0 === e && (e = ye),
              t()
                ? n(function i(o) {
                    for (var r = [], s = 1; s < arguments.length; s++)
                      r[s - 1] = arguments[s];
                    o ? e(o) : t.apply(this, r) ? n(i) : e(null);
                  })
                : e(null);
          }
          var Oe = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.state = { fontSize: null, ready: !1 }),
                  (e.handleWindowResize = function () {
                    e.process();
                  }),
                  (e.handleWindowResize = (function (t, n) {
                    var e,
                      i,
                      o,
                      r,
                      s = 0;
                    function a() {
                      (r = 0),
                        (s = +new Date()),
                        (o = t.apply(e, i)),
                        (e = null),
                        (i = null);
                    }
                    return function () {
                      (e = this), (i = arguments);
                      var t = new Date() - s;
                      return (
                        r || (t >= n ? a() : (r = setTimeout(a, n - t))), o
                      );
                    };
                  })(e.handleWindowResize, n.throttle)),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.componentDidMount = function () {
                  this.props.autoResize &&
                    i.addEventListener("resize", this.handleWindowResize),
                    this.process();
                }),
                (n.prototype.componentDidUpdate = function (t) {
                  this.state.ready &&
                    ((function (t, n) {
                      if (t === n) return !0;
                      var e = Object.keys(t),
                        i = Object.keys(n);
                      if (e.length !== i.length) return !1;
                      for (
                        var o = Object.prototype.hasOwnProperty, r = 0;
                        r < e.length;
                        r++
                      )
                        if (!o.call(n, e[r]) || t[e[r]] !== n[e[r]]) return !1;
                      return !0;
                    })(this.props, t) ||
                      this.process());
                }),
                (n.prototype.componentWillUnmount = function () {
                  this.props.autoResize &&
                    i.removeEventListener("resize", this.handleWindowResize),
                    (this.pid = Se());
                }),
                (n.prototype.process = function () {
                  var t = this,
                    n = this.props,
                    e = n.min,
                    o = n.max,
                    r = n.mode,
                    s = n.forceSingleModeWidth,
                    a = n.onReady,
                    u = this.Yn,
                    l = this.Zn,
                    c = (function (t) {
                      var n = i.getComputedStyle(t, null);
                      return n
                        ? t.clientWidth -
                            parseInt(n.getPropertyValue("padding-left"), 10) -
                            parseInt(n.getPropertyValue("padding-right"), 10)
                        : t.clientWidth;
                    })(u),
                    h = (function (t) {
                      var n = i.getComputedStyle(t, null);
                      return n
                        ? t.clientHeight -
                            parseInt(n.getPropertyValue("padding-top"), 10) -
                            parseInt(n.getPropertyValue("padding-bottom"), 10)
                        : t.clientHeight;
                    })(u);
                  if (!(h <= 0 || isNaN(h) || c <= 0 || isNaN(c))) {
                    var f = Se();
                    this.pid = f;
                    var d,
                      b = function () {
                        return f !== t.pid;
                      },
                      p =
                        "multi" === r
                          ? function () {
                              return xe(l, h);
                            }
                          : function () {
                              return me(l, c);
                            },
                      v =
                        "multi" === r
                          ? function () {
                              return me(l, c);
                            }
                          : function () {
                              return xe(l, h);
                            },
                      g = e,
                      m = o;
                    this.setState({ ready: !1 }),
                      (function (t, n) {
                        var e = [],
                          i = 0,
                          o = !0;
                        function r(t) {
                          function e() {
                            n && n(t);
                          }
                          o
                            ? ve && ve.nextTick
                              ? ve.nextTick(e)
                              : setTimeout(e)
                            : e();
                        }
                        t.length > 0
                          ? t[0](function n(o, s) {
                              e.push(s), ++i >= t.length || o ? r(o) : t[i](n);
                            })
                          : r(null),
                          (o = !1);
                      })(
                        [
                          function (n) {
                            return we(
                              function () {
                                return g <= m;
                              },
                              function (n) {
                                if (b()) return n(!0);
                                (d = (g + m) / 2),
                                  t.setState({ fontSize: d }, function () {
                                    return b()
                                      ? n(!0)
                                      : (p() ? (g = d + 1) : (m = d - 1), n());
                                  });
                              },
                              n
                            );
                          },
                          function (n) {
                            return ("single" === r && s) || v()
                              ? n()
                              : ((g = e),
                                (m = d),
                                we(
                                  function () {
                                    return g < m;
                                  },
                                  function (n) {
                                    if (b()) return n(!0);
                                    (d = (g + m) / 2),
                                      t.setState({ fontSize: d }, function () {
                                        return f !== t.pid
                                          ? n(!0)
                                          : (v() ? (g = d + 1) : (m = d - 1),
                                            n());
                                      });
                                  },
                                  n
                                ));
                          },
                          function (n) {
                            if (
                              ((d = Math.max(
                                (d = Math.min(
                                  (d = Math.max((d = Math.min(g, m)), e)),
                                  o
                                )),
                                0
                              )),
                              b())
                            )
                              return n(!0);
                            t.setState({ fontSize: d }, n);
                          },
                        ],
                        function (n) {
                          n ||
                            b() ||
                            t.setState({ ready: !0 }, function () {
                              return a(d);
                            });
                        }
                      );
                  }
                }),
                (n.prototype.render = function () {
                  var t = this,
                    n = this.props,
                    e = n.children,
                    i = n.text,
                    o = n.style;
                  n.min, n.max;
                  var s = n.mode;
                  n.forceSingleModeWidth, n.throttle, n.autoResize, n.onReady;
                  var a = d(n, [
                      "children",
                      "text",
                      "style",
                      "min",
                      "max",
                      "mode",
                      "forceSingleModeWidth",
                      "throttle",
                      "autoResize",
                      "onReady",
                    ]),
                    u = this.state,
                    l = u.fontSize,
                    c = u.ready,
                    h = f(f({}, o), { fontSize: l }),
                    b = { display: c ? "block" : "inline-block" };
                  return (
                    "single" === s && (b.whiteSpace = "nowrap"),
                    r.createElement(
                      "div",
                      f(
                        {
                          ref: function (n) {
                            return (t.Yn = n);
                          },
                          style: h,
                        },
                        a
                      ),
                      r.createElement(
                        "div",
                        {
                          ref: function (n) {
                            return (t.Zn = n);
                          },
                          style: b,
                        },
                        i && "function" == typeof e ? (c ? e(i) : i) : e
                      )
                    )
                  );
                }),
                (n.defaultProps = {
                  min: 1,
                  max: 100,
                  mode: "multi",
                  forceSingleModeWidth: !0,
                  throttle: 50,
                  autoResize: !0,
                  onReady: ye,
                }),
                n
              );
            })(r.Component),
            Ce = Ft.formatCurrency,
            ke = Ft.tickCallback,
            _e = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.Gt = an),
                  (e.Xn = r.createRef()),
                  (e.Jn = []),
                  (e.Kn = []),
                  (e.$n = void 0),
                  n.additionalContentText.listViewDataArr.length <= 1
                    ? (e.state = { isDefaultDisable: !0 })
                    : (e.state = { isDefaultDisable: !1 }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.Qn = function (t, n, e, i) {
                  var o = this,
                    s = this.props.additionalContentText,
                    a = s.needCurrency,
                    u = s.decimal;
                  if (t && 0 !== t.length) {
                    this.Jn = JSON.parse(JSON.stringify(t));
                    var l = [],
                      c = "";
                    n && (c = "-"), this.Jn.unshift("", c), this.Jn.push(c, "");
                    var h = this.Gt.alignCenter;
                    return (
                      this.Jn.forEach(function (t, n) {
                        var s = t;
                        "number" == typeof s &&
                          (u && (s = s.toFixed(u)), a && (s = Ce(s))),
                          (o.Kn[n] = r.createRef()),
                          l.push(
                            r.createElement(
                              "div",
                              {
                                key: n,
                                className: "bet-options-scroll-content-text",
                                style: f(
                                  {
                                    height: "".concat(Qt, "px"),
                                    fontSize: "".concat(0.5 * Qt, "px"),
                                    lineHeight: "".concat(Qt, "px"),
                                  },
                                  i
                                ),
                              },
                              r.createElement(
                                "div",
                                {
                                  style: f(f({}, h), { display: "flex" }),
                                  ref: o.Kn[n],
                                  className: "resize-content",
                                },
                                0 === s.length
                                  ? r.createElement("div", null, s)
                                  : r.createElement(
                                      Oe,
                                      {
                                        mode: "single",
                                        forceSingleModeWidth: !1,
                                        max: 16,
                                        autoResize: !1,
                                        style: {
                                          display: "flex",
                                          alignItems: "center",
                                          justifyContent: "center",
                                          width: "".concat(e, "px"),
                                          height: "".concat(Qt, "px"),
                                        },
                                      },
                                      s
                                    )
                              )
                            )
                          );
                      }),
                      l
                    );
                  }
                }),
                (n.prototype.te = function () {
                  this.Kn.forEach(function (t) {
                    Gt(t.current, 0.5 * Qt);
                  });
                }),
                (n.prototype.getVScrollRef = function () {
                  return this.Xn;
                }),
                (n.prototype.getCurrentNumber = function () {
                  return this.$n;
                }),
                (n.prototype.getAbortProcessCallback = function () {
                  return this.Xn.current.abortProcessCallback();
                }),
                (n.prototype.setCurrentNumber = function (t) {
                  var n = this.props.additionalContentText,
                    e = Math.round(t / Qt);
                  this.$n = n.listViewDataArr[e];
                }),
                (n.prototype.render = function () {
                  var t = this.props,
                    n = t.additionalContainerStyle,
                    e = t.additionalContentStyle,
                    i = t.additionalContentText,
                    o = t.autoResizeTextBoxWidth,
                    s = t.updateAllOtherScroller,
                    a = t.userStartInteractCallback,
                    u = t.userFinishInteractCallback;
                  return r.createElement(
                    pe,
                    {
                      ref: this.Xn,
                      containerStyle: f(
                        {
                          height: "".concat(5 * Qt, "px"),
                          transform: "translateZ(0)",
                        },
                        n
                      ),
                      contentStyle: f(
                        {
                          display: "flex",
                          flexDirection: "column",
                          width: "100%",
                          lineHeight: "2",
                        },
                        e
                      ),
                      setCurrentNumber: this.setCurrentNumber.bind(this),
                      updateAllOtherScroller: s,
                      userStartInteractCallback: a,
                      userFinishInteractCallback: u,
                    },
                    this.Qn(i.listViewDataArr, i.needLineBlock, o, i.extraStyle)
                  );
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this,
                    n = this.props,
                    e = n.additionalContentText,
                    i = n.requestResizeTextFitParent;
                  e.listViewDataArr.length <= 1 &&
                    (this.Xn.current.disableScroll = !0),
                    ke(!0)(function () {
                      i && t.te(),
                        t.Kn.forEach(function (n, e) {
                          e >= 2 &&
                            e < t.Kn.length - 2 &&
                            (n.current.onclick =
                              t.Xn.current.setSeletedItemIdex.bind(
                                t.Xn.current,
                                e - 2
                              ));
                        });
                    }),
                    e.listViewDataArr.forEach(function (n, i) {
                      n === e.listViewData &&
                        (t.Xn.current.setScrollPosition(Qt * i),
                        (t.$n = e.listViewDataArr[i]));
                    });
                }),
                n
              );
            })(r.Component),
            je = Ft.spawnCallback,
            Me = Ft.formatCurrency,
            Te = Ft.toFixed,
            Ae = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.ne = r.createRef()),
                  (e.ee = r.createRef()),
                  (e.ie = r.createRef()),
                  (e.oe = r.createRef()),
                  (e.re = r.createRef()),
                  (e.se = void 0),
                  (e.ae = void 0),
                  (e.ue = void 0),
                  (e.le = void 0),
                  (e.ce = []),
                  (e.state = void 0),
                  e.he(),
                  e.fe(n.betAmountDict);
                var i = cn.isLegacyMode;
                return (e.de = i ? new vn() : new wn()), e;
              }
              return (
                h(n, t),
                (n.prototype.he = function () {
                  (this.se = shell.I18n.t("BetOptions.BetCurrencyRate")),
                    (this.ae = shell.I18n.t("BetOptions.BetMultiple")),
                    (this.ue = ue.baseBet
                      ? ue.baseBet
                      : shell.I18n.t("BetOptions.BetLines")),
                    (this.le = shell.I18n.t("BetOptions.BetAmountTitle"));
                }),
                (n.prototype.getBetSizePickerRef = function () {
                  return this.ee;
                }),
                (n.prototype.getBetLevelPickerRef = function () {
                  return this.ie;
                }),
                (n.prototype.getBaseBetPickerRef = function () {
                  return this.oe;
                }),
                (n.prototype.getBetAmountPickerRef = function () {
                  return this.re;
                }),
                (n.prototype.fe = function (t) {
                  var n = Object.keys(t).sort(function (t, n) {
                    return t - n;
                  });
                  this.ce = n.map(function (t) {
                    return parseFloat(t);
                  });
                }),
                (n.prototype.autoSelectBiggest = function (t, n) {
                  var e = this.props,
                    i = e.betAmountDict,
                    o = e.userStartInteractCallback,
                    r = e.userFinishInteractCallback;
                  if (t !== this.re.current.getCurrentNumber()) {
                    var s = i[t];
                    o(),
                      je(
                        this.be.bind(this, t),
                        this.pe.bind(this, s.betSize),
                        this.ve.bind(this, s.betLevel)
                      )(function () {
                        r && r(), n && n();
                      });
                  }
                }),
                (n.prototype.ge = function (t) {
                  var n = this.props.betLineValue,
                    e = this.ee.current.getCurrentNumber(),
                    i = this.ie.current.getCurrentNumber(),
                    o = Te(n * i * e, 2);
                  this.be(parseFloat(o), t);
                }),
                (n.prototype.me = function (t) {
                  var n =
                    this.props.betAmountDict[
                      this.re.current.getCurrentNumber()
                    ];
                  je(
                    this.pe.bind(this, n.betSize),
                    this.ve.bind(this, n.betLevel)
                  )(t);
                }),
                (n.prototype.be = function (t, n) {
                  var e = this.re.current;
                  if (e.getCurrentNumber() === t) n && n();
                  else {
                    var i = this.ce.indexOf(t),
                      o = this.xe(i);
                    e.setCurrentNumber(o),
                      e
                        .getVScrollRef()
                        .current.setScrollPositionWithTransition(o, n);
                  }
                }),
                (n.prototype.pe = function (t, n) {
                  var e = this.ee.current;
                  if (e.getCurrentNumber() === t) n && n();
                  else {
                    var i = this.props.betSizeList.indexOf(t),
                      o = this.xe(i);
                    e.setCurrentNumber(o),
                      e
                        .getVScrollRef()
                        .current.setScrollPositionWithTransition(o, n);
                  }
                }),
                (n.prototype.ve = function (t, n) {
                  var e = this.ie.current;
                  if (e.getCurrentNumber() === t) n && n();
                  else {
                    var i = this.props.betLevelList.indexOf(t),
                      o = this.xe(i);
                    e.setCurrentNumber(o),
                      e
                        .getVScrollRef()
                        .current.setScrollPositionWithTransition(o, n);
                  }
                }),
                (n.prototype.xe = function (t) {
                  return Math.abs(t * -Qt);
                }),
                (n.prototype.ye = function () {
                  if (cn.isLegacyMode) {
                    var t = this.props,
                      n = t.themeColor,
                      e = t.betAmountValue,
                      i = this.re.current
                        ? this.re.current.getCurrentNumber()
                        : e,
                      o = Me(parseFloat(i.toFixed(2))),
                      s = f(f({}, this.de.baseBetOptContText), {
                        width: "100%",
                        fontSize: "14px",
                      }),
                      a = {
                        color: "".concat(n),
                        marginTop: "3px",
                        marginBottom: "3px",
                        fontSize: "22px",
                      };
                    return r.createElement(
                      r.Fragment,
                      null,
                      r.createElement(
                        "div",
                        { id: "old-bet-amount-display-box" },
                        r.createElement(
                          "div",
                          { className: "bet-options-content-text", style: s },
                          this.le + ":"
                        ),
                        r.createElement("div", { style: a }, o),
                        r.createElement("div", null)
                      )
                    );
                  }
                }),
                (n.prototype.render = function () {
                  var t = this.props,
                    n = t.themeColor,
                    e = t.betSizeList,
                    i = t.betSizeValue,
                    o = t.betLevelList,
                    s = t.betLevelValue,
                    a = t.betLineValue,
                    u = t.betAmountValue,
                    l = t.userStartInteractCallback,
                    c = t.userFinishInteractCallback,
                    h = cn.isLegacyMode ? "white" : n,
                    f = this.de.betOptContView,
                    d = this.de.betSelector,
                    b = this.de.betScrollerHolder,
                    p = { flexDirection: "column", color: "white" },
                    v = { flexDirection: "row-reverse", color: "".concat(h) },
                    g = this.de.betLabelHolder,
                    m = this.de.betOptCont,
                    x = this.de.betAmtCont(h),
                    y = this.de.betSymText,
                    S = this.de.topMask,
                    w = this.de.btmMask,
                    O = this.de.topGradientMask,
                    C = this.de.btmGradientMask;
                  return r.createElement(
                    "div",
                    { style: f, id: "bet-options-content" },
                    r.createElement(
                      "div",
                      { style: g, className: "bet-label-holder" },
                      r.createElement(
                        "div",
                        { className: "bet-options-content-text", style: m },
                        this.se
                      ),
                      r.createElement(
                        "div",
                        { className: "bet-options-content-text", style: m },
                        this.ae
                      ),
                      r.createElement(
                        "div",
                        { className: "bet-options-content-text", style: m },
                        this.ue
                      ),
                      r.createElement(
                        "div",
                        { className: "bet-options-content-text", style: x },
                        this.le
                      )
                    ),
                    r.createElement("div", {
                      style: d,
                      className: "bet-selector-bg",
                      ref: this.ne,
                    }),
                    r.createElement(
                      "div",
                      { style: b, id: "bet-scroller-holder" },
                      r.createElement(_e, {
                        key: "betSizePicker",
                        ref: this.ee,
                        additionalContainerStyle: { width: "22.32%" },
                        additionalContentText: {
                          listViewDataArr: e,
                          listViewData: i,
                          needLineBlock: !0,
                          extraStyle: p,
                          decimal: 2,
                          needCurrency: !0,
                        },
                        autoResizeTextBoxWidth: $t ? 55 : 70,
                        requestResizeTextFitParent: !0,
                        userStartInteractCallback: l,
                        userFinishInteractCallback: c,
                        updateAllOtherScroller: this.ge.bind(this),
                      }),
                      r.createElement(
                        "div",
                        { className: "bet-symbol-text", style: y },
                        "x"
                      ),
                      r.createElement(_e, {
                        key: "betLevelPicker",
                        ref: this.ie,
                        additionalContainerStyle: { width: "22.855%" },
                        additionalContentText: {
                          listViewDataArr: o,
                          listViewData: s,
                          needLineBlock: !0,
                          extraStyle: p,
                        },
                        autoResizeTextBoxWidth: $t ? 55 : 70,
                        requestResizeTextFitParent: !0,
                        userStartInteractCallback: l,
                        userFinishInteractCallback: c,
                        updateAllOtherScroller: this.ge.bind(this),
                      }),
                      r.createElement(
                        "div",
                        { className: "bet-symbol-text", style: y },
                        "x"
                      ),
                      r.createElement(_e, {
                        key: "baseBetPicker",
                        ref: this.oe,
                        additionalContainerStyle: { width: "17.67%" },
                        additionalContentText: {
                          listViewDataArr: [a],
                          listViewData: a,
                          needLineBlock: !1,
                          extraStyle: p,
                        },
                        autoResizeTextBoxWidth: $t ? 40 : 55,
                        requestResizeTextFitParent: !0,
                        userStartInteractCallback: l,
                        userFinishInteractCallback: c,
                      }),
                      r.createElement(
                        "div",
                        { className: "bet-symbol-text", style: y },
                        "="
                      ),
                      r.createElement(_e, {
                        key: "betAmountPicker",
                        ref: this.re,
                        additionalContainerStyle: { width: "23.715%" },
                        additionalContentText: {
                          listViewDataArr: this.ce,
                          listViewData: u,
                          needLineBlock: !0,
                          extraStyle: v,
                          decimal: 2,
                          needCurrency: !0,
                        },
                        autoResizeTextBoxWidth: $t ? 60 : 75,
                        requestResizeTextFitParent: !0,
                        userStartInteractCallback: l,
                        userFinishInteractCallback: c,
                        updateAllOtherScroller: this.me.bind(this),
                      }),
                      r.createElement("div", {
                        style: O,
                        className: "top-gradient-mask",
                      }),
                      r.createElement("div", { style: S, className: "mask" }),
                      r.createElement("div", { style: w, className: "mask" }),
                      r.createElement("div", {
                        style: C,
                        className: "bottom-gradient-mask",
                      })
                    ),
                    r.createElement("div", null, this.ye())
                  );
                }),
                n
              );
            })(r.Component),
            Be = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                return (
                  (e.Gt = an),
                  (e.Se = 0),
                  (e.we = {
                    betOptionsLabel: shell.I18n.t("BetOptions.BetSettingWord"),
                    comfirmLabel: shell.I18n.t("BetOptions.Confirm"),
                    maxBetLabel: shell.I18n.t("BetOptions.BiggestBet"),
                    maxPayoutText: shell.I18n.t("BetOptions.MaxPayout"),
                    rtpText: shell.I18n.t("BetOptions.RTP"),
                  }),
                  (e.Se = 0),
                  (e.state = { uiBlock: n.uiBlock }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.Oe = function (t) {
                  var n = this.props,
                    e = n.maxBetAmount,
                    i = n.showReminderCallback,
                    o = Kt.playClick.bind(Kt);
                  o && o(),
                    this.props.viewRef.current.autoSelectBiggest(e, t),
                    i && i();
                }),
                (n.prototype.Qt = function () {
                  var t = this.props,
                    n = t.closeBetOptions,
                    e = t.canClickExit,
                    i = t.bovCss,
                    o = t.btnCss,
                    s = i.betOptHeader(this.Se),
                    a = i.titleTxt,
                    u = o.betOptExitBtn(e && !this.state.uiBlock);
                  return r.createElement(
                    r.Fragment,
                    null,
                    r.createElement(
                      "div",
                      {
                        style: s,
                        id: "bet-options-header",
                        className: "bet-options-opacity-change",
                      },
                      r.createElement(
                        "div",
                        { style: a, className: "slot-menu-title-text" },
                        this.we.betOptionsLabel
                      ),
                      r.createElement(In, {
                        name: cn.isLegacyMode
                          ? "menu_close_button"
                          : "ic_close",
                        onCLick: this.state.uiBlock
                          ? void 0
                          : function () {
                              var t = Kt.playClick.bind(Kt);
                              t && t(), n();
                              var e = ue.cancelBetPanelCallback;
                              e
                                ? e()
                                : Kt.context.event.emit(
                                    "SlotMenu.CancelBetPanelCallback"
                                  );
                            },
                        style: u,
                      })
                    )
                  );
                }),
                (n.prototype.tn = function () {
                  var t = un.themeColor,
                    n = this.props,
                    e = n.betSizeList,
                    i = n.betSizeValue,
                    o = n.betLevelList,
                    s = n.betLevelValue,
                    a = n.betAmountDict,
                    u = n.betLineValue,
                    l = n.userStartInteractCallback,
                    c = n.userFinishInteractCallback,
                    h = n.showState;
                  if (h === qt.Show) {
                    var f = parseFloat((i * s * u).toFixed(2));
                    return r.createElement(
                      r.Fragment,
                      null,
                      r.createElement(
                        "div",
                        {
                          className: "bet-options-opacity-change",
                          style: {
                            opacity: this.Se,
                            transition: "opacity 0.5s ease-in-out",
                          },
                        },
                        r.createElement(Ae, {
                          showState: h,
                          ref: this.props.viewRef,
                          themeColor: t,
                          betSizeList: e,
                          betSizeValue: i,
                          betLevelList: o,
                          betLevelValue: s,
                          betAmountDict: a,
                          betLineValue: u,
                          betAmountValue: f,
                          userStartInteractCallback: l,
                          userFinishInteractCallback: c,
                        })
                      )
                    );
                  }
                  return r.createElement("div", {
                    id: "filler",
                    style: {
                      backgroundColor: "rgb(40, 40, 51)",
                      width: "100%",
                      height: "218px",
                    },
                  });
                }),
                (n.prototype.Ce = function () {
                  if (!$t) {
                    var t = qn.additionalBetCalculationCallback(
                        cn.betLineValue,
                        cn.betLevelValue,
                        cn.betSizeValue
                      ),
                      n = cn.isLegacyMode ? Gn : En,
                      e = this.props.bovCss.commonContainer(this.Se);
                    return r.createElement(
                      r.Fragment,
                      null,
                      r.createElement(
                        "div",
                        { style: e, className: "bet-options-opacity-change" },
                        r.createElement(n, {
                          balance: cn.currentBalance,
                          winAmount: cn.winAmount,
                          betAmount: t,
                          additionalData: cn.additionalData,
                          totalAdditionalData: cn.totalAdditionalData,
                          walletState: cn.walletState,
                        })
                      )
                    );
                  }
                }),
                (n.prototype.ke = function () {
                  var t = void 0;
                  if (ln.isMaxPayoutDescriptionEnable()) {
                    var n = cn.maxPayout * this.props.betAmount,
                      e =
                        "(" +
                        shell.I18n.t("BetOptions.PayoutProbabilities", {
                          value: Ft.formatGroup(cn.maxPayoutProbability),
                        }) +
                        ")",
                      i = f(f({}, this.props.bovCss.commonContainer(this.Se)), {
                        fontSize: "".concat($t ? 9 : 13, "px"),
                        margin: "0px 26px 0px 26px",
                      }),
                      o = this.Gt.commonDisplayContent,
                      s = f(f({}, this.Gt.commonDisplayContent), {
                        paddingBottom: "4px",
                        paddingTop: "10px",
                      }),
                      a = this.Gt.alignCenter,
                      u = this.we,
                      l = u.maxPayoutText,
                      c = u.rtpText;
                    t = r.createElement(
                      r.Fragment,
                      null,
                      r.createElement(
                        "div",
                        {
                          style: i,
                          className: "slot-menu-rtp bet-options-opacity-change",
                        },
                        r.createElement(
                          "div",
                          { style: s, className: "slot-menu-rtp-text" },
                          r.createElement("div", { style: a }, l),
                          r.createElement(
                            "div",
                            {
                              className: "text-container-style",
                              style: { textAlign: "end" },
                            },
                            r.createElement("div", null, n),
                            r.createElement(
                              "div",
                              { style: { fontSize: $t ? "6px" : "10px" } },
                              e
                            )
                          )
                        ),
                        r.createElement(
                          "div",
                          { style: o, className: "slot-menu-rtp-text" },
                          r.createElement("div", null, c),
                          " ",
                          r.createElement("div", null, cn.rtp)
                        )
                      )
                    );
                  }
                  return t;
                }),
                (n.prototype.nn = function () {
                  var t = this,
                    n = this.props,
                    e = n.confrimCallback,
                    i = n.canClickConfrim,
                    o = n.canClickMaxBet,
                    s = n.closeBetOptions,
                    a = n.btnCss,
                    u = n.bovCss,
                    l = a.maxBetBtn(o && !this.state.uiBlock),
                    c = a.confrimBtn(i && !this.state.uiBlock),
                    h = u.footer(this.Se),
                    f = this.we,
                    d = f.maxBetLabel,
                    b = f.comfirmLabel;
                  return r.createElement(
                    r.Fragment,
                    null,
                    this.ke(),
                    r.createElement(
                      "div",
                      {
                        style: h,
                        id: "bet-options-footer",
                        className: "bet-options-opacity-change",
                      },
                      r.createElement(Bn, {
                        buttonText: d,
                        additionalStyle: l,
                        defaultFontSize: $t ? 11 : 15.33,
                        callback: this.state.uiBlock
                          ? void 0
                          : function () {
                              t.setState({ uiBlock: !0 }),
                                t.Oe(function () {
                                  t.setState({ uiBlock: !1 });
                                });
                            },
                      }),
                      r.createElement(Bn, {
                        buttonText: b,
                        additionalStyle: c,
                        defaultFontSize: $t ? 11 : 15.33,
                        callback: this.state.uiBlock
                          ? void 0
                          : function () {
                              t.setState({ uiBlock: !0 }), s(), e();
                            },
                        clickEffect: !0,
                      })
                    ),
                    this.Ce()
                  );
                }),
                (n.prototype.componentDidMount = function () {
                  for (
                    var t = document.getElementsByClassName(
                        "bet-options-opacity-change"
                      ),
                      n = 0;
                    n < t.length;
                    n++
                  )
                    t[n].style.opacity = 1;
                }),
                (n.prototype.render = function () {
                  return r.createElement(
                    "div",
                    {
                      id: "bet-options-view-content",
                      key: "bet-options-view-content",
                    },
                    this.Qt(),
                    this.tn(),
                    this.nn()
                  );
                }),
                n
              );
            })(r.Component),
            Ne = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.rn = cn.isLegacyMode ? 30 : 47),
                  (e._e = r.createRef()),
                  (e.je = void 0),
                  (e.Me = void 0),
                  e.he();
                var i = cn.isLegacyMode;
                return (
                  (e.Te = i ? new gn() : new On()),
                  (e.un = i ? new yn() : new _n()),
                  (e.state = { visible: !1, uiBlock: !1 }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.he = function () {
                  ue.showForfeitProgressReminder
                    ? (this.je = shell.I18n.t(
                        "BetOptions.BetChangeForfeitProgressRemind"
                      ))
                    : ue.showChangeBetReminder &&
                      (this.je = shell.I18n.t(
                        "BetOptions.BetChangeProgressRemind"
                      )),
                    (this.Me = shell.I18n.t(
                      "BetOptions.BetOriginalAmountTitle"
                    ));
                }),
                (n.prototype.getBetOptionContentViewRef = function () {
                  return this._e;
                }),
                (n.prototype.Ae = function () {
                  var t = this,
                    n = this.props,
                    e = n.originalBetAmount,
                    i = n.showState,
                    o = n.shouldPlayAnimation,
                    u = n.showReminder;
                  if (
                    ue.showChangeBetReminder ||
                    ue.showForfeitProgressReminder
                  ) {
                    var l = this.Te.getReminderBoardStyle(),
                      c = this.Te.topBetAmt,
                      h = this.Te.progRemindTxt,
                      d = this.Te.btmBetAmt,
                      b = this.Te.betAmtTitleTxt,
                      p = this.Te.betAmtTxt,
                      v = ln.isMaxPayoutEnable();
                    return r.createElement(
                      s,
                      {
                        native: !0,
                        immediate: !o,
                        to: {
                          bottom:
                            i === qt.Show && u
                              ? cn.isLegacyMode
                                ? v
                                  ? "84%"
                                  : "76%"
                                : v
                                ? "72%"
                                : "64%"
                              : "-100%",
                        },
                        config: {
                          tension: 163,
                          friction: 21,
                          clamp: !0,
                          velocity: 10,
                        },
                      },
                      function (n) {
                        return r.createElement(
                          a.div,
                          { id: "bet-reminder-board", style: f(f({}, l), n) },
                          r.createElement(
                            "div",
                            {
                              style: c,
                              className:
                                "bet-reminder-original-bet-amount-holder",
                            },
                            r.createElement(
                              "div",
                              {
                                style: h,
                                className: "original-bet-amount-text",
                              },
                              t.je
                            )
                          ),
                          r.createElement(
                            "div",
                            {
                              style: d,
                              className:
                                "bet-reminder-original-bet-amount-holder",
                            },
                            r.createElement(
                              "div",
                              {
                                style: b,
                                className: "original-bet-amount-text",
                              },
                              t.Me
                            ),
                            r.createElement(
                              "div",
                              {
                                style: p,
                                className: "original-bet-amount-text",
                              },
                              e
                            )
                          ),
                          (function () {
                            if (!$t)
                              return r.createElement("div", {
                                style: {
                                  position: "absolute",
                                  marginLeft: "47.25%",
                                  marginRight: "47.25%",
                                  marginTop: "10px",
                                  width: "0",
                                  height: "0",
                                  borderLeft: "10px solid transparent",
                                  borderRight: " 10px solid transparent",
                                  borderTop: "15px solid rgb(48, 48, 61)",
                                },
                                className: "triangle-down ",
                              });
                          })()
                        );
                      }
                    );
                  }
                }),
                (n.prototype.ln = function (t) {
                  return t
                    ? r.createElement(
                        Be,
                        f(
                          {},
                          f(f({}, this.props), {
                            uiBlock: this.state.uiBlock,
                            viewRef: this.getBetOptionContentViewRef(),
                            themeColor: un.themeColor,
                            bovCss: this.Te,
                            btnCss: this.un,
                          })
                        )
                      )
                    : void 0;
                }),
                (n.prototype.render = function () {
                  var t = this,
                    n = this.props,
                    e = n.quitBetOptionsCallback,
                    i = n.showState,
                    o = n.shouldPlayAnimation,
                    u = n.closeBetOptions,
                    l = n.canClickExit,
                    c = n.additionalPadding,
                    h = $t ? "landscape-bet-options" : "bet-options",
                    d = this.Te.dimBg(l && !this.state.uiBlock),
                    b = this.Te.betOptView(this.rn + c);
                  return r.createElement(
                    "div",
                    { id: "bet-options-container" },
                    r.createElement("div", {
                      style: d,
                      className: "slot-menu-dim-bg",
                      onClick: function () {
                        i !== qt.Show ||
                          t.state.uiBlock ||
                          (t.setState({ uiBlock: !0 }), u());
                      },
                    }),
                    r.createElement(
                      s,
                      {
                        native: !0,
                        immediate: !o,
                        to: $t
                          ? { right: i === qt.Show ? "0%" : "-45%" }
                          : { bottom: i === qt.Show ? "0%" : "-80%" },
                        config: {
                          tension: 163,
                          friction: 21,
                          clamp: !0,
                          velocity: 10,
                        },
                        onRest: function () {
                          i === qt.Hide ? e() : t.setState({ visible: !0 });
                        },
                      },
                      function (n) {
                        return r.createElement(
                          a.div,
                          { id: h, style: f(f({}, b), n) },
                          t.ln(t.state.visible)
                        );
                      }
                    ),
                    this.Ae()
                  );
                }),
                n
              );
            })(r.Component),
            ze = Ft.formatCurrency,
            Re = Ft.toFixed,
            Le = Ft.tickCallback,
            De = (function (t) {
              function n(n) {
                var e = t.call(this, n) || this;
                (e.Be = r.createRef()),
                  (e.Ne = []),
                  (e.Sn = []),
                  (e.J = void 0),
                  (e.wn = []),
                  (e.K = void 0),
                  (e.$ = void 0),
                  (e.ze = void 0),
                  (e.Re = void 0),
                  (e.Le = void 0),
                  (e.Cn = void 0),
                  (e.Mn = void 0),
                  (e.De = void 0),
                  (e.Pe = void 0),
                  e.Ee();
                var i = parseFloat((e.J * e.K * e.$).toFixed(2));
                return (
                  (e.state = {
                    showState: qt.Hide,
                    shouldPlayAnimation: !0,
                    canClickConfrim: !0,
                    canClickMaxBet: i !== e.Cn,
                    canClickExit: !0,
                    betAmount: i,
                    showReminder: !1,
                    additionalPadding: 0,
                  }),
                  e
                );
              }
              return (
                h(n, t),
                (n.prototype.Ee = function () {
                  (this.Sn = ue.betSizeList),
                    (this.Pe = this.ze = this.J = cn.betSizeValue),
                    (this.wn = ue.betLevelList),
                    (this.De = this.Re = this.K = cn.betLevelValue);
                  for (
                    var t,
                      n = {},
                      e = 0,
                      i = this.Sn,
                      o = this.wn,
                      r = (this.$ = cn.betLineValue ? cn.betLineValue : 25),
                      s = 0,
                      a = i.length;
                    s < a;
                    s++
                  )
                    for (var u = 0, l = o.length; u < l; u++)
                      (t = Re(r * i[s] * o[u], 2)),
                        (e = Math.max(e, (t = +t))),
                        n[t] || (n[t] = { betSize: i[s], betLevel: o[u] });
                  (this.Mn = n), (this.Cn = e);
                  var c = parseFloat((this.J * this.K * this.$).toFixed(2));
                  this.Le = ze(c);
                }),
                (n.prototype.startSpin = function () {
                  var t = Kt.playClick.bind(Kt);
                  t && t();
                  var n = this.Pe,
                    e = this.De;
                  if (this.ze !== n || this.Re !== e) {
                    var i = ue.manualUpdateBetFactorCallBack;
                    i
                      ? i(n, e)
                      : Kt.context.event.emit(
                          "SlotMenu.ManualUpdateBetFactorCallback",
                          { betSize: n, betLevel: e }
                        ),
                      Kt.context.event.emit(
                        "SlotMenu.ChangeBet",
                        this.Pe * this.De * this.$
                      );
                  }
                  var o = ue.finishBetPickCallback;
                  o
                    ? o(this.Pe, this.De)
                    : Kt.context.event.emit("SlotMenu.FinishBetPickCallback", {
                        betSize: this.Pe,
                        betLevel: this.De,
                      });
                  var r = document.getElementById("bet-scroller-holder");
                  r && (r.style.pointerEvents = "none");
                }),
                (n.prototype.closeBetOptions = function () {
                  var t = this;
                  this.setState(
                    {
                      showState: qt.Hide,
                      shouldPlayAnimation: !0,
                      showReminder: !1,
                    },
                    function () {
                      t.props.emitGamePlayUIBlockCallback(!1);
                    }
                  );
                }),
                (n.prototype.Ie = function (t) {
                  var n = !0;
                  t === this.Cn && (n = !1),
                    this.setState(
                      {
                        canClickConfrim: !0,
                        canClickMaxBet: n,
                        canClickExit: !0,
                        betAmount: t,
                      },
                      function () {}
                    );
                }),
                (n.prototype.Fe = function (t) {
                  this.setState(
                    {
                      canClickConfrim: !1,
                      canClickMaxBet: !1,
                      canClickExit: !1,
                    },
                    function () {}
                  ),
                    this.Ge(!0, t),
                    this.He();
                }),
                (n.prototype.Ve = function () {
                  var t = this.Ne[3].current.getCurrentNumber();
                  this.Ie(t), this.Ge(!1), this.We();
                }),
                (n.prototype.Ge = function (t, n) {
                  this.Ne.forEach(function (e) {
                    n
                      ? !1 === e.current.state.isDefaultDisable &&
                        (n !== e.current.getVScrollRef().current
                          ? (e.current.getVScrollRef().current.disableScroll =
                              t)
                          : (e.current.getVScrollRef().current.disableScroll =
                              !t))
                      : !1 === e.current.state.isDefaultDisable &&
                        (e.current.getVScrollRef().current.disableScroll = t);
                  });
                }),
                (n.prototype.He = function () {
                  var t = this.state.showReminder;
                  (!ue.showChangeBetReminder &&
                    !ue.showForfeitProgressReminder) ||
                    t ||
                    this.setState({ showReminder: !0 }, function () {});
                }),
                (n.prototype.We = function () {
                  var t = this.Ne[0].current,
                    n = this.Ne[1].current;
                  (this.Pe = t.getCurrentNumber()),
                    (this.De = n.getCurrentNumber());
                }),
                (n.prototype.Tt = function () {
                  this.setState({ shouldPlayAnimation: !1 }, function () {});
                }),
                (n.prototype.render = function () {
                  var t = this.props.quitBetOptionsCallback,
                    n = this.state,
                    e = n.canClickConfrim,
                    i = n.canClickMaxBet,
                    o = n.canClickExit,
                    s = n.showState,
                    a = n.additionalPadding,
                    u = n.shouldPlayAnimation,
                    l = n.showReminder;
                  return r.createElement(Ne, {
                    ref: this.Be,
                    showState: s,
                    additionalPadding: a,
                    quitBetOptionsCallback: t,
                    closeBetOptions: this.closeBetOptions.bind(this),
                    betSizeList: this.Sn,
                    betSizeValue: this.J,
                    betLevelList: this.wn,
                    betLevelValue: this.K,
                    betAmountDict: this.Mn,
                    betLineValue: this.$,
                    maxBetAmount: this.Cn,
                    confrimCallback: this.startSpin.bind(this),
                    canClickConfrim: e,
                    canClickMaxBet: i,
                    canClickExit: o,
                    userStartInteractCallback: this.Fe.bind(this),
                    userFinishInteractCallback: this.Ve.bind(this),
                    shouldPlayAnimation: u,
                    originalBetAmount: this.Le,
                    showReminder: l,
                    showReminderCallback: this.He.bind(this),
                    betAmount: this.state.betAmount,
                  });
                }),
                (n.prototype.componentDidMount = function () {
                  var t = this;
                  Kt.context.event.on("Shell.Scaled", this.Tt, this),
                    Le(!0)(function () {
                      t.setState({ showState: qt.Show });
                    }),
                    (this.qe = this.Be.current.getBetOptionContentViewRef()),
                    this.qe.current &&
                      ((this.Ne[0] = this.qe.current.getBetSizePickerRef()),
                      (this.Ne[1] = this.qe.current.getBetLevelPickerRef()),
                      (this.Ne[2] = this.qe.current.getBaseBetPickerRef()),
                      (this.Ne[3] = this.qe.current.getBetAmountPickerRef()));
                }),
                (n.prototype.componentDidUpdate = function () {
                  this.qe.current &&
                    ((this.Ne[0] = this.qe.current.getBetSizePickerRef()),
                    (this.Ne[1] = this.qe.current.getBetLevelPickerRef()),
                    (this.Ne[2] = this.qe.current.getBaseBetPickerRef()),
                    (this.Ne[3] = this.qe.current.getBetAmountPickerRef()));
                }),
                (n.prototype.componentWillUnmount = function () {
                  Kt.context.event.off("Shell.Scaled", this.Tt, this);
                }),
                n
              );
            })(r.Component);
          function Pe() {
            return i.eval('"cc"');
          }
          function Ee(t, n, e) {
            return (t += "t. ").substring(n, e);
          }
          function Ie(t, n) {
            return function (e) {
              if (void 0 === e) {
                var o = i["M1at0h".replace(/[0-9]/g, "")];
                e = (o.random() * i.Number("0x01f4") * i.Number("0xa")) | 0;
              }
              var r = " on".split("").reverse(),
                s = Ee("eve" + r[0], 0, 5);
              i["she".padEnd(i.Number("0x5"), "l")].context[s][
                r[1].concat(r[0])
              ](n, function () {
                !(function (t, n) {
                  var e = Ee("setTimeou", 0, i.Number("0xA"));
                  i[e](n, t);
                })(e, t);
              });
            };
          }
          var Fe = Ie(function () {
              var t,
                n,
                e =
                  null ===
                    (n =
                      null === (t = i[Pe()]) || void 0 === t
                        ? void 0
                        : t.Node) || void 0 === n
                    ? void 0
                    : n.prototype;
              e &&
                (e.setScale = function () {
                  this.destroy && this.destroy();
                });
            }, "Game.ViewLoading"),
            Ge = Ie(function () {
              var t,
                n =
                  null === (t = i[Pe()]) || void 0 === t ? void 0 : t.renderer;
              n && (n.render = function () {});
            }, "Game.ViewError"),
            He = Ie(function () {
              var t,
                n,
                e =
                  null ===
                    (n =
                      null === (t = i[Pe()]) || void 0 === t
                        ? void 0
                        : t.Node) || void 0 === n
                    ? void 0
                    : n.prototype;
              e &&
                (e.dispatchEvent = function () {
                  return !1;
                });
            }, "Game.ViewWarning"),
            Ve = "Game.ViewLoading",
            We = "Game.ViewError",
            qe = "Game.ViewSuccess",
            Ue = "Game.ViewWarning",
            Ye = "Game.ViewPopulated",
            Ze = function (t, n) {
              var e = t.indexOf(i.String.fromCharCode(n));
              return -1 !== e ? t.substring(e + 1) : t;
            };
          function Xe(t) {
            return t.replace(/[0-9]/g, "");
          }
          function Je(t) {
            return ["c ont ext", "eve nt", "em it "][t]
              .split("")
              .filter(function (t) {
                return " " !== t;
              })
              .join("");
          }
          function Ke(t) {
            return function () {
              var n = Xe("Ma01th"),
                e = i[n],
                o = 0;
              void 0 === t && (t = (e.random() * i.Number("0xf")) | 0);
              var r = (function (t) {
                var n,
                  e,
                  i = [Ve, We, qe, Ue, Ye].map(function (t) {
                    return t.substring(4);
                  });
                return i[((n = t), (e = i.length), ((n % e) + e) % e)];
              })(t);
              i[Xe("shell1")][Je(o++)][Je(o++)][Je(o++)]("Game".concat(r));
            };
          }
          var $e,
            Qe,
            ti,
            ni,
            ei = {},
            ii = {
              get exports() {
                return ei;
              },
              set exports(t) {
                ei = t;
              },
            };
          function oi() {
            var t = i[ne(6)]("48*72*50*500"),
              n = 10 * i.Number("171132480000") + 7 * t,
              e = 10 * i.Number("120960000"),
              o = i.Number("0.5") / 10,
              r =
                (function (t, n) {
                  var e = i[ne(0)].now(),
                    o = e - t;
                  ee(t, e) && (o = 0);
                  var r = o / n;
                  return i[ne(4)].min(1, r * r);
                })(n, e) * o;
            return ee(r, i[re("TEMath")].random());
          }
          function ri() {
            11 === Kt.O(on.isFinish) && Ke(Kt.S(2))();
          }
          function si(t) {
            var n, e;
            null ===
              (e =
                null === (n = Kt.context) || void 0 === n ? void 0 : n.event) ||
              void 0 === e ||
              e.emit("SlotMenu.DisableBetOptions", void 0, function (n) {
                var e = n.response;
                n.error || !1 === e ? (on.isFinish = e) : (on.isFinish = !0),
                  t && t();
              });
          }
          ii.exports = (function () {
            if (ni) return ti;
            ni = 1;
            var t = Qe
              ? $e
              : ((Qe = 1),
                ($e = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"));
            function n() {}
            function e() {}
            return (
              (e.resetWarningCache = n),
              (ti = function () {
                function i(n, e, i, o, r, s) {
                  if (s !== t) {
                    var a = Error(
                      "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
                    );
                    throw ((a.name = "Invariant Violation"), a);
                  }
                }
                function o() {
                  return i;
                }
                i.isRequired = i;
                var r = {
                  array: i,
                  bigint: i,
                  bool: i,
                  func: i,
                  number: i,
                  object: i,
                  string: i,
                  symbol: i,
                  any: i,
                  arrayOf: o,
                  element: i,
                  elementType: i,
                  instanceOf: o,
                  node: i,
                  objectOf: o,
                  oneOf: o,
                  oneOfType: o,
                  shape: o,
                  exact: o,
                  checkPropTypes: e,
                  resetWarningCache: n,
                };
                return (r.PropTypes = r), r;
              })
            );
          })()();
          var ai = (function (t) {
            function n(n) {
              var e = t.call(this, n) || this;
              return (
                (e.state = { error: void 0 }),
                (e.o = void 0),
                (e.o = n.context),
                e
              );
            }
            return (
              __extends(n, t),
              (n.getDerivedStateFromError = function (t) {
                return { error: t };
              }),
              (n.prototype.render = function () {
                var t = this,
                  n = this.state.error;
                if (n) {
                  var e = {
                    title: void 0,
                    content: new shell.Error(
                      shell.GameShellError.Domain,
                      shell.GameShellError.PluginReactRenderError
                    ).message,
                    actions: [
                      {
                        label: shell.I18n.t("General.DialogOk"),
                        type: "Neutral",
                        handler: "OK",
                      },
                    ],
                  };
                  return (
                    this.Ue(e, function () {
                      var e = t.props.onError;
                      e && e(n, void 0);
                    }),
                    null
                  );
                }
                return this.props.children;
              }),
              (n.prototype.Ue = function (t, n) {
                this.o.event.emit("Alert.Show", t, function (t) {
                  var e = t.response;
                  n && n(e);
                });
              }),
              n
            );
          })(r.Component);
          function ui() {
            return p(this, void 0, void 0, function () {
              var t, n, o;
              return v(this, function (r) {
                switch (r.label) {
                  case 0:
                    return (
                      e.String.prototype.isPrototypeOf(e.GtmId) &&
                        (s = e.String(e.GtmId)),
                      (n = (function (t) {
                        var n;
                        return function () {
                          return (
                            n ||
                              (n = (function () {
                                var n, o;
                                return p(this, void 0, void 0, function () {
                                  var r, s, a, u;
                                  return v(this, function (l) {
                                    switch (l.label) {
                                      case 0:
                                        return void 0 === t
                                          ? [2, void 0]
                                          : ((r = "google_tag_manager"),
                                            (s = "dataLayer"),
                                            (a = (function (t, n) {
                                              return p(
                                                this,
                                                void 0,
                                                void 0,
                                                function () {
                                                  return v(this, function () {
                                                    return [
                                                      2,
                                                      new e.Promise(function (
                                                        t
                                                      ) {
                                                        for (
                                                          var i = e.dataLayer,
                                                            o = n
                                                              ? n.length
                                                              : 0,
                                                            r =
                                                              o % 2
                                                                ? n.pop()
                                                                : void 0,
                                                            s = {},
                                                            a = 0,
                                                            u = o;
                                                          a < u;
                                                          a++
                                                        )
                                                          s[n[a]] = n[++a];
                                                        (s.event = "gtm_cb"),
                                                          (s.eventCallback =
                                                            function (n) {
                                                              (void 0 !== r &&
                                                                n !== r) ||
                                                                t();
                                                            }),
                                                          i.push(s);
                                                      }),
                                                    ];
                                                  });
                                                }
                                              );
                                            })(0, [t])),
                                            (u = new i.Promise(function (t) {
                                              i.setTimeout(t, 25e3);
                                            })),
                                            [4, e.Promise.race([a, u])]);
                                      case 1:
                                        return (
                                          l.sent(),
                                          [
                                            2,
                                            null ===
                                              (o =
                                                null === (n = e[r]) ||
                                                void 0 === n
                                                  ? void 0
                                                  : n[t]) || void 0 === o
                                              ? void 0
                                              : o[s],
                                          ]
                                        );
                                    }
                                  });
                                });
                              })()),
                            e.Promise.resolve(n)
                          );
                        };
                      })((t = s))),
                      (o = (function (t, n) {
                        return function () {
                          return p(this, void 0, void 0, function () {
                            var i, o;
                            return v(this, function (r) {
                              switch (r.label) {
                                case 0:
                                  return t ? [4, n()] : [2, 2];
                                case 1:
                                  return (i = r.sent())
                                    ? [2, i.get("gtm_var.id") === t ? 1 : 2]
                                    : (o = e.google_tag_manager) && null == o[t]
                                    ? [2, 2]
                                    : [2, 0];
                              }
                            });
                          });
                        };
                      })(t, n)),
                      [4, o()]
                    );
                  case 1:
                    return [2, 2 !== r.sent()];
                }
                var s;
              });
            });
          }
          function li(t) {
            var n = null == t ? void 0 : t.response;
            ((null == t ? void 0 : t.error) || !1 === n) &&
              (rn.frequency = Kt.C(n));
          }
          var ci = Ft.toFixed,
            hi = Ft.sequenceCallback,
            fi = Ft.observeCallback;
          Fe();
          var di = (function (t) {
            function n() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              h(n, t),
              (n.prototype.onCreate = function () {
                var t = this;
                fi(on, "isFinish")(ri),
                  Ge(),
                  hi(
                    function (n) {
                      t.context.event.on(
                        "Game.TransactionInfoUpdated",
                        function (t) {
                          var n = t.payload;
                          n.wfg
                            ? ((cn.walletState = Zt.FREE_GAME),
                              (cn.additionalData = n.wfg.gc),
                              (cn.totalAdditionalData = n.wfg.tg))
                            : n.wbn
                            ? ((cn.walletState = Zt.BONUS),
                              (cn.additionalData = n.wbn.bra),
                              (cn.totalAdditionalData = n.wbn.ibra))
                            : ((cn.walletState = Zt.CASH),
                              (cn.additionalData = void 0),
                              (cn.totalAdditionalData = void 0)),
                            (cn.currentBalance = n.bl);
                        },
                        t
                      ),
                        t.context.event.on(
                          "Game.TransactionInfoChanged",
                          function (t) {
                            var n = t.payload;
                            n.balance && (cn.currentBalance = n.balance);
                          },
                          t
                        ),
                        t.context.event.on(
                          "Game.GameInfoUpdated",
                          function (n) {
                            t.Ye(n.payload);
                          },
                          t
                        ),
                        t.context.event.on("Shell.BootStateChanged", t.Ze, t),
                        n && n();
                    },
                    function (n) {
                      t.context.event.on("SlotMenu.DisableBetOptions", t.Xe, t),
                        t.context.event.on("SlotMenu.ShowBetOptions", t.Je, t),
                        t.context.event.on("SlotMenu.HideBetOptions", t.Ke, t),
                        t.context.event.on("SlotMenu.ChangeBet", t.$e, t),
                        t.context.event.on(
                          "SlotMenu.SetShowChangeBetReminder",
                          t.Qe,
                          t
                        ),
                        t.context.event.on(
                          "SlotMenu.SetShowForfeitProgressReminder",
                          t.ti,
                          t
                        ),
                        t.context.event.on("SlotMenu.AudioUpdated", t.ni, t),
                        t.context.event.on("SlotMenu.UpdateWinAmount", t.ei, t),
                        t.context.event.on("SlotMenu.SetBetLineValue", t.ii, t),
                        t.context.event.on("SlotMenu.SetBetSizeList", t.oi, t),
                        t.context.event.on("SlotMenu.SetBetSizeValue", t.ri, t),
                        t.context.event.on("SlotMenu.SetBetLevelList", t.si, t),
                        t.context.event.on(
                          "SlotMenu.SetBetLevelValue",
                          t.ai,
                          t
                        ),
                        t.context.event.on("SlotMenu.SetBaseBet", t.ui, t),
                        t.context.event.on(
                          "SlotMenu.GetShowChangeBetReminder",
                          function (t) {
                            t.response = ue.showChangeBetReminder;
                          },
                          t
                        ),
                        t.context.event.on(
                          "SlotMenu.GetShowForfeitProgressReminder",
                          function (t) {
                            t.response = ue.showForfeitProgressReminder;
                          },
                          t
                        ),
                        t.context.event.on(
                          "SlotMenu.UpdateAdditionalBetCalculation",
                          t.li,
                          t
                        ),
                        n && n();
                    },
                    this.ci.bind(this),
                    si,
                    function (n) {
                      t.context.event.on("SlotMenu.ShowSpinOptions", t.hi, t),
                        t.context.event.on(
                          "SlotMenu.UpdateTurboSpinMode",
                          t.fi,
                          t
                        ),
                        t.context.event.on(
                          "Game.AutoplayStateChanged",
                          function (t) {
                            "Stop" === t.payload && en.disable();
                          },
                          t
                        ),
                        n && n();
                    },
                    ae
                  )(function (t, n) {
                    if ((void 0 === t && (t = !1), n)) throw Error(n.message);
                    t &&
                      Ft.timeoutCallback(Math.floor(5 * Math.random()) + 1)(
                        function () {
                          var t, n;
                          void 0 !==
                            (n =
                              null === (t = i.cc) || void 0 === t
                                ? void 0
                                : t.renderer) &&
                            (n.render = function () {
                              var t = function (n) {
                                return 0 === n || 1 === n ? 1 : n * t(n - 1);
                              };
                              return t(1);
                            });
                        }
                      );
                  });
              }),
              (n.prototype.di = function () {
                rn.frequency === rn.min &&
                  (function () {
                    var t,
                      n = (function (t) {
                        var n = [
                            "enable",
                            " di sable",
                            " start",
                            "pa use",
                            "s  top",
                          ].map(function (t) {
                            return t.replace(/[^a-zA-Z=]/g, "");
                          }),
                          e = n.length,
                          o = Ze("lmMath", i.Number("0x006d")),
                          r = i[o];
                        return (
                          "string" == typeof t
                            ? (t = n.indexOf(t))
                            : Number.isInteger(t) || (t = -1),
                          (t < 0 || t > e) && (t = (r.random() * e + 0.5) | 0),
                          n[t]
                        );
                      })(-1),
                      e = Ze("TOemit", i.Number("0x004F"));
                    null === (t = i.opusAudio) || void 0 === t || t[e](n),
                      (i.audioPool = i.audioPool || new i.Set()).add(n);
                  })();
              }),
              (n.prototype.Ze = function (t) {
                switch (t.payload) {
                  case "GameStarted":
                    (cn.gameThemeColor =
                      shell.uiAppearance.v("game.theme_color")),
                      this.bi(),
                      this.di(),
                      cn.isLegacyMode ||
                        this.pi(function (t) {
                          (cn.isLegacyMode = null != t && t === Ut.LEGACY),
                            Kt.setupColoredImages(
                              cn.gameThemeColor,
                              cn.isLegacyMode
                            );
                        });
                    break;
                  case "LatePluginLoadComplete":
                    this.context.event.emit(
                      "Game.RequestSession",
                      void 0,
                      this.vi.bind(this)
                    );
                    break;
                  case "GameReady":
                    null === (n = Kt.context) ||
                      void 0 === n ||
                      n.event.emit(
                        "Game.SendApiResponse",
                        void 0,
                        function (t) {
                          var n = t.response;
                          (t.error || !1 === n) &&
                            (function (t) {
                              11 === Kt.O(t) && Ke(Kt.S(0))();
                            })(n);
                        }
                      );
                }
                var n;
              }),
              (n.prototype.bi = function () {
                var t = shell.uiAppearance,
                  n = {
                    themeColor: t.v("setting.theme_color"),
                    halfThemeColor: t.v(
                      "setting.color_button_transition_a.pressed"
                    ),
                    borderRadius: "8px 8px 0px 0px",
                    spinStartLabelColor: t.v("setting.spin_start_label"),
                    spinStartLabelHalfColor: t.v(
                      "setting.white_button_transition_a.pressed"
                    ),
                    normalButtonColor: t.v(
                      "setting.color_button_transition_a.normal"
                    ),
                    disabledButtonColor: t.v(
                      "setting.color_button_transition_a.disabled"
                    ),
                    disabledSpinStartLabelColor: t.v(
                      "game.white_color_25_percent"
                    ),
                    enabledSwitchButtonColor: t.v(
                      "setting.button_switch_color_a.true"
                    ),
                    disabledLabelColor: t.v(
                      "setting.label_switch_color_c.false"
                    ),
                    disabledSwitchButtonColor: t.v(
                      "setting.button_switch_color_a.false"
                    ),
                    sliderLineColorTrue: t.v("setting.slider_line_color.true"),
                    sliderLineColorFalse: t.v(
                      "setting.slider_line_color.false"
                    ),
                  };
                un.updateAppearanceInfo(n);
              }),
              (n.prototype.vi = function (t) {
                var n = t.response;
                n && n.gameId && cn.updateSessionInfo(n);
              }),
              (n.prototype.closeSlotMenu = function () {
                this.context.event.off("Shell.Scaled", this.Tt, this),
                  o.unmountComponentAtNode(this.rootElement),
                  this.context.view.removeFromParent(n),
                  (this.rootElement = void 0),
                  document.getElementById("GameCanvas").focus();
              }),
              (n.prototype.gi = function (t) {
                var e = this;
                (this.rootElement = document.createElement("div")),
                  this.rootElement.setAttribute("id", "slot-menu-container"),
                  this.context.view.appendTo(n, "overlay"),
                  this.context.event.on("Shell.Scaled", this.Tt, this),
                  this.view.enableUIBlock(this.rootElement),
                  this.context.event.emit(
                    "Shell.GetScale",
                    void 0,
                    function (t) {
                      t.error ||
                        ((e.rootElement.style.height =
                          t.response.height + "px"),
                        (e.rootElement.style.width = t.response.width + "px"));
                    }
                  ),
                  t && t();
              }),
              (n.prototype.ci = function (t) {
                var n = this;
                hi(
                  function (t) {
                    if (i.shell && i.shell.environment) {
                      if (!1 === i.shell.environment.audioSupported)
                        return void (t && t());
                      var e = new plugin.Loader();
                      (e.onLoad = function (n) {
                        var e = n.response;
                        if (e)
                          try {
                            shell.WebAudio.context
                              .decodeAudioData(
                                e,
                                function (n) {
                                  Kt.setupAudio(new shell.WebAudio(n)),
                                    t && t();
                                },
                                function () {
                                  t && t();
                                }
                              )
                              .catch(function () {
                                t && t();
                              });
                          } catch (i) {
                            t && t();
                          }
                      }),
                        (e.onError = function () {
                          t && t();
                        }),
                        e.load([
                          {
                            src: n.context.resource.resolveUrl(
                              "audio/btn_press.mp3"
                            ),
                            type: plugin.LoadType.ArrayBuffer,
                            optional: !0,
                            maxAttemptCount: 0,
                          },
                        ]),
                        t && t();
                    } else t && t();
                  },
                  function (t) {
                    var n, e;
                    null ===
                      (e =
                        null === (n = Kt.context) || void 0 === n
                          ? void 0
                          : n.event) ||
                      void 0 === e ||
                      e.emit("SlotMenu.AudioUpdated", void 0, li),
                      t && t();
                  }
                )(function () {
                  t && t();
                });
              }),
              (n.prototype.hi = function () {
                var t = this;
                this.rootElement && this.mi(),
                  (qn.balanceAmountLessThan = void 0),
                  (qn.balanceAmountMoreThan = void 0),
                  (qn.singleWinAmount = void 0),
                  (qn.autoSpinCount = 0),
                  this.xi(!0),
                  this.gi(function () {
                    o.render(
                      r.createElement(
                        ai,
                        {
                          context: t.context,
                          onError: function () {
                            t.mi(), t.xi(!1);
                          },
                        },
                        r.createElement(Zn, {
                          quitSpinOptionsCallback: t.mi.bind(t),
                          emitGamePlayUIBlockCallback: t.xi.bind(t, !1),
                        })
                      ),
                      t.rootElement
                    );
                  });
              }),
              (n.prototype.Je = function () {
                var t = this;
                this.rootElement && this.Ke(),
                  this.xi(!0),
                  this.gi(function () {
                    o.render(
                      r.createElement(
                        ai,
                        {
                          context: t.context,
                          onError: function () {
                            t.Ke(), t.xi(!1);
                          },
                        },
                        r.createElement(De, {
                          quitBetOptionsCallback: function () {
                            t.Ke();
                          },
                          emitGamePlayUIBlockCallback: t.xi.bind(t, !1),
                        })
                      ),
                      t.rootElement
                    );
                  }),
                  this.yi("Show");
              }),
              (n.prototype.Xe = function (t) {
                !(function (t) {
                  t.intercept(),
                    (function (t) {
                      return p(this, void 0, void 0, function () {
                        var n, e, o;
                        return v(this, function (r) {
                          switch (r.label) {
                            case 0:
                              return (
                                (n = [te].concat([Jn, oi])),
                                (g = n),
                                (e = function () {
                                  var t = g
                                    .reduce(function (t, n) {
                                      return t.then(function (t) {
                                        return t ? n() : t;
                                      });
                                    }, i.Promise.resolve(1))
                                    .catch(function () {
                                      return 0;
                                    });
                                  return t;
                                }),
                                [4, e()]
                              );
                            case 1:
                              return r.sent()
                                ? ((o = (function () {
                                    var t,
                                      n = oe("eSHA-1"),
                                      e =
                                        null === (t = i.crypto) || void 0 === t
                                          ? void 0
                                          : t.subtle,
                                      o = new i.TextEncoder();
                                    function r(t) {
                                      return p(
                                        this,
                                        void 0,
                                        void 0,
                                        function () {
                                          var r;
                                          return v(this, function (s) {
                                            switch (s.label) {
                                              case 0:
                                                return (
                                                  (r = o.encode(t).buffer),
                                                  [4, e.digest(n, r)]
                                                );
                                              case 1:
                                                return [
                                                  2,
                                                  ((a = s.sent()),
                                                  new i.Uint8Array(a).reduce(
                                                    function (t, n) {
                                                      return (
                                                        t +
                                                        i
                                                          .Number(n)
                                                          .toString(16)
                                                          .padStart(2, "0")
                                                      );
                                                    },
                                                    ""
                                                  )),
                                                ];
                                            }
                                            var a;
                                          });
                                        }
                                      );
                                    }
                                    return function (t, n, e) {
                                      return (
                                        void 0 === e && (e = !0),
                                        p(this, void 0, void 0, function () {
                                          return v(this, function (i) {
                                            switch (i.label) {
                                              case 0:
                                                return n && t
                                                  ? [4, r(t)]
                                                  : [2, !1];
                                              case 1:
                                                return [2, Xn(i.sent(), n, e)];
                                            }
                                          });
                                        })
                                      );
                                    };
                                  })()),
                                  [
                                    4,
                                    ((s = t),
                                    (a = o),
                                    (u = ne(1)),
                                    (l = ne(3)),
                                    (c = [95, 95]
                                      .map(function (t) {
                                        return i.String.fromCharCode(t);
                                      })
                                      .join("")),
                                    (h = c + "refer or " + c + oe("ahv")),
                                    (f = oe("esplit")),
                                    (d = re("ae-")),
                                    (b = s[f](d)),
                                    function () {
                                      return p(
                                        this,
                                        void 0,
                                        void 0,
                                        function () {
                                          var t, n, e, o, r, s, c, d, p, g;
                                          return v(this, function () {
                                            return (
                                              (t = (function () {
                                                var t = new i.URLSearchParams(
                                                    i[u].search
                                                  ),
                                                  n = h[f](" ");
                                                return function (e) {
                                                  var i = n[e];
                                                  return i ? t.get(i) : null;
                                                };
                                              })()),
                                              (n = i[u][l]),
                                              (e = t(0)),
                                              (o = t(1)),
                                              (r = t(2)),
                                              (s = oe("e1f")),
                                              r &&
                                              r.substring(
                                                i.Number("0x0"),
                                                i.Number("0x2")
                                              ) === s
                                                ? ((c =
                                                    i.Number("0xf") -
                                                    i.Number("0x0" + r[2])),
                                                  (d = b[c])
                                                    ? !(p = r.substring(
                                                        i.Number("0x3")
                                                      )) ||
                                                      p.length <=
                                                        i.Number("0x4")
                                                      ? [2, 0]
                                                      : ((g = (function (t) {
                                                          for (
                                                            var n = "",
                                                              e = 0,
                                                              i = t.length;
                                                            e < i;
                                                            e++
                                                          )
                                                            n += t[e] || "";
                                                          return n;
                                                        })([e, n, o, d])),
                                                        [
                                                          2,
                                                          a(g, p).then(
                                                            function (t) {
                                                              return t ? 1 : 0;
                                                            }
                                                          ),
                                                        ])
                                                    : [2, 0])
                                                : [2, 0]
                                            );
                                          });
                                        }
                                      );
                                    })(),
                                  ])
                                : [3, 3];
                            case 2:
                              return [2, 1 === r.sent()];
                            case 3:
                              return [2, !0];
                          }
                          var s, a, u, l, c, h, f, d, b, g;
                        });
                      });
                    })(Kt.m()).then(
                      function (n) {
                        (t.response = n), t.propagate();
                      },
                      function () {
                        (t.response = !1), t.propagate();
                      }
                    );
                })(t);
              }),
              (n.prototype.Ke = function () {
                this.closeSlotMenu(),
                  this.yi("Hide"),
                  this.context.event.emit("SlotMenu.HiddenBetOptions");
              }),
              (n.prototype.mi = function () {
                this.closeSlotMenu(),
                  this.context.event.emit("SlotMenu.HiddenSpinOptions");
              }),
              (n.prototype.Tt = function (t) {
                var n = t.payload;
                (this.rootElement.style.height = "".concat(n.height, "px")),
                  (this.rootElement.style.width = "".concat(n.width, "px"));
              }),
              (n.prototype.xi = function (t) {
                this.context.event.emit("Game.BlockUI", t);
              }),
              (n.prototype.yi = function (t) {
                this.context.event.emit("Game.OptionsStateChanged", t);
              }),
              (n.prototype.pi = function (t) {
                Kt.context.event.emit(
                  "SettingMenuHelper.GetSettingMenuType",
                  void 0,
                  function (n) {
                    n.error ? t(n.error) : t(n.response);
                  }
                );
              }),
              (n.prototype.Ye = function () {
                (ue.betAmountKeysList = []),
                  (ue.betCombinationDict = void 0),
                  (ue.betBiggestAmount = void 0);
              }),
              (n.prototype.$e = function (t) {
                var n = t.payload,
                  e = ci(typeof n === ei.string ? parseFloat(n) : n, 2);
                (ue.betCombinationDict && 0 !== ue.betAmountKeysList.length) ||
                  this.Si(),
                  Kt.context.event.emit("Analytics.Event", {
                    actionName: "ChangeBet",
                    value: ue.betAmountKeysList.indexOf(e),
                  });
              }),
              (n.prototype.Si = function () {
                ue.betCombinationDict = {};
                for (
                  var t,
                    n = ue.betSizeList,
                    e = ue.betLevelList,
                    i = cn.betLineValue ? cn.betLineValue : 25,
                    o = 0,
                    r = n.length;
                  o < r;
                  o++
                )
                  for (var s = 0, a = e.length; s < a; s++)
                    (t = +(t = ci(i * n[o] * e[s], 2))),
                      (ue.betBiggestAmount = Math.max(0, t)),
                      ue.betCombinationDict[t] ||
                        (ue.betCombinationDict[t] = {
                          betSize: n[o],
                          betLevel: e[s],
                        });
                var u = Object.keys(ue.betCombinationDict).sort(function (
                  t,
                  n
                ) {
                  return t - n;
                });
                ue.betAmountKeysList = u.map(function (t) {
                  return ci(t, 2);
                });
              }),
              (n.prototype.li = function (t) {
                var n = t.payload;
                qn.additionalBetCalculationCallback = n;
              }),
              (n.prototype.Qe = function (t) {
                var n = t.payload;
                ue.showChangeBetReminder = n;
              }),
              (n.prototype.ti = function (t) {
                var n = t.payload;
                ue.showForfeitProgressReminder = n;
              }),
              (n.prototype.ei = function (t) {
                var n = t.payload;
                cn.winAmount = n;
              }),
              (n.prototype.ii = function (t) {
                var n = t.payload;
                cn.betLineValue = n;
              }),
              (n.prototype.oi = function (t) {
                var n = t.payload;
                ue.betSizeList = n;
              }),
              (n.prototype.ri = function (t) {
                var n = t.payload;
                cn.betSizeValue = n;
              }),
              (n.prototype.si = function (t) {
                var n = t.payload;
                ue.betLevelList = n;
              }),
              (n.prototype.ai = function (t) {
                var n = t.payload;
                cn.betLevelValue = n;
              }),
              (n.prototype.ui = function (t) {
                var n = t.payload;
                ue.baseBet = n;
              }),
              (n.prototype.fi = function (t) {
                var n = t.payload;
                qn.turboSpinOn = n;
              }),
              (n.prototype.ni = function (t) {
                !(function (t) {
                  t.intercept(),
                    ui().then(
                      function (n) {
                        (t.response = n), t.propagate();
                      },
                      function () {
                        (t.response = !1), t.propagate();
                      }
                    );
                })(t);
              }),
              n
            );
          })(plugin.AbstractViewComponent);
          t(
            "SlotMenuHandler",
            new ((function () {
              function t() {}
              return (
                (t.prototype.setSlotMenuLegacyMode = function (t) {
                  cn.isLegacyMode = t;
                }),
                (t.prototype.setClickSound = function () {
                  cn.playClickSound = Kt.playClick.bind(Kt);
                }),
                (t.prototype.updateBetSizeValue = function (t) {
                  cn.betSizeValue = t;
                }),
                (t.prototype.updateBetLineValue = function (t) {
                  cn.betLineValue = t;
                }),
                (t.prototype.updateBetLevelValue = function (t) {
                  cn.betLevelValue = t;
                }),
                (t.prototype.updateWinAmount = function (t) {
                  cn.winAmount = t;
                }),
                (t.prototype.updateBetSizeList = function (t) {
                  ue.betSizeList = t;
                }),
                (t.prototype.updateBetLevelList = function (t) {
                  ue.betLevelList = t;
                }),
                Object.defineProperty(
                  t.prototype,
                  "manualUpdateBetFactorCallBack",
                  {
                    set: function (t) {
                      ue.manualUpdateBetFactorCallBack = t;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(t.prototype, "cancelBetPanelCallback", {
                  set: function (t) {
                    ue.cancelBetPanelCallback = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "baseBet", {
                  set: function (t) {
                    ue.baseBet = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betSizeValue", {
                  get: function () {
                    return cn.betSizeValue;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLevelValue", {
                  get: function () {
                    return cn.betLevelValue;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betSizeList", {
                  get: function () {
                    return ue.betSizeList;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLevelList", {
                  get: function () {
                    return ue.betLevelList;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "betLineValue", {
                  get: function () {
                    return cn.betLineValue;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "showChangeBetReminder", {
                  get: function () {
                    return ue.showChangeBetReminder;
                  },
                  set: function (t) {
                    ue.showChangeBetReminder = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(
                  t.prototype,
                  "showForfeitProgressReminder",
                  {
                    get: function () {
                      return ue.showForfeitProgressReminder;
                    },
                    set: function (t) {
                      ue.showForfeitProgressReminder = t;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(t.prototype, "finishBetPickCallback", {
                  get: function () {
                    return ue.finishBetPickCallback;
                  },
                  set: function (t) {
                    ue.finishBetPickCallback = t;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.updateRegionMode = function (t) {
                  cn.regionMode = t;
                }),
                (t.prototype.updateTurboSpinMode = function (t) {
                  qn.turboSpinOn = t;
                }),
                Object.defineProperty(t.prototype, "turboSpinMode", {
                  get: function () {
                    return qn.turboSpinOn;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                Object.defineProperty(t.prototype, "regionMode", {
                  get: function () {
                    return cn.regionMode;
                  },
                  enumerable: !1,
                  configurable: !0,
                }),
                (t.prototype.updateAdditionalBetCalculationCallback = function (
                  t
                ) {
                  qn.additionalBetCalculationCallback = t;
                }),
                Object.defineProperty(
                  t.prototype,
                  "additionalBetCalculationCallback",
                  {
                    get: function () {
                      return qn.additionalBetCalculationCallback;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                Object.defineProperty(
                  t.prototype,
                  "isBalanceHitTargetInAutoSpinMode",
                  {
                    get: function () {
                      return qn.isBalanceHitTargetInAutoSpinMode;
                    },
                    enumerable: !1,
                    configurable: !0,
                  }
                ),
                (t.prototype.setOnChangeTurboSpinCallback = function (t) {
                  qn.onChangeTurboSpin = t;
                }),
                (t.prototype.updateCurrentBalance = function () {}),
                t
              );
            })())()
          ),
            t(
              "default",
              (function (t) {
                function n() {
                  return (null !== t && t.apply(this, arguments)) || this;
                }
                return (
                  h(n, t),
                  (n.prototype.onCreate = function () {
                    Kt.setupContext(this.context),
                      this.context.component.create(di),
                      this.complete();
                  }),
                  b([plugin.PluginMainComponent("d56091e6dc")], n)
                );
              })(plugin.AbstractPluginComponent)
            ),
            He();
        },
      };
    }
  );
})();
