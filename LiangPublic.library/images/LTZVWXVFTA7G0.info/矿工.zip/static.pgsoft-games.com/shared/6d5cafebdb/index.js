System.register(["./dc1d4d64e1.c2335.js"], function (r) {
  "use strict";
  var a = { _$meta: 1, default: 1 };
  return {
    setters: [
      function (e) {
        var t,
          n = {};
        for (t in e) a[t] || (n[t] = e[t]);
        r(n);
      },
    ],
    execute: function () {
      r("_$meta", {
        name: "6d5cafebdb",
        version: "3.3.0-rc.1",
        alias: "CAkQC3zCjBZExUeADYVOFce",
      });
    },
  };
});
